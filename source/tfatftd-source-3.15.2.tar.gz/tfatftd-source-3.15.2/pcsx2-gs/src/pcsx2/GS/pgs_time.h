#pragma once
// lab profiling: where the render thread's time goes inside PCSX2's renderer (printed with ?PS2_PGS_PROF)
#include <chrono>
extern double g_pgs_t[12];   // 0-7 ms timers, 8 = stencil DATE draws, 9 = draws with depth
inline double pgs_now_ms() { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
struct PgsTimed { int i; double t0; explicit PgsTimed(int n) : i(n), t0(pgs_now_ms()) {} ~PgsTimed() { g_pgs_t[i] += pgs_now_ms() - t0; } };
#define PGS_TIME(n) PgsTimed pgs_timed_scope(n)
