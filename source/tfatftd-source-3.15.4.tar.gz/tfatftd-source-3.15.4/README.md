# tfatftd.xyz — source code

This is the source code of the game engine that runs **The Fast and the Furious** (PS2, 2006) in the browser at
tfatftd.xyz, including the PCSX2 graphics renderer it uses for high resolutions (up to 8x).

No game data is in here: no disc image, no game code, no textures, no saves. The engine's scripts turn a disc you own
into a web page on your own machine (`engine/scripts/port.sh`, see `engine/README.md`). The recompiled game code those
scripts produce comes from your disc and is not part of this package.

## What's in here

| folder | what it is | license |
|---|---|---|
| `engine/` | ps2-web-recomp by Samir Nuri, with the changes made for tfatftd.xyz (physics, online play, camera and widescreen options, performance work, the hook-up to PCSX2's renderer) | MIT (original files) — the whole build is GPL-3.0-or-later, see below |
| `pcsx2-gs/src/` | the parts of PCSX2 used: the GS (graphics synthesizer) core, hardware renderer, texture cache and shaders, plus `common/` and a few 3rdparty headers. Copied from PCSX2 master `1ccd6a8` (2026-11-04) by `sync.sh`, with the small web patches in `patches.py` | GPL-3.0-or-later (PCSX2), 3rdparty licenses in `licenses/` |
| `pcsx2-gs/web/` | new code: PCSX2's GS device on WebGPU (`GSDeviceWGPU`, `GSTextureWGPU`), the WGSL ports of PCSX2's shaders (`shaders/`), a small shader preprocessor, the glue that replaces PCSX2's frontend, and the bridge to the engine | GPL-3.0-or-later |
| `pcsx2-gs/native/` | a test harness that runs the same renderer natively (wgpu-native) on recorded GS streams | GPL-3.0-or-later |

## License

The engine (ps2-web-recomp) is MIT-licensed, and its files keep that license (`licenses/ps2-web-recomp-MIT.txt`).
The PCSX2 code is GPL-3.0-or-later. Because the build that runs on tfatftd.xyz combines both, **the combined program
is distributed under the GNU General Public License version 3 or later** (`COPYING.GPLv3`). You can use, change and
share it under those terms.

## Building

1. Engine: follow `engine/README.md` (`scripts/setup.sh`, then `scripts/port.sh` with your own disc image).
2. PCSX2 renderer: set `PS2_PGS_DIR` to this package's `pcsx2-gs` folder before the web build
   (`PS2_PGS_DIR=$PWD/pcsx2-gs engine/scripts/build_web.sh tokyodrift <emsdk>`). CMake then builds `libpcsx2gs`.
3. In the page, `?PS2_PGS=<1..8>` turns PCSX2's renderer on at that resolution.
4. Native test harness: `cd pcsx2-gs/native && make` (needs clang and wgpu-native in `engine/third_party/wgpu-native`).

See `CREDITS.md` for the people whose work this is built on.
