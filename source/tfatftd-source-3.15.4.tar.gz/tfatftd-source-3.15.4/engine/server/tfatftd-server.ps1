# tfatftd.xyz multiplayer server (v0.07) - a tiny relay that runs on your own PC.
# Every player's browser sends its car position ~15 times a second; the server passes it to everyone else.
# v0.02: it is also the network switch for the game's own LAN mode - every Ethernet frame the emulated
# PS2 network adapter sends (binary websocket message) goes to every other player, like one LAN cable.
# v0.07: ideas from th0mk's nfsu2.xyz server (github.com/th0mk/nfsu2-web, MIT):
#        - a real switch: it learns which player has which network-card address, so a LAN frame meant for one
#          player goes only to that player (before, every frame went to everyone)
#        - it pings every player each 2 s; a player on a slow connection gets car updates at half rate so he never chokes
# v0.06: the career room host is invisible (the server itself keeps the room open; no car or tag in game)
# v0.05: the career room has a host too - TOKYO BOT, parked at the Career start
# v0.04: the bot host keeps one shared lobby (up to 3 players + the bot) and restarts itself when this file is updated
# v0.03: a bot host lives on the LAN cable too - a pretend PS2 that hosts a lobby anyone can join any time
#        (Multiplayer > LAN > Join shows it). It runs while this window is open.
# Plain PowerShell, no exe (nothing for Smart App Control to block).
#   local test:  ws://localhost:8787
#   friends:     the https address Tailscale Funnel prints (the .bat sets that up)
param([int]$Port = 8787, [string]$BotName = 'TOKYO BOT')
$ErrorActionPreference = 'Stop'

# the bot host (C#, compiled on the fly by PowerShell - still no exe)
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading;

// tfatftd.xyz LAN bot host: a pretend PS2 on the LAN cable. It answers "anyone hosting?", lets players join its
// lobby, starts the session when they press Ready and keeps everyone connected. Written for C# 5 (Windows PowerShell).
public static class LanBot
{
    public static readonly ConcurrentQueue<byte[]> Outbox = new ConcurrentQueue<byte[]>();
    public static readonly ConcurrentQueue<string> Log = new ConcurrentQueue<string>();
    static readonly byte[] Mac = { 0x02, 0x84, 0x00, 0x00, 0x00, 0xfe };
    static readonly byte[] Ip = { 10, 84, 0, 254 };
    static readonly object Gate = new object();
    static readonly Dictionary<string, Peer> Peers = new Dictionary<string, Peer>();
    static Timer timer;
    static int ipId = 0x100;
    static string botName = "TOKYO BOT";
    // what the bot hosts: Tokyo Tower Hot Spot, Destination Battle 1 (a race through the open city, clock counts up)
    public static int Location = 0x146f, EventType = 0x0a, EventText = 0x1d66;

    const string SearchReply = "0000ff01000004009200000040313810050000000000100001000000504c41594552000000000000000000000000000000000000000000000000000000000000020000000000000000000000030000005014000000000000040000000900000000000000050000004d1d000004504c4159455200000000000000000000000000000004010a5400d5db21000000000000db21000000000000";
    const string LobbyPre = "0f00520500000004050000000000100001000000504c41594552000000000000000000000000000000000000000000000000000000000000020000000000000000000000030000005014000000000000040000000900000000000000050000004d1d000004504c41594552000000000000000000000000000000000000000101010006000000504c415945520000000000000000000000000d01000006000000504c41594552000000000000000000000001";
    const string BotRecord = "17040000a1bb0d0051350c00c1caa13ea813d03e85eb513e00000000c1caa13ea813d03e85eb513e00000000ef010009e7ffbfff73ff00000000000002ef010009e7ffbfff73ff00000000000000ef010009e7ffbfff73ff00000000000000ef010009e7ffbfff73ff00000000000000ef010009e7ffbfff73ff00000000000000ef010009e7ffbfff73ff00000000000000ef010009e7ffbfff73ff000000000000001228d6780000e52700000001060000000000000000000000187900000000000000000000000000000000000001310d0000310d0000ffffffffcf7800002526000000010000000000000000000000002a7c000000000000000000000000000000000000011b0d00001c0d00001d0d000000000000c8780000a425000000010300000000000000000000000c7b00000000000000000000000000000000000001190d00001a0d0000ffffffffd0780000a52500000001030000000100000000000000707b00000000804000000000000000000000000001200d0000210d0000ffffffffd1780000a62500000001030000000100000001000000847b00000000804000000000000000000000000001200d0000210d0000ffffffffc3780000a72500000001000000000200000000000000137c00000000000000000000000000000000000001240d0000250d0000ffffffffc4780000a82500000001000000000300000000000000147c000000000000000000000000000000000000012a0d00002b0d0000ffffffffc6780000a92500000001000000000100000000000000157c000000000000000000000000000000000000011e0d00001f0d0000ffffffffd2780000aa2500000001000000000700000000000000167c00000000000000000000000000000000000001320d0000330d0000ffffffffc2780000ab2500000001000000000900000000000000177c000000000000000000000000000000000000012c0d00002d0d0000ffffffffd3780000952800000001010000000100000001000000d47b0000000000000000000000000000000000000000000000000000017416000075160000ffffffffd4780000ad2500000001000000000b000000000000001a7c00000000000000000000000000000000000001280d0000290d0000ffffffffc7780000ae2500000001000000000a00000000000000197c00000000000000000000000000000000000001260d0000270d0000ffffffff011254124012541240d5780000af2500000001000000000a00000001000000187c000000000000000000000000000000000000012f0d0000300d0000ffffffffbf780000b125000000010300000002000000010000001e7c000000000000000000000000000000000000015f1d00005f1d0000ffffffffcc780000b0250000013aff07ff40ff00000000000001000000000c000000000000001d7c00000000000000000000000000000000000001340d0000350d0000ffffffffb67800004555000000010100000001000000030000005a79000000000000000000000000000000000000000000000000000000c9780000075500000001000000001000000000000000297c000000000000000000000000000000000000016a1600006b160000ffffffff";
    const string JoinEntry = "000d0a54005edb21000001010006000000504c41594552000000000000000000000001";
    const string Pose42 = "42007900020300009e552944cfe2c842890b10c4e32c243c73586338c164363b74fc7f3ffe7fff7ffb7f00800080ff7f3f004000006910000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
    class Pending { public int Seq; public byte[] Msg; public long Sent; }
    class Peer
    {
        public byte[] Mac = new byte[6], Ip = new byte[4];
        public string Key, Name = "PLAYER";
        public int Slot, S = 1, R = 1, Ping = -1, Ping46 = -1, K46;
        public long Last46, LastSeen, LastPose;
        public bool Joined, Ready, Racing;
        public byte[] Record;
        public byte[] Tail = Hex("06000000504c41594552" + "0000000000000000000000");
        public List<byte[]> Frags = new List<byte[]>();
        public int FragWait = -1;
        public List<Pending> Pending = new List<Pending>();
        public List<byte[]> Extra = new List<byte[]>();
    }
    static bool sessionStarted;
    static long startAt;

    public static void Start(string name)
    {
        if (!string.IsNullOrEmpty(name)) botName = name.ToUpperInvariant();
        if (botName.Length > 15) botName = botName.Substring(0, 15);
        timer = new Timer(Tick, null, 50, 50);
        Say("bot host ready as \"" + botName + "\" on 10.84.0.254");
    }

    static void Say(string s) { Log.Enqueue(s); }
    static long Now() { return Environment.TickCount; }
    static byte[] Hex(string h)
    {
        byte[] b = new byte[h.Length / 2];
        for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(h.Substring(i * 2, 2), 16);
        return b;
    }
    static void PutName(byte[] b, int at, int room, string name)
    {
        for (int i = 0; i < room; i++) b[at + i] = 0;
        for (int i = 0; i < name.Length && i < room - 1; i++) b[at + i] = (byte)name[i];
    }
    // every "PLAYER" in a captured template becomes our name (length fields in front of it too)
    static void Rename(byte[] b, int from, int to)
    {
        byte[] pat = { 0x50, 0x4c, 0x41, 0x59, 0x45, 0x52 };
        for (int i = from; i + 6 <= to; i++)
        {
            bool hit = true;
            for (int k = 0; k < 6; k++) if (b[i + k] != pat[k]) { hit = false; break; }
            if (!hit) continue;
            bool counted = i >= 4 && b[i - 4] == 6 && b[i - 3] == 0 && b[i - 2] == 0 && b[i - 1] == 0;
            if (counted) { for (int k = 0; k < 6; k++) b[i + k] = (byte)"SERVER"[k]; i += 5; }
            else { PutName(b, i, 16, botName); i += 15; }
        }
    }
    static ushort U16(byte[] b, int o) { return (ushort)(b[o] | (b[o + 1] << 8)); }
    static byte Lo(int v) { return (byte)v; }
    static byte Hi(int v) { return (byte)(v >> 8); }

    static void Send(byte[] dstMac, byte[] dstIp, int sport, int dport, byte[] payload)
    {
        int len = 20 + 8 + payload.Length;
        byte[] f = new byte[Math.Max(60, 14 + len)];
        Array.Copy(dstMac, 0, f, 0, 6); Array.Copy(Mac, 0, f, 6, 6); f[12] = 8; f[13] = 0;
        int id = Interlocked.Increment(ref ipId) & 0xffff;
        byte[] iph = { 0x45, 0, (byte)(len >> 8), (byte)len, (byte)(id >> 8), (byte)id, 0, 0, 0x78, 17, 0, 0 };
        Array.Copy(iph, 0, f, 14, 12); Array.Copy(Ip, 0, f, 26, 4); Array.Copy(dstIp, 0, f, 30, 4);
        int sum = 0;
        for (int i = 14; i < 34; i += 2) sum += (f[i] << 8) | f[i + 1];
        while ((sum >> 16) != 0) sum = (sum & 0xffff) + (sum >> 16);
        sum = ~sum & 0xffff; f[24] = (byte)(sum >> 8); f[25] = (byte)sum;
        int ul = 8 + payload.Length;
        f[34] = (byte)(sport >> 8); f[35] = (byte)sport; f[36] = (byte)(dport >> 8); f[37] = (byte)dport; f[38] = (byte)(ul >> 8); f[39] = (byte)ul;
        Array.Copy(payload, 0, f, 42, payload.Length);
        Outbox.Enqueue(f);
    }
    static byte[] Msg(int ty, params byte[] body)
    {
        byte[] m = new byte[4 + body.Length];
        m[0] = (byte)ty; m[1] = (byte)(ty >> 8); m[2] = (byte)m.Length; m[3] = (byte)(m.Length >> 8);
        Array.Copy(body, 0, m, 4, body.Length);
        return m;
    }
    static byte[] Packet(List<byte[]> msgs)
    {
        int n = 0; foreach (byte[] m in msgs) n += m.Length;
        byte[] p = new byte[6 + n];
        p[2] = (byte)(4 + n); p[3] = (byte)((4 + n) >> 8);
        int o = 6; foreach (byte[] m in msgs) { Array.Copy(m, 0, p, o, m.Length); o += m.Length; }
        return p;
    }
    static byte[] Reliable(Peer p, int ty, params byte[] body)
    {
        byte[] b = new byte[2 + body.Length]; b[0] = Lo(p.R); b[1] = Hi(p.R); Array.Copy(body, 0, b, 2, body.Length);
        byte[] m = Msg(ty, b);
        Pending q = new Pending(); q.Seq = p.R; q.Msg = m; q.Sent = Now();
        p.Pending.Add(q); p.R++;
        return m;
    }
    static void ToPeer(Peer p, List<byte[]> msgs)
    {
        if (msgs.Count == 0) return;
        if (p.Racing) { p.Extra.AddRange(msgs); return; }
        Send(p.Mac, p.Ip, 8667, 8667, Packet(msgs));
    }
    static void ToPeer(Peer p, byte[] msg) { List<byte[]> l = new List<byte[]>(); l.Add(msg); ToPeer(p, l); }

    static List<Peer> Members()
    {
        List<Peer> l = new List<Peer>();
        foreach (Peer p in Peers.Values) if (p.Joined) l.Add(p);
        l.Sort((a, b) => a.Slot.CompareTo(b.Slot));
        return l;
    }

    // the lobby as a new player sees it: us (the host) and everyone already in, each with their car
    static byte[] LobbyFor(Peer newcomer)
    {
        List<Peer> others = new List<Peer>();
        foreach (Peer m in Members()) if (m != newcomer && m.Record != null) others.Add(m);
        // the captured lobby header: our name (fixed fields), then the newcomer's own name (as they sent it), then ours again
        byte[] tpl = Hex(LobbyPre); Rename(tpl, 0, tpl.Length);
        tpl[0x48] = Lo(Location); tpl[0x49] = Hi(Location); tpl[84] = (byte)EventType; tpl[0x60] = Lo(EventText); tpl[0x61] = Hi(EventText);
        tpl[126] = (byte)(1 + others.Count); tpl[128] = (byte)(1 + others.Count); tpl[151] = (byte)others.Count;
        List<byte> d = new List<byte>();
        for (int i = 0; i < 130; i++) d.Add(tpl[i]);
        d.AddRange(newcomer.Tail);
        for (int i = 151; i < tpl.Length; i++) d.Add(tpl[i]);
        d.AddRange(Hex(BotRecord));
        foreach (Peer m in others)
        {
            byte[] e = new byte[13 + m.Tail.Length + 1];
            e[1] = 0x0d; Array.Copy(m.Ip, 0, e, 2, 4); e[6] = 0xdb; e[7] = 0x21; e[10] = 1; e[11] = (byte)m.Slot;
            Array.Copy(m.Tail, 0, e, 13, m.Tail.Length); e[e.Length - 1] = 1;
            d.AddRange(e); d.AddRange(m.Record);
        }
        byte[] all = d.ToArray();
        int total = all.Length; all[2] = Lo(total); all[3] = Hi(total); all[4] = (byte)(total >> 16); all[5] = 0;
        return all;
    }
    static List<byte[]> Fragments(Peer p, byte[] data)
    {
        List<byte[]> frags = new List<byte[]>();
        int idx = 0;
        for (int o = 0; o < data.Length; o += 1200, idx++)
        {
            int n = Math.Min(1200, data.Length - o);
            byte[] body = new byte[1 + 4 + 4 + n];
            body[0] = (byte)idx;
            body[1] = Lo(data.Length); body[2] = Hi(data.Length); body[3] = (byte)(data.Length >> 16);
            body[5] = Lo(n); body[6] = Hi(n);
            Array.Copy(data, o, body, 9, n);
            frags.Add(Reliable(p, 0x6f, body)); p.Pending[p.Pending.Count - 1].Sent = long.MaxValue / 2;
        }
        return frags;
    }

    public static void Feed(byte[] f)
    {
        try { lock (Gate) FeedLocked(f); } catch (Exception e) { Say("bot error: " + e.Message); }
    }
    static void FeedLocked(byte[] f)
    {
        if (f.Length < 42) return;
        int et = (f[12] << 8) | f[13];
        if (et == 0x806 && f[21] == 1 && f[38] == Ip[0] && f[39] == Ip[1] && f[40] == Ip[2] && f[41] == Ip[3])
        {
            byte[] r = new byte[60];
            Array.Copy(f, 6, r, 0, 6); Array.Copy(Mac, 0, r, 6, 6); r[12] = 8; r[13] = 6;
            byte[] arp = { 0, 1, 8, 0, 6, 4, 0, 2 }; Array.Copy(arp, 0, r, 14, 8);
            Array.Copy(Mac, 0, r, 22, 6); Array.Copy(Ip, 0, r, 28, 4); Array.Copy(f, 22, r, 32, 6); Array.Copy(f, 28, r, 38, 4);
            Outbox.Enqueue(r);
            return;
        }
        if (et != 0x800 || f[23] != 17) return;
        int u = 14 + (f[14] & 15) * 4;
        if (u + 8 > f.Length) return;
        int dp = (f[u + 2] << 8) | f[u + 3], ul = (f[u + 4] << 8) | f[u + 5];
        if (u + ul > f.Length || ul < 8) return;
        byte[] pl = new byte[ul - 8]; Array.Copy(f, u + 8, pl, 0, pl.Length);
        byte[] srcMac = new byte[6], srcIp = new byte[4]; Array.Copy(f, 6, srcMac, 0, 6); Array.Copy(f, 26, srcIp, 0, 4);
        if (dp == 8666 && pl.Length == 16)
        {
            if (sessionStarted) return;   // racing: the lobby is closed until everyone is back
            byte[] r = Hex(SearchReply);
            Array.Copy(pl, 12, r, 12, 4);
            Rename(r, 0, r.Length);
            r[0x50] = Lo(Location); r[0x51] = Hi(Location); r[92] = (byte)EventType; r[0x68] = Lo(EventText); r[0x69] = Hi(EventText);
            r[24] = (byte)(1 + Members().Count);
            Array.Copy(Ip, 0, r, 132, 4);
            Send(new byte[] { 255, 255, 255, 255, 255, 255 }, new byte[] { 255, 255, 255, 255 }, 1215, 8666, r);
            return;
        }
        if (dp != 8667 || f[30] != Ip[0] || f[31] != Ip[1] || f[32] != Ip[2] || f[33] != Ip[3]) return;
        string key = string.Join(".", srcIp);
        Peer p;
        if (!Peers.TryGetValue(key, out p)) { p = new Peer(); p.Key = key; Array.Copy(srcMac, p.Mac, 6); Array.Copy(srcIp, p.Ip, 4); Peers[key] = p; }
        p.LastSeen = Now();
        Game(p, pl);
    }

    static void Leave(Peer p, string why)
    {
        Peers.Remove(p.Key);
        if (p.Joined) Say("player " + p.Key + " (" + p.Name + ") " + why);
        if (Members().Count == 0 && sessionStarted) { sessionStarted = false; startAt = 0; Say("everyone left - the lobby is open again"); }
    }

    static void Game(Peer p, byte[] pl)
    {
        List<byte[]> outm = new List<byte[]>();
        int o = 6;
        while (o + 4 <= pl.Length)
        {
            int ty = U16(pl, o), ln = U16(pl, o + 2);
            if (ln < 4 || o + ln > pl.Length) break;
            byte[] m = new byte[ln]; Array.Copy(pl, o, m, 0, ln); o += ln;
            int seq = ln >= 6 ? U16(m, 4) : 0;
            if (ty == 0x0b)
            {
                if (sessionStarted) continue;
                if (p.Joined) { Leave(p, "rejoined"); Peer np = new Peer(); np.Key = p.Key; Array.Copy(p.Mac, np.Mac, 6); Array.Copy(p.Ip, np.Ip, 4); np.LastSeen = Now(); Peers[p.Key] = np; p = np; outm.Clear(); }
                if (Members().Count >= 3) continue;   // 4 cars max: us + 3
                bool[] used = new bool[4]; foreach (Peer x in Members()) used[x.Slot] = true;
                for (int s = 1; s < 4; s++) if (!used[s]) { p.Slot = s; break; }
                if (ln > 12) { p.Tail = new byte[ln - 8]; Array.Copy(m, 8, p.Tail, 0, ln - 8); int nl = Math.Min(15, (int)m[8]); string nm = ""; for (int i = 0; i < nl && 12 + i < ln; i++) nm += (char)m[12 + i]; if (nm.Length > 0) p.Name = nm; }
                p.Joined = true;
                // tell everyone already here about the newcomer
                foreach (Peer x in Members())
                {
                    if (x == p) continue;
                    byte[] b = new byte[12 + p.Tail.Length];
                    Array.Copy(p.Ip, 0, b, 0, 4); b[4] = 0xdb; b[5] = 0x21; b[8] = 1; b[9] = 1; b[10] = (byte)p.Slot;
                    Array.Copy(p.Tail, 0, b, 12, p.Tail.Length);
                    ToPeer(x, Reliable(x, 0x27, b));
                }
                List<byte[]> first = new List<byte[]>();
                first.Add(Msg(0x1e, Lo(p.S), Hi(p.S), Lo(seq), Hi(seq))); p.S++;
                p.Ping46 = p.S; p.Last46 = Now(); p.K46 = 1; first.Add(Msg(0x46, Lo(p.S), Hi(p.S), 1)); p.S++;
                p.Frags = Fragments(p, LobbyFor(p));
                foreach (Pending q in p.Pending) if (q.Msg == p.Frags[0]) q.Sent = Now();
                p.FragWait = U16(p.Frags[0], 4); first.Add(p.Frags[0]); p.Frags.RemoveAt(0);
                Send(p.Mac, p.Ip, 8667, 8667, Packet(first));
                Say("player " + p.Key + " (" + p.Name + ") joined the lobby in slot " + p.Slot);
                continue;
            }
            if (ty == 0x1e)
            {
                int acked = U16(m, 6);
                p.Pending.RemoveAll(x => x.Seq == acked);
                if (acked == p.FragWait) { p.FragWait = -1; if (p.Frags.Count > 0) { byte[] nf = p.Frags[0]; p.Frags.RemoveAt(0); foreach (Pending q in p.Pending) if (q.Msg == nf) q.Sent = Now(); p.FragWait = U16(nf, 4); Send(p.Mac, p.Ip, 8667, 8667, Packet(new List<byte[]> { nf })); } }
                continue;
            }
            if (ty == 0x46)
            {
                if (seq == p.Ping) { int k = m[6]; p.Ping = p.S; outm.Add(Msg(0x4a, Lo(p.S), Hi(p.S), (byte)k, 0x10, 0, 0, 0, 0, 0)); p.S++; }
                continue;
            }
            if (ty == 0x4a)
            {
                if (seq == p.Ping46) { int k = m[6]; p.Ping46 = p.S; p.Last46 = Now(); p.K46 = (k + 1) & 255; outm.Add(Msg(0x46, Lo(p.S), Hi(p.S), (byte)p.K46)); p.S++; }
                continue;
            }
            if (ty == 0x42) continue;
            if (!p.Joined) continue;
            outm.Add(Msg(0x1e, Lo(p.S), Hi(p.S), Lo(seq), Hi(seq))); p.S++;   // ack every reliable message
            if (ty == 0xfa3)
            {
                if (ln >= 8 + 1184) { p.Record = new byte[1184]; Array.Copy(m, 8, p.Record, 0, 1184); }
                if (p.Ping < 0) { p.Ping = p.S; outm.Add(Msg(0x4a, Lo(p.S), Hi(p.S), 1, 0x10, 0, 0, 0, 0, 0)); p.S++; }
            }
            else if (ty == 0x4f && ln >= 9)
            {
                bool ready = m[8] == 1;
                if (!sessionStarted && ready != p.Ready)
                {
                    p.Ready = ready;
                    Say("player " + p.Key + " (" + p.Name + ") is " + (ready ? "ready" : "not ready"));
                    foreach (Peer x in Members()) ToPeer(x, Reliable(x, 0x4f, (byte)p.Slot, 0, (byte)(ready ? 1 : 0)));
                    bool all = true; foreach (Peer x in Members()) if (!x.Ready) all = false;
                    if (all) StartSession();
                }
            }
            else if (ty == 0x33)
            {
                outm.Add(Reliable(p, 0x33)); outm.Add(Reliable(p, 0xfab, 0, 0, 0x60, 0x40));
                if (!p.Racing) { Say("player " + p.Key + " (" + p.Name + ") is on the track"); ToPeer(p, outm); outm.Clear(); p.Racing = true; }
            }
            else if (ty == 0x58) { Leave(p, "left"); return; }
        }
        ToPeer(p, outm);
    }

    static void StartSession()
    {
        sessionStarted = true;
        Say("everyone is ready - starting the session with " + Members().Count + " player(s)");
        foreach (Peer x in Members())
        {
            List<byte[]> l = new List<byte[]>();
            l.Add(Reliable(x, 0x4f, 0, 0, 1)); l.Add(Reliable(x, 0xfaf, 0x30, 0x75, 0, 0)); l.Add(Reliable(x, 0xfaf, 0x20, 0x75, 0, 0));
            l.Add(Reliable(x, 0xfaf, 0xff, 0xff, 0xff, 0xff)); l.Add(Reliable(x, 0x4f, 0, 0, 0)); l.Add(Reliable(x, 0xfcb, 0, 0, 0x20, 0x41));
            ToPeer(x, l);
        }
        startAt = Now() + 1500;
    }

    static void Tick(object state)
    {
        try
        {
            lock (Gate)
            {
                long now = Now();
                List<Peer> gone = new List<Peer>();
                foreach (Peer p in Peers.Values) if (now - p.LastSeen > 20000) gone.Add(p);
                foreach (Peer p in gone) Leave(p, "timed out");
                if (startAt != 0 && now >= startAt)
                {
                    startAt = 0;
                    List<Peer> ms = Members();
                    byte[] grid = { 0, 0xff, 0xff, 0xff };
                    for (int i = 0; i < ms.Count && i < 3; i++) grid[i + 1] = (byte)ms[i].Slot;
                    foreach (Peer x in ms) ToPeer(x, Reliable(x, 0x2f, Lo(Location), Hi(Location), 0, 0, grid[0], grid[1], grid[2], grid[3]));
                }
                foreach (Peer p in Peers.Values)
                {
                    if (p.Ping46 >= 0 && now - p.Last46 > 1000)
                    {
                        List<byte[]> l = new List<byte[]>();
                        p.Ping46 = p.S; p.Last46 = now; l.Add(Msg(0x46, Lo(p.S), Hi(p.S), (byte)p.K46)); p.S++;
                        p.Ping = p.S; l.Add(Msg(0x4a, Lo(p.S), Hi(p.S), (byte)p.K46, 0x10, 0, 0, 0, 0, 0)); p.S++;
                        ToPeer(p, l);
                    }
                    List<byte[]> due = new List<byte[]>();
                    foreach (Pending q in p.Pending) if (q.Sent < now && now - q.Sent > 700) { q.Sent = now; due.Add(q.Msg); }
                    if (due.Count > 0) { if (p.Racing) p.Extra.AddRange(due); else Send(p.Mac, p.Ip, 8667, 8667, Packet(due)); }
                    if (p.Racing && now - p.LastPose >= 110)
                    {
                        p.LastPose = now;
                        byte[] m42 = Hex(Pose42); m42[4] = Lo(p.S); m42[5] = Hi(p.S); p.S++;
                        List<byte[]> l = new List<byte[]>(); l.Add(m42); l.AddRange(p.Extra); p.Extra.Clear();
                        Send(p.Mac, p.Ip, 8667, 8667, Packet(l));
                    }
                }
            }
        }
        catch (Exception e) { Say("bot tick error: " + e.Message); }
    }
}

'@

$clients = [hashtable]::Synchronized(@{})   # id -> @{ ws; lock; name }
$state = [hashtable]::Synchronized(@{ next = 1 })
$macs = [hashtable]::Synchronized(@{})      # network-card address -> player id (the switch's table)

function Write-Log($text, $color = 'Gray') { Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $text) -ForegroundColor $color }

# Listen on every name (friends arrive through Tailscale Funnel with its https name as the Host).
# Windows wants a one-time OK for that ("urlacl"); if it is missing we ask for it once (one Yes popup),
# and if that is refused we fall back to this PC only.
function Open-Listener([string]$prefix) {
    $l = [System.Net.HttpListener]::new()
    $l.Prefixes.Add($prefix)
    $l.Start()
    return $l
}
$listener = $null
try { $listener = Open-Listener "http://+:$Port/" } catch {
    if ($IsLinux -or $IsMacOS) { $listener = $null } else {
        Write-Log "First run: Windows needs a one-time OK so friends can reach the server (click Yes)." 'Yellow'
        try {
            Start-Process netsh -ArgumentList "http add urlacl url=http://+:$Port/ user=`"$env:USERDOMAIN\$env:USERNAME`"" -Verb RunAs -Wait -WindowStyle Hidden
            $listener = Open-Listener "http://+:$Port/"
        } catch { $listener = $null }
    }
}
if (-not $listener) {
    try {
        $listener = [System.Net.HttpListener]::new()
        $listener.Prefixes.Add("http://localhost:$Port/")
        $listener.Prefixes.Add("http://127.0.0.1:$Port/")
        $listener.Start()
        Write-Log "Running for this PC only (friends cannot join until Windows allows the port)." 'Yellow'
    } catch {
        Write-Log "Could not open port $Port. Is the server already running in another window?" 'Red'
        Read-Host 'Press Enter to close'
        exit 1
    }
}

# one receive loop per player, each in its own runspace
$pool = [runspacefactory]::CreateRunspacePool(1, 64)
$pool.Open()
$receiver = {
    param($id, $clients, $macs)
    $me = $clients[$id]
    $poseTo = @{}   # player id -> when we last passed them a car update from this player
    $ws = $me.ws
    $buf = New-Object byte[] 65536
    $none = [System.Threading.CancellationToken]::None
    function Send-One([byte[]]$bytes, $k, $kind) {
        $c = $clients[$k]
        if (-not $c) { return }
        [System.Threading.Monitor]::Enter($c.lock)
        try {
            if ($c.ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                $c.ws.SendAsync([ArraySegment[byte]]::new($bytes), $kind, $true, $none).GetAwaiter().GetResult()
            }
        } catch {} finally { [System.Threading.Monitor]::Exit($c.lock) }
    }
    function Send-All([byte[]]$bytes, $skip, $kind = [System.Net.WebSockets.WebSocketMessageType]::Text, [bool]$pose = $false) {
        $nowMs = [Environment]::TickCount -band 0x7fffffff
        foreach ($k in @($clients.Keys)) {
            if ($k -eq $skip) { continue }
            $c = $clients[$k]
            if (-not $c) { continue }
            # lag control: a player whose ping is over 250 ms gets car updates at most every 100 ms
            if ($pose -and $c.rtt -gt 250) {
                if ($poseTo.ContainsKey($k) -and ($nowMs - $poseTo[$k]) -lt 100) { continue }
                $poseTo[$k] = $nowMs
            }
            [System.Threading.Monitor]::Enter($c.lock)
            try {
                if ($c.ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
                    $c.ws.SendAsync([ArraySegment[byte]]::new($bytes), $kind, $true, $none).GetAwaiter().GetResult()
                }
            } catch {} finally { [System.Threading.Monitor]::Exit($c.lock) }
        }
    }
    try {
        while ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $ms = [System.IO.MemoryStream]::new()
            do {
                $r = $ws.ReceiveAsync([ArraySegment[byte]]::new($buf), $none).GetAwaiter().GetResult()
                if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw 'closed' }
                $ms.Write($buf, 0, $r.Count)
            } while (-not $r.EndOfMessage)
            if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Binary) {
                # a LAN frame: pass it on untouched (an Ethernet frame is at most ~1.5 KB)
                $frame = $ms.ToArray()
                if ($frame.Length -ge 14 -and $frame.Length -le 2048) {
                    $bin = [System.Net.WebSockets.WebSocketMessageType]::Binary
                    $macs[[BitConverter]::ToString($frame, 6, 6)] = $id        # learn: this address lives with this player
                    $dst = [BitConverter]::ToString($frame, 0, 6)
                    if ($dst -eq '02-84-00-00-00-FE') { }                     # for the bot only
                    elseif ((($frame[0] -band 1) -eq 0) -and $macs.ContainsKey($dst)) { if ($macs[$dst] -ne $id) { Send-One $frame $macs[$dst] $bin } }
                    else { Send-All $frame $id $bin }                          # everyone: broadcast, or an address not learned yet
                    [LanBot]::Feed($frame)
                }
                continue
            }
            $text = [System.Text.Encoding]::UTF8.GetString($ms.ToArray())
            if ($text.Length -lt 2 -or $text[0] -ne '{' -or $text.Length -gt 4000) { continue }
            # a ping answer: work out this player's ping (round trip, ms) and tell him
            if ($text.StartsWith('{"t":"pong"')) {
                if ($text -match '"s":(\d+)') { $me.rtt = [Math]::Max(0, ([Environment]::TickCount -band 0x7fffffff) - [int]$Matches[1]); Send-One ([System.Text.Encoding]::UTF8.GetBytes('{"t":"rtt","ms":' + $me.rtt + '}')) $id ([System.Net.WebSockets.WebSocketMessageType]::Text) }
                continue
            }
            # stamp the sender's id on the message and pass it to everyone else
            Send-All ([System.Text.Encoding]::UTF8.GetBytes('{"id":' + $id + ',' + $text.Substring(1))) $id ([System.Net.WebSockets.WebSocketMessageType]::Text) ($text.StartsWith('{"t":"pose"'))
        }
    } catch {} finally {
        $clients.Remove($id)
        foreach ($m in @($macs.Keys)) { if ($macs[$m] -eq $id) { $macs.Remove($m) } }
        Send-All ([System.Text.Encoding]::UTF8.GetBytes('{"id":' + $id + ',"t":"bye"}')) $id
        try { $ws.Dispose() } catch {}
    }
}

# the bot's frames go out to every player (each PS2 network adapter keeps only frames addressed to it)
$botPump = {
    param($clients, $state, $listener, $path, $macs)
    $pingAt = 0
    $stamp = (Get-Item $path).LastWriteTimeUtc; $check = 0
    $none = [System.Threading.CancellationToken]::None
    $bin = [System.Net.WebSockets.WebSocketMessageType]::Binary
    while ($true) {
        $line = $null
        while ([LanBot]::Log.TryDequeue([ref]$line)) { [Console]::ForegroundColor = 'Magenta'; [Console]::WriteLine(("[{0}] bot: {1}" -f (Get-Date -Format 'HH:mm:ss'), $line)); [Console]::ResetColor() }
        $f = $null
        while ([LanBot]::Outbox.TryDequeue([ref]$f)) {
            $dst = [BitConverter]::ToString($f, 0, 6)
            $only = if ((($f[0] -band 1) -eq 0) -and $macs.ContainsKey($dst)) { $macs[$dst] } else { $null }
            foreach ($k in @($clients.Keys)) {
                if ($only -ne $null -and $k -ne $only) { continue }
                $c = $clients[$k]
                if (-not $c) { continue }
                [System.Threading.Monitor]::Enter($c.lock)
                try { if ($c.ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) { $c.ws.SendAsync([ArraySegment[byte]]::new($f), $bin, $true, $none).GetAwaiter().GetResult() } } catch {} finally { [System.Threading.Monitor]::Exit($c.lock) }
            }
        }
        if ((([Environment]::TickCount -band 0x7fffffff) - $pingAt) -gt 2000) {
            $pingAt = [Environment]::TickCount -band 0x7fffffff
            $ping = [System.Text.Encoding]::UTF8.GetBytes('{"t":"ping","s":' + $pingAt + '}')
            foreach ($k in @($clients.Keys)) {
                $c = $clients[$k]
                if (-not $c) { continue }
                [System.Threading.Monitor]::Enter($c.lock)
                try { if ($c.ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) { $c.ws.SendAsync([ArraySegment[byte]]::new($ping), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $none).GetAwaiter().GetResult() } } catch {} finally { [System.Threading.Monitor]::Exit($c.lock) }
            }
        }
        Start-Sleep -Milliseconds 10
        if (++$check -ge 200) {
            $check = 0
            try { $now = (Get-Item $path).LastWriteTimeUtc } catch { $now = $stamp }
            if ($now -ne $stamp) { $state.restart = $true; [Console]::WriteLine('Server file updated - restarting with the new version...'); $listener.Stop(); return }
        }
    }
}

[LanBot]::Start($BotName)
$botPs = [powershell]::Create()
$botPs.RunspacePool = $pool
[void]$botPs.AddScript($botPump).AddArgument($clients).AddArgument($state).AddArgument($listener).AddArgument($PSCommandPath).AddArgument($macs)
$botHandle = $botPs.BeginInvoke()

Write-Log "tfatftd.xyz server running on port $Port. Leave this window open while you play. Ctrl+C stops it." 'Green'
$jobs = New-Object System.Collections.ArrayList
while ($listener.IsListening) {
    try { $ctx = $listener.GetContext() } catch { break }
    try {
        if ($ctx.Request.IsWebSocketRequest) {
            $wsctx = $ctx.AcceptWebSocketAsync([NullString]::Value).GetAwaiter().GetResult()
            $id = $state.next; $state.next = $id + 1
            $clients[$id] = @{ ws = $wsctx.WebSocket; lock = [object]::new(); rtt = 0 }
            $ps = [powershell]::Create()
            $ps.RunspacePool = $pool
            [void]$ps.AddScript($receiver).AddArgument($id).AddArgument($clients).AddArgument($macs)
            [void]$jobs.Add(@{ ps = $ps; handle = $ps.BeginInvoke() })
            Write-Log ("player {0} joined from {1} ({2} online)" -f $id, $ctx.Request.RemoteEndPoint.Address, $clients.Count) 'Cyan'
        } else {
            $body = [System.Text.Encoding]::UTF8.GetBytes("tfatftd.xyz server v0.07 - $($clients.Count) player(s) online")
            $ctx.Response.Headers.Add('Access-Control-Allow-Origin', '*')
            $ctx.Response.ContentType = 'text/plain'
            $ctx.Response.OutputStream.Write($body, 0, $body.Length)
            $ctx.Response.Close()
        }
    } catch { Write-Log "connection error: $($_.Exception.Message)" 'DarkYellow' }
    # tidy finished receive loops
    foreach ($j in @($jobs)) { if ($j.handle.IsCompleted) { try { $j.ps.EndInvoke($j.handle) } catch {}; $j.ps.Dispose(); $jobs.Remove($j) } }
}

if ($state.restart) {
    foreach ($k in @($clients.Keys)) { try { $clients[$k].ws.Abort() } catch {} }
    try { $listener.Close() } catch {}
    Start-Sleep -Milliseconds 500
    & powershell -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath -Port $Port -BotName $BotName
}
