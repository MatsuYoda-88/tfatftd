# Tokyo Drift: real cars for online players (research notes)

Goal: show each online player as their own career car (model, paint, parts), built by the game's own code,
the way the original GameSpy online mode did.

## Proven (lab 3.1-a+)

- **Car serialization works through a fake stream.**
  - `SDCustomVehicle` (vtable 0x509C00, size 0x150): Write = 0x31E0D0(car, stream), Read = 0x31DFC0(car, stream).
  - All stream primitives funnel into 0x39E4C8 (reserve), 0x39E660 (write bytes), 0x39E6C0 (read bytes).
    `mp.cpp` hooks them when a0 == 0xF00 (the fake stream) and routes bytes to host buffers.
  - The local FC RX-7 packs to 1129 bytes. `obj = 0x21DF08(0x150)` (malloc), `0x142158(obj)` (ctor), feed bytes,
    `0x31DFC0(obj, 0xF00)` gives a byte-identical copy (re-packed and compared).
- **Guest calls from the page:** `_ps2web_mp_call(fn, args, n)` runs a guest function on the next cruise frame
  (EE thread, game stack). `_ps2web_mp_probe(addr, n)` logs the next n calls of any *dispatched* function
  (virtual methods, function pointers, hooks.txt entries) with args, ra and return addresses on the stack.
  Probes are safe; hooking the factory with call_original + a hooks.txt entry froze cruise loading (lab 3.1-c).

## Original online code

- `GSNetPlayer::WriteGameData` 0x17D9F0 / `ReadGameData` 0x17DA40: 0x17DE88(netplayer) picks the driver handle
  (remote: PlayerManager slot + 0x148; local: custom manager list +0x74 id 0xDAC+idx), then the driver's
  vtable +0xCC / +0xC4 (driver class vtable 0x52B010: Write 0x1AD030, Read 0x1ACFA0) writes a bool + the car.
- GSNet_c object pointer at 0x5CB358: +0xA4 player list, +0xA8 count; net player +0x48/+0x49 slot index.

## Players

- **PlayerManager at 0x5CAB50:** slots of 0x1B4 bytes (max 2), count at +0x368 (0x5CAEB8), current slot at +0x36C.
  - Slot +0xC4 is a text/desc object, +0xCC is the name, +0x148 is the driver handle (vtable 0x529F58, +0xC = driver
    object, vtable 0x52B010, whose +0xC is the SDCustomVehicle), +0x15C is the GSRaceCar.
  - AddPlayer is 0x144420(PM, &out, idx); RemovePlayer is 0x144490.
- **GSPlayer objects:** 0x5CA020 and 0x5CA308 (stride 0x2E8), vtable at +0x248 (0x50CFC8), +0x1FC index,
  +0x2D8 slot pointer. The world load sequence (0x1BA2D8) loops over both.
- **Custom car manager:** `ld32(0x4DC554)` (= 0x5CB020).
  - +0x5C models (id 1000+, name at +0xC, e.g. 1047 "91RX7INFINI").
  - +0x64 custom cars (id, +0xC parts, +0x1C model).
  - +0x74 drivers.
  - Lookup functions: 0x319D30 (model by id), 0x319E68 (custom car by id, hooked: `_ps2web_mp_custom_override`),
    0x319EC8 (custom car by index), 0x319EE8 (driver by id).

## How cruise builds a race car (the open problem)

- Cars are **not** built through GameMode::SpawnCar 0x1A0300 / spawner 0x13D960 in cruise (those log only
  frontend scenes).
- Object factory chain: 0x251E30 tries the factories at 0x4DA888...; 0x148F28 makes "GSRACECAR" (malloc 0x1600, ctor 0x196518)
  and "GSTRAFFIC" (0xE10, ctor 0x19A510).
- Scene loader 0x252498(world, parser): sets globals world 0x4DA890 / parser 0x4DA894, reads tokens.
  `VEHICLE-MOVER-TYPE` -> 0x251FC8 creates the object named by the next token, and the object parses its own
  block (vtable +0xD8).
- The loader is a script command (0x2F6C38) run on the current script parser (global 0x5C574C).
  RunScript is 0x2F6DD0(name, archive, -1): it hashes the name (0x39C8D0) and opens the file inside an archive
  (0x399518).
- Car recipes are `<MODEL>.UPC` text (`VEHICLE { VEHICLE-MOVER-TYPE GSRACECAR { MOVER {...} VEHICLE-MOVER {...} } }`),
  stored in `%s.upc.arc` archives. The model entry fields +0x6C/+0x70/+0x74/+0x78/+0x80 are file hashes
  (parser 0x31C1DC).
- Text parser: NextToken 0x3705A8, compare 0x370EE8, expect 0x3709E8. Characters come from the stream at
  `(parser+0x258)+0x208` (vtable read at +0x5C).

## Next steps

1. Find the archive object that holds the local car's UPC (likely referenced from the GSRaceCar / its loader).
   Try RunScript("<MODEL>.UPC", thatArchive, -1) in cruise and see if a second GSRaceCar appears.
2. If that works: load the remote model's `.upc.arc` (and the body/wheel archives listed at car+0x834..0x878)
   on demand, then apply the remote SDCustomVehicle (unpacked bytes) to the new car's driver.
3. Hook the new car into the mp puppet slot (car_update already drives any car it is given).
