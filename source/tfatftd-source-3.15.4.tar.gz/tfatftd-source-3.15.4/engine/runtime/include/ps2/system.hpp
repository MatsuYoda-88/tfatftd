#pragma once

#include "cpu.hpp"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include <atomic>
namespace ps2 {
// Breadcrumbs for hang hunting in the browser: the last runtime spot (and guest pc) the emulation thread
// went into, readable from the page while the thread is stuck.
inline std::atomic<const char *> g_where{"start"};
inline std::atomic<std::uint32_t> g_where_pc{0};
inline thread_local bool t_is_emulation = false;   // set on the emulation thread
inline thread_local bool t_is_vu = false;          // set on the VU thread
inline std::atomic<const char *> g_where_vu{"idle"};
struct Where {
    const char *prev = nullptr;
    explicit Where(const char *w) {
        if (t_is_emulation) prev = g_where.exchange(w, std::memory_order_relaxed);
        else if (t_is_vu) prev = g_where_vu.exchange(w, std::memory_order_relaxed);
    }
    ~Where() {
        if (t_is_emulation) g_where.store(prev, std::memory_order_relaxed);
        else if (t_is_vu) g_where_vu.store(prev, std::memory_order_relaxed);
    }
};
// bytes the emulation thread posted to the graphics queues, per message type (hang/slowness hunting)
inline std::atomic<std::uint64_t> g_posted_bytes[16];
// time producers spent waiting for queue room: [0] vu ring us, [1] render ring us, [2] vu waits, [3] render waits, [4] waits > 100 ms
inline std::atomic<std::uint64_t> g_post_wait[5];
inline std::atomic<std::uint64_t> g_post_msgs{0}, g_post_wakes{0};
inline std::atomic<int> g_queue_batch{1};
// VU1 program stats: 0 baked calls, 1 jit calls, 2 slow lookups, 3 candidate hits, 4 baked ns (sampled x16), 5 jit ns (sampled x16), 6 jit compiles, 7 code changes
inline std::atomic<std::uint64_t> g_vu_stats[8];
// VIF unpacks: 0 fast path, 1 of those plain V4-32 copies, 2 slow path (masked / row mode / fill / V4-5), 3 slow-path elements
inline std::atomic<std::uint64_t> g_unpack_stats[4];
inline std::atomic<std::uint64_t> g_vu_gif_bytes{0};   // GIF data the VU thread sends the render thread
inline std::atomic<std::uint64_t> g_post_us{0}, g_copy_us{0}, g_post_big{0};   // emulation thread: time in post, in its memcpy; biggest message   // 1: wake the consumer per 1 MB / at sync points instead of per message
}

namespace ps2 {

inline constexpr std::uint64_t kEeClock = 294912000ull;
inline constexpr std::uint32_t kHandlerReturn = 0x00001000u;
inline constexpr std::uint32_t kIdle = 0x00001010u;

extern Cpu g_cpu;

struct Press {
    std::uint64_t frame;
    std::uint32_t frames;
    std::uint16_t buttons;
    std::uint8_t stick = 0;
};

struct Patch {
    std::uint8_t place;
    std::uint8_t bytes;
    std::uint32_t address;
    std::uint64_t value;
};

struct AxisPress {
    std::uint64_t frame;
    std::uint32_t frames;
    int axis;
    std::uint8_t value;
};

struct Options {
    bool trace_syscalls = false;
    bool trace_io = false;
    bool trace_threads = false;
    bool pal = true;
    bool widescreen = false;
    float aspect = 4.0f / 3.0f;  // display shape, width / height
    bool rate_forced = false;
    std::uint64_t max_frames = 0;
    std::string misses_path;
    std::string disc_path;
    bool trace_iop_modules = false;
    bool trace_iop_hle = false;
    std::string frames_dir;
    std::uint32_t frame_every = 60;
    std::vector<Press> presses;
    bool skip_intro = false;
    bool real_clutch = false;  // tfatftd: L1 is a real clutch pedal (see clutch.cpp)   // tfatftd: shorten the boot credit screens and tap through the movies to PRESS START
    std::vector<AxisPress> axis_presses;
    std::vector<Patch> patches;
    std::function<void()> on_vblank;
    std::function<void(const std::string &name, const std::uint8_t *code, std::size_t size)> on_vu_program;
    std::string memcard_path;
    std::function<void()> on_memcard_saved;
    std::string save_state_path;
    std::uint64_t save_state_frame = 0;
};

extern Options g_options;

struct ThreadContext {
    Reg128 r[32];
    Reg128 hi, lo;
    std::uint32_t sa, pc;
    std::uint32_t f[32];
    std::uint32_t facc, fcr31;
};

void save_context(const Cpu &c, ThreadContext &t);
void load_context(Cpu &c, const ThreadContext &t);

std::uint64_t now();
std::uint64_t hblank_cycles();
void set_budget(Cpu &c, std::int64_t cycles);
void set_ee_speed(std::uint32_t percent);   // EE overclock, 100 = a real PS2
void schedule(int event, std::uint64_t at, std::function<void()> action);
std::uint64_t scheduled_at(int event);
bool preempt(Cpu &c);

bool has_code(std::uint32_t pc);
void raise_intc(unsigned cause);
void request_reschedule();
void request_iop_sync();
void sync_iop();

bool load_elf(const std::string &path, std::uint32_t &entry);
void boot(std::uint32_t entry, const std::vector<std::string> &args);
int run();
void halt(const std::string &reason);
bool save_state(const std::string &path);
bool load_state(const std::string &path);
bool load_state(const std::uint8_t *data, std::size_t size);
bool halted();
const std::string &halt_reason();
std::uint64_t frame_count();

bool display_frame(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);

struct WindowTarget {
    enum Kind { X11, Wayland, Canvas } kind = X11;
    void *display = nullptr;
    std::uint64_t window = 0;
    void *surface = nullptr;
    const char *selector = nullptr;
    std::uint32_t width = 0, height = 0;
};

// Lets the WebGPU renderer present straight to a window or canvas instead of handing frames back.
bool attach_window(const WindowTarget &target);
void resize_window(std::uint32_t width, std::uint32_t height);
bool present_frame();
void init_graphics();
void start_render_thread();
void start_vu_thread();
void run_vu_thread();
double vu_thread_idle_ms();
void vu_record(int frames);                                  // lab: record the VU thread input for a replay bench
const std::uint8_t *vu_record_data(std::uint32_t *bytes);
std::uint64_t vu1_interpreted_calls();
std::string vu1_hot_programs();
void vu1_snap(std::uint64_t key);
std::uint8_t *vu1_snap_data(std::uint32_t *bytes, std::uint32_t *entry, int *pending);
void post_present();
enum class Rendered { idle, presented, busy };
Rendered render_pending(bool surface, const std::function<void(const std::uint32_t *rgba, std::uint32_t width, std::uint32_t height)> &copy,
                        const std::function<void()> &before_present, double budget_ms);
void wait_render_work(int timeout_ms);
// even frame spacing: a built frame can wait for the host to put it on screen at its turn
void set_defer_show(bool on);
bool frame_waiting_to_show();
bool show_waiting_frame();
std::uint32_t frames_shown();
void wake_render_thread();
bool copy_frame(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);
bool parse_press(const std::string &spec, Press &press);
bool parse_axis(const std::string &spec, AxisPress &press);
bool load_patches(const std::string &path);
double gpu_busy_ms();
void gpu_profile(std::uint64_t from, std::uint64_t to);
void set_fast_lane(int on);
void set_event_loop_thread();   // this thread gets back to its JS event loop while it waits (web: page / drawing worker)
void wait_word_async(std::atomic<std::uint32_t> *word, std::uint32_t seen, int timeout_ms);
void browser_yield();
std::uint64_t frames_run();
void set_full_rate(bool on);   // force 60 fps pacing in shops/menus (game paces them to 30)
std::uint64_t primitives_drawn();
// pad 0 is the first controller port, pad 1 the second, which starts unplugged
void set_pad_buttons(std::uint16_t pressed, int pad = 0);
void set_pad_axis(int axis, std::uint8_t value, int pad = 0);
void set_pad_pressure(int button, std::uint8_t value, int pad = 0);
void set_pad_connected(int pad, bool connected);
std::uint16_t pad_rumble(int pad = 0);
void set_audio_sink(std::function<void(const std::int16_t *samples, std::size_t frames)> sink);

bool intro_turbo();   // tfatftd: boot fast-forward running (host skips pacing, mutes audio)
void readback_stats(double out[4]);   // GPU readbacks: waited, background, bytes, ms waited
void readback_log();
}
