#pragma once
#include <cstdint>

namespace ps2::clutch {
void enable();                                            // real clutch on L1 (call at boot, game thread)
bool on();
std::uint16_t filter_buttons(int pad, std::uint16_t pressed);   // takes L1 away from the game while on
}
