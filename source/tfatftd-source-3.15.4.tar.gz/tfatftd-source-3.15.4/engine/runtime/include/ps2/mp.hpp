#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace ps2::mp {

struct Pose {
    float pos[3] = {};
    float rot[3][3] = {};   // rows: right, up, forward
    float vel[3] = {};
};

void install();
void set_puppet(std::uint32_t car, const Pose &pose);
void clear_puppet(std::uint32_t car);
bool read_car(std::uint32_t car, Pose &out);
void debug_init();

// ---- online (v0.01) ----
constexpr int kSlots = 7;
// local car's pose; world = which map it is on (1 = Wangan, 0 = elsewhere). false when no car is driving.
bool local_pose(Pose &out, int &world);
std::uint32_t player_car();   // the car the chase camera follows (0 if none)
// show remote player `slot` as a ghost car at `pose` (present=false releases the car it was using)
void set_remote(int slot, const Pose &pose, bool present);
// the game car remote player `slot` is shown with (0 = none yet, the page draws a box instead)
std::uint32_t slot_car(int slot);
// the game's view camera: rows right, up, forward, position (12 floats)
bool camera_pose(float out[12]);
void online_debug_log();   // PS2_MP_LOG: print local car / world / camera once a second
// The picture on screen lags the game by a frame or more (it is drawn from a queue). To draw ghosts over
// the right picture, the camera and local car are stamped when a frame is handed to the queue (note_frame,
// game thread) and looked up when that frame reaches the screen (note_shown, render thread).
void note_frame(std::uint32_t seq);
void note_shown(std::uint32_t seq);
// camera / local pose (16 floats: pos, rot rows, vel, world) of the frame on screen, `back` frames earlier
bool shown_camera(int back, float out[12]);
bool shown_local(int back, float out[16]);
// spawn a car of `model` (0x3736D0 index) with custom-car `id` in the current game mode (next cruise frame)
void request_spawn(int model, int id);
std::string take_log();
// research / car sync: run a guest function on the next cruise frame (EE thread), result via call_result
void queue_call(std::uint32_t fn, const std::uint32_t *args, int n);
std::uint32_t call_result(int &done);
// log the next n calls of a dispatched guest function (args, ra, return addresses on the stack)
void request_probe(std::uint32_t addr, int n);
// the fake stream (guest address 0xF00) the game's serializers write to / read from
std::vector<std::uint8_t> stream_take();
void stream_feed(const std::uint8_t *p, int n);
void force_slot_car(int slot, std::uint32_t car);
int live_cars(std::uint32_t *out, int max);
void set_load_slot(int slot, std::uint32_t handle);
void set_career_car(int id);
void set_friend_unlist(int on);
void set_friend_car(int slot, const std::uint8_t *p, int n);
void set_friend_pose(int slot, const Pose &pose, bool present);
std::uint32_t friend_built(int slot);
void refresh_friend(int slot);   // rebuild friend `slot`'s car (he just loaded back into the world)
std::vector<std::uint8_t> my_car();
std::vector<std::uint8_t> my_state();
std::uint32_t pausemap();
int pausemap_friends(float *out, int max);   // friends' pause-map arrows: {slot, cx, cy, w, h, deg, alpha} each
void camera_next();   // cycle the in-game camera view (next frame, player 1)   // the pause-menu map renderer, while it is being drawn (0 otherwise)   // my car's LAN state packet (GSRaceCar::NetWrite), refreshed every other frame
void set_friend_state(int slot, const std::uint8_t *p, int n);   // a friend's LAN state packet, applied with NetRead   // LAN: send/race the career car (-1 off, 0 first garage car, else custom id)
// make custom-car lookups (0x319E68) for `id` return `obj` (a remote player's car); obj 0 removes it
void set_custom_override(std::uint32_t id, std::uint32_t obj);   // research log lines since the last call

}
