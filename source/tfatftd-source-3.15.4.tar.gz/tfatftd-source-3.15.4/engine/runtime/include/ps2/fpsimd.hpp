#pragma once
// 4 lanes at once, bit-for-bit the same answers as fp::add / fp::mul (fpu.hpp).
// Trick: a float's bits are turned into an exact double by hand (so the PS2's "exponent 255 is just a big
// number" rule holds), the double add/mul is exact for these inputs, and the answer is chopped back to 24 bits
// the way the PS2 rounds (towards zero).
#ifdef __wasm_simd128__
#include <wasm_simd128.h>
#include <cstdint>

namespace ps2::fps {

// f32 bits (as u32 in i32x4) -> exact f64 bits, lanes 0,1 (lo) or 2,3 (hi). Exponent 0 -> signed zero.
inline v128_t widen(v128_t x, v128_t zero_mask, bool hi) {
    const v128_t e = hi ? wasm_u64x2_extend_high_u32x4(x) : wasm_u64x2_extend_low_u32x4(x);
    const v128_t z = hi ? wasm_i64x2_extend_high_i32x4(zero_mask) : wasm_i64x2_extend_low_i32x4(zero_mask);
    const v128_t sign = wasm_i64x2_shl(wasm_v128_and(e, wasm_i64x2_splat(0x80000000ll)), 32);
    const v128_t mag = wasm_i64x2_add(wasm_i64x2_shl(wasm_v128_and(e, wasm_i64x2_splat(0x7FFFFFFFll)), 29), wasm_i64x2_splat(896ll << 52));
    return wasm_v128_or(sign, wasm_v128_andnot(mag, z));
}

inline v128_t join(v128_t lo, v128_t hi) {   // low 32 bits of each i64 lane -> i32x4
    return wasm_i32x4_shuffle(lo, hi, 0, 2, 4, 6);
}
inline v128_t zero_mask(v128_t x) { return wasm_i32x4_eq(wasm_v128_and(x, wasm_i32x4_splat(0x7F800000)), wasm_i32x4_splat(0)); }

// two f64x2 answers -> PS2 floats: chop to 24 bits, too big -> max, too small -> signed zero
inline v128_t pack(v128_t blo, v128_t bhi) {
    const v128_t top = wasm_i32x4_shuffle(blo, bhi, 1, 3, 5, 7);   // sign | exponent(11) | 20 mantissa bits
    const v128_t m = wasm_v128_and(join(wasm_u64x2_shr(blo, 29), wasm_u64x2_shr(bhi, 29)), wasm_i32x4_splat(0x7FFFFF));
    const v128_t e = wasm_i32x4_sub(wasm_v128_and(wasm_u32x4_shr(top, 20), wasm_i32x4_splat(0x7FF)), wasm_i32x4_splat(896));
    const v128_t sign = wasm_v128_and(top, wasm_i32x4_splat(static_cast<int>(0x80000000u)));
    v128_t r = wasm_v128_or(wasm_i32x4_shl(e, 23), m);
    r = wasm_v128_bitselect(wasm_i32x4_splat(0x7FFFFFFF), r, wasm_i32x4_gt(e, wasm_i32x4_splat(255)));
    r = wasm_v128_andnot(r, wasm_i32x4_lt(e, wasm_i32x4_splat(1)));
    return wasm_v128_or(r, sign);
}

inline v128_t mul_slow(v128_t a, v128_t b) {
    const v128_t za = zero_mask(a), zb = zero_mask(b);
    const v128_t lo = wasm_f64x2_mul(widen(a, za, false), widen(b, zb, false));
    const v128_t hi = wasm_f64x2_mul(widen(a, za, true), widen(b, zb, true));
    return pack(lo, hi);
}

inline v128_t pow2(v128_t exp32, bool hi) {   // i32 biased double exponents -> f64x2 powers of two
    const v128_t e = hi ? wasm_u64x2_extend_high_u32x4(exp32) : wasm_u64x2_extend_low_u32x4(exp32);
    return wasm_i64x2_shl(e, 52);
}

inline v128_t add_slow(v128_t a, v128_t b) {
    const v128_t abs = wasm_i32x4_splat(0x7FFFFFFF);
    const v128_t za = zero_mask(a), zb = zero_mask(b);
    // flushed magnitudes (exponent 0 -> 0) pick which one is bigger
    const v128_t aa = wasm_v128_andnot(wasm_v128_and(a, abs), za), ba = wasm_v128_andnot(wasm_v128_and(b, abs), zb);
    const v128_t swap = wasm_u32x4_gt(ba, aa);
    const v128_t big = wasm_v128_bitselect(b, a, swap), small = wasm_v128_bitselect(a, b, swap);
    const v128_t zbig = wasm_v128_bitselect(zb, za, swap), zsmall = wasm_v128_bitselect(za, zb, swap);
    // the PS2 keeps one bit below the big number's last bit: chop the small one to steps of g = 2^(e_big-24)
    const v128_t eb = wasm_u32x4_shr(wasm_v128_and(big, abs), 23);
    const v128_t gexp = wasm_i32x4_add(eb, wasm_i32x4_splat(872)), iexp = wasm_i32x4_sub(wasm_i32x4_splat(1174), eb);
    v128_t out[2];
    for (int h = 0; h < 2; ++h) {
        const v128_t B = widen(big, zbig, h), Sm = widen(small, zsmall, h);
        const v128_t t = wasm_f64x2_mul(wasm_f64x2_trunc(wasm_f64x2_mul(Sm, pow2(iexp, h))), pow2(gexp, h));
        out[h] = wasm_f64x2_add(B, t);
    }
    return pack(out[0], out[1]);
}


// Fast path: every lane an ordinary number (exponent 26..253) -> use the chip's own float <-> double changes,
// which are exact here. Anything odd (zero, tiny, huge) goes the long way above. Same answers either way.
inline v128_t exp_in(v128_t x, int lo, int hi) {   // all-ones where lo <= exponent <= hi
    const v128_t e = wasm_u32x4_shr(wasm_v128_and(x, wasm_i32x4_splat(0x7F800000)), 23);
    return wasm_u32x4_le(wasm_i32x4_sub(e, wasm_i32x4_splat(lo)), wasm_i32x4_splat(hi - lo));
}
inline v128_t chop_join(v128_t lo, v128_t hi) {   // f64x2 x2 -> f32x4, chopped (exact demote)
    const v128_t m = wasm_i64x2_splat(static_cast<long long>(0xFFFFFFFFE0000000ull));
    const v128_t a = wasm_f32x4_demote_f64x2_zero(wasm_v128_and(lo, m)), b = wasm_f32x4_demote_f64x2_zero(wasm_v128_and(hi, m));
    return wasm_i32x4_shuffle(a, b, 0, 1, 4, 5);
}

inline v128_t mul(v128_t a, v128_t b) {
    if (wasm_i32x4_all_true(wasm_v128_and(exp_in(a, 1, 254), exp_in(b, 1, 254)))) {
        const v128_t lo = wasm_f64x2_mul(wasm_f64x2_promote_low_f32x4(a), wasm_f64x2_promote_low_f32x4(b));
        const v128_t hi = wasm_f64x2_mul(wasm_f64x2_promote_low_f32x4(wasm_i32x4_shuffle(a, a, 2, 3, 2, 3)), wasm_f64x2_promote_low_f32x4(wasm_i32x4_shuffle(b, b, 2, 3, 2, 3)));
        const v128_t r = chop_join(lo, hi);
        if (wasm_i32x4_all_true(exp_in(r, 1, 254))) return r;
    }
    return mul_slow(a, b);
}

inline v128_t add(v128_t a, v128_t b) {
    const v128_t abs = wasm_i32x4_splat(0x7FFFFFFF);
    const v128_t swap = wasm_u32x4_gt(wasm_v128_and(b, abs), wasm_v128_and(a, abs));
    const v128_t big = wasm_v128_bitselect(b, a, swap), small = wasm_v128_bitselect(a, b, swap);
    if (wasm_i32x4_all_true(wasm_v128_and(exp_in(big, 26, 253), exp_in(small, 1, 254)))) {
        // chop the small one to steps of g = 2^(e_big-24): t = trunc(small / g) * g, all exact in doubles
        const v128_t eb = wasm_v128_and(big, wasm_i32x4_splat(0x7F800000));
        const v128_t g = wasm_i32x4_sub(eb, wasm_i32x4_splat(24 << 23));
        const v128_t ig = wasm_i32x4_sub(wasm_i32x4_splat(278 << 23), eb);
        const v128_t g2 = wasm_i32x4_shuffle(g, g, 2, 3, 2, 3), ig2 = wasm_i32x4_shuffle(ig, ig, 2, 3, 2, 3);
        const v128_t s2 = wasm_i32x4_shuffle(small, small, 2, 3, 2, 3), b2 = wasm_i32x4_shuffle(big, big, 2, 3, 2, 3);
        const v128_t tlo = wasm_f64x2_mul(wasm_f64x2_trunc(wasm_f64x2_mul(wasm_f64x2_promote_low_f32x4(small), wasm_f64x2_promote_low_f32x4(ig))), wasm_f64x2_promote_low_f32x4(g));
        const v128_t thi = wasm_f64x2_mul(wasm_f64x2_trunc(wasm_f64x2_mul(wasm_f64x2_promote_low_f32x4(s2), wasm_f64x2_promote_low_f32x4(ig2))), wasm_f64x2_promote_low_f32x4(g2));
        const v128_t lo = wasm_f64x2_add(wasm_f64x2_promote_low_f32x4(big), tlo), hi = wasm_f64x2_add(wasm_f64x2_promote_low_f32x4(b2), thi);
        const v128_t r = chop_join(lo, hi);
        // an exact cancel gives +0 (like fp::add); otherwise the answer must be an ordinary number
        const v128_t ok = wasm_v128_or(exp_in(r, 1, 254), wasm_i32x4_eq(r, wasm_i32x4_splat(0)));
        if (wasm_i32x4_all_true(ok)) return r;
    }
    return add_slow(a, b);
}

}
#endif
