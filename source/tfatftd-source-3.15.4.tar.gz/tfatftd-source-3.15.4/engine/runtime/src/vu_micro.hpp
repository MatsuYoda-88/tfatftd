#pragma once
#include <string>

#include "ps2/cpu.hpp"

#include <cstdint>

namespace ps2::state {
class Stream;
}

namespace ps2::vu {

void state(ps2::state::Stream &s);

void reset();
void run(int unit, std::uint32_t address);
std::uint32_t tpc(int unit);
void set_tops(std::uint32_t top, std::uint32_t itop);
void code_changed(int unit);
std::string hot_programs();
void snap_program(std::uint64_t key);
std::uint8_t *snap_data(std::uint32_t *bytes, std::uint32_t *entry, int *pending);
Vu0Regs &regs(int unit);
std::uint64_t interpreted_calls();

}
