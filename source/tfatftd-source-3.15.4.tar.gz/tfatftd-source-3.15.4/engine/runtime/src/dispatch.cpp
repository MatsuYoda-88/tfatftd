#include "ps2/generated.hpp"
#include "ps2/system.hpp"

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <set>
#include <string>
#include <vector>
#include <unordered_map>

namespace ps2 {

namespace {

std::vector<UnitInfo> g_units;
std::vector<const UnitInfo *> g_index;
std::uint32_t g_origin = 0;
std::uint32_t g_unit_size = 1;
std::set<std::uint32_t> g_misses;
std::set<std::string> g_module_misses;
// Native hooks on guest functions (multiplayer puppets etc). Only calls that reach dispatch
// (jalr / cross-unit) are caught, which is how virtual methods are called.
std::unordered_map<std::uint32_t, HookFn> g_hooks;
constexpr std::uint32_t kNoBypass = 0xFFFFFFFFu;   // no pc is odd-aligned like this, so pc 0 can be hooked too
std::uint32_t g_bypass = kNoBypass;  // pc whose hook is skipped once (running the original from inside its hook)

constexpr std::uint32_t kModuleMagic = 0x32524E53u;

struct Instance {
    std::uint32_t base;
    const ModuleInfo *module;
};

const ModuleInfo *g_modules = nullptr;
std::uint32_t g_module_count = 0;
std::uint32_t g_module_span = 0;
std::vector<Instance> g_instances;

bool loaded_at(const ModuleInfo &m, std::uint32_t base) {
    if (m.fixed_base) {
        if (base != m.fixed_base) return false;
    } else if (ld32(base + 0x2Cu) != m.size) {
        return false;
    }
    for (std::uint32_t k = 0; k < m.check_count; ++k)
        if (ld32(base + m.checks[2 * k]) != m.checks[2 * k + 1]) return false;
    return true;
}

// The word a call checks turns with each call, so every translated code word
// is proven again within check_count calls: one word per call keeps calls
// cheap while even a one word change of the image is caught in time.
std::uint32_t g_spot_cursor = 0;

const Instance *in_place(const Instance &i) {
    static const bool full = std::getenv("PS2_WINDOW_FULL") != nullptr;
    if (full || !i.module->fixed_base) return loaded_at(*i.module, i.base) ? &i : nullptr;
    if (!i.module->check_count) return &i;
    const std::uint32_t c = g_spot_cursor++ % i.module->check_count;
    return ld32(i.base + i.module->checks[2 * c]) == i.module->checks[2 * c + 1] ? &i : nullptr;
}

Instance make_instance(std::uint32_t base, const ModuleInfo *m) {
    return {base, m};
}

const Instance *instance_for(std::uint32_t pc) {
    for (std::size_t k = 0; k < g_instances.size(); ++k) {
        const Instance &i = g_instances[k];
        if (pc - i.base >= i.module->size) continue;
        if (in_place(i)) return &i;
        g_instances.erase(g_instances.begin() + static_cast<std::ptrdiff_t>(k));
        break;
    }
    if (!g_module_count || pc >= kRamSize) return nullptr;
    // A code window rewritten by the game holds fixed base modules, each an
    // image of one content. The one whose check words are in place serves it.
    for (std::uint32_t k = 0; k < g_module_count; ++k) {
        const ModuleInfo &m = g_modules[k];
        if (m.fixed_base && pc - m.fixed_base < m.size && loaded_at(m, m.fixed_base)) {
            g_instances.push_back(make_instance(m.fixed_base, &m));
            return &g_instances.back();
        }
    }
    for (std::uint32_t at = pc & ~15u; pc - at < g_module_span; at -= 16) {
        if (ld32(at) == kModuleMagic) {
            for (std::uint32_t k = 0; k < g_module_count; ++k)
                if (pc - at < g_modules[k].size && loaded_at(g_modules[k], at)) {
                    g_instances.push_back(make_instance(at, &g_modules[k]));
                    return &g_instances.back();
                }
            return nullptr;
        }
        if (at < 16) break;
    }
    return nullptr;
}

const UnitInfo *module_unit(const ModuleInfo &m, std::uint32_t offset) {
    for (std::uint32_t k = 0; k < m.count; ++k)
        if (offset - m.units[k].base < m.units[k].size) return &m.units[k];
    return nullptr;
}

const UnitInfo *unit_for(std::uint32_t pc) {
    const std::uint32_t slot = (pc - g_origin) / g_unit_size;
    if (pc < g_origin || slot >= g_index.size()) return nullptr;
    return g_index[slot];
}

void record_miss(std::uint32_t pc) {
    if (const Instance *m = instance_for(pc)) {
        char token[96];
        std::snprintf(token, sizeof token, "%s:%x", m->module->name, pc - m->base);
        if (!g_module_misses.insert(token).second || g_options.misses_path.empty()) return;
        std::ofstream(g_options.misses_path, std::ios::app) << token << "\n";
        return;
    }
    if (!g_misses.insert(pc).second || g_options.misses_path.empty()) return;
    std::ofstream out(g_options.misses_path, std::ios::app);
    out << std::hex << pc << "\n";
}

}

void call_original(Cpu &c, std::uint32_t pc, std::uint32_t depth) {
    g_bypass = pc;
    c.pc = pc;
    dispatch(c, 0, depth);
}

void set_hook(std::uint32_t pc, HookFn fn) {
    if (fn) g_hooks[pc] = std::move(fn);
    else g_hooks.erase(pc);
}

void register_units(const UnitInfo *units, std::uint32_t count) {
    g_units.assign(units, units + count);
    if (g_units.empty()) return;
    std::sort(g_units.begin(), g_units.end(), [](const UnitInfo &a, const UnitInfo &b) { return a.base < b.base; });
    g_origin = g_units.front().base;
    g_unit_size = g_units.front().size;
    g_index.assign((g_units.back().base - g_origin) / g_unit_size + 1, nullptr);
    for (const UnitInfo &u : g_units) g_index[(u.base - g_origin) / g_unit_size] = &u;
}

void register_modules(const ModuleInfo *modules, std::uint32_t count) {
    g_modules = modules;
    g_module_count = count;
    g_instances.clear();
    for (std::uint32_t k = 0; k < count; ++k) g_module_span = std::max(g_module_span, modules[k].size);
}

bool has_code(std::uint32_t pc) {
    const UnitInfo *u = unit_for(pc);
    if (u && u->entries[(pc - u->base) >> 2] != 0) return true;
    const Instance *m = instance_for(pc);
    const UnitInfo *mu = m ? module_unit(*m->module, pc - m->base) : nullptr;
    return mu && mu->entries[(pc - m->base - mu->base) >> 2] != 0;
}

// research call tracer (lab): which functions reached through dispatch get a pointer into car A or car B
// as one of their first 4 arguments - diffing the two shows what the game does for one car and not the other
bool g_ctrace_on = false;
std::uint32_t g_ctrace_car[2] = {};
std::uint32_t g_ctrace_back = 0x10400u;   // the car's part objects sit just below it in memory
std::set<std::uint64_t> g_ctrace_seen;
void ctrace_hit(Cpu &c, std::uint32_t pc) {
    for (int a = 0; a < 4; ++a) {
        const std::uint32_t v = c.r[4 + a].w[0];
        for (int k = 0; k < 2; ++k) {
            const std::uint32_t base = g_ctrace_car[k];
            if (!base || v < base - g_ctrace_back || v >= base + 0x1800u) continue;
            const std::uint64_t key = (static_cast<std::uint64_t>(pc) << 32) | (static_cast<std::uint64_t>(k) << 31) | (static_cast<std::uint64_t>(a) << 24) | (v - base + g_ctrace_back);
            if (g_ctrace_seen.size() < 20000 && g_ctrace_seen.insert(key).second)
                std::fprintf(stderr, "[ctrace] car%c fn %08X a%d=%d ra %08X\n", k ? 'B' : 'A', pc, a, static_cast<int>(v - base), c.r[31].w[0]);
        }
    }
}

void dispatch(Cpu &c, std::uint32_t, std::uint32_t depth) {
    const std::uint32_t pc = c.pc;
    if (pc & kUnwind) return;
    if (g_ctrace_on) [[unlikely]] ctrace_hit(c, pc);
    if (t_is_emulation) g_where_pc.store(pc, std::memory_order_relaxed);
    if (pc == kHandlerReturn || pc == kIdle) return;
    if (!g_hooks.empty()) [[unlikely]] {
        auto it = pc == g_bypass ? g_hooks.end() : g_hooks.find(pc);
        if (pc == g_bypass) g_bypass = kNoBypass;
        if (it != g_hooks.end() && it->second(c)) {
            // handled natively: return to the caller - unless the hook ran game code that got cut off by a
            // thread switch / interrupt (pc has kUnwind): then that pc is where things go on, leave it alone
            if (!(c.pc & kUnwind)) c.pc = c.r[31].w[0];
            return;
        }
    }
    const UnitInfo *u = unit_for(pc);
    const std::uint16_t id = u ? u->entries[(pc - u->base) >> 2] : 0;
    if (!id) {
        if (const Instance *m = instance_for(pc)) {
            const std::uint32_t base = m->base;
            const UnitInfo *mu = module_unit(*m->module, pc - base);
            const std::uint16_t entry = mu ? mu->entries[(pc - base - mu->base) >> 2] : 0;
            if (entry) {
                c.base = base;
                mu->function(c, entry, depth);
                return;
            }
        }
        record_miss(pc);
        char reason[64];
        std::snprintf(reason, sizeof reason, "missing code at 0x%08X (ra 0x%08X)", pc, c.r[31].w[0]);
        std::fprintf(stderr, "[ee] no translated code at 0x%08X (ra 0x%08X)\n", pc, c.r[31].w[0]);
        for (int i = 1; i < 32; i += 4)
            std::fprintf(stderr, "[ee]   r%-2d %08X %08X %08X %08X\n", i, c.r[i].w[0], c.r[i + 1].w[0], c.r[i + 2].w[0], i + 3 < 32 ? c.r[i + 3].w[0] : 0u);
        halt(reason);
        c.pc = pc | kUnwind;
        return;
    }
    u->function(c, id, depth);
}

void call(Cpu &c, std::uint32_t target, std::uint32_t depth) {
    c.pc = target;
    if (depth >= kMaxDepth) return;
    dispatch(c, 0, depth);
}

void bad_entry(Cpu &c, std::uint32_t unit_base) {
    std::fprintf(stderr, "[ee] bad entry into unit 0x%08X for pc 0x%08X\n", unit_base, c.pc);
    halt("bad entry");
    c.pc |= kUnwind;
}

void stop(Cpu &c, std::uint32_t pc, const char *what) {
    std::fprintf(stderr, "[ee] stopped at 0x%08X: %s\n", pc, what);
    halt(what);
    c.pc = pc | kUnwind;
}

void probe(Cpu &c, std::uint32_t pc) {
    std::fprintf(stderr, "[probe] 0x%08X a0 %08X a1 %08X a2 %08X a3 %08X ra %08X v0 %08X\n", pc, c.r[4].w[0], c.r[5].w[0], c.r[6].w[0],
                 c.r[7].w[0], c.r[31].w[0], c.r[2].w[0]);
}

void breakpoint(Cpu &c, std::uint32_t pc) {
    std::fprintf(stderr, "[ee] break at 0x%08X (ra 0x%08X)\n", pc, c.r[31].w[0]);
}

void trap(Cpu &c, std::uint32_t pc) {
    std::fprintf(stderr, "[ee] trap at 0x%08X (ra 0x%08X)\n", pc, c.r[31].w[0]);
}

}

namespace ps2 {
void ctrace(std::uint32_t car_a, std::uint32_t car_b, bool on) {
    if (on) { g_ctrace_seen.clear(); g_ctrace_car[0] = car_a; g_ctrace_car[1] = car_b; }
    g_ctrace_on = on;
}
}
