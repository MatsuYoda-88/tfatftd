#include "dmac.hpp"
#include "gs/gif.hpp"
#include "vif.hpp"
#include "vu_micro.hpp"
#include "gs/gs.hpp"
#include "gs/queue.hpp"
#include "hw.hpp"
#include "iop/iop.hpp"
#include "iop/sif.hpp"
#include "iop/sio2.hpp"
#include "iop/spu2.hpp"
#include "ipu/ipu.hpp"
#include "ps2/clutch.hpp"
#include "ps2/disc.hpp"
#include "kernel.hpp"
#include "ps2/generated.hpp"
#include "ps2/memory.hpp"
#include "ps2/mp.hpp"
#include "ps2/state.hpp"
#include "ps2/state_request.hpp"
#include "ps2/system.hpp"
#include "ps2/video.hpp"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include <iterator>
#include <mutex>
#include <stdexcept>

namespace ps2 {
void end_intro_skip(const char *why);

Cpu g_cpu;
Options g_options;

namespace {

constexpr std::int64_t kMaxSlice = 20000;

struct Event {
    int id;
    std::uint64_t at;
    std::function<void()> action;
};

std::uint64_t g_base = 0;
std::int64_t g_given = 0;
// EE overclock: the game's clock (vsync, timers, events) keeps real PS2 time, but each emulated cycle of work costs
// only 100/percent of a cycle, so a frame fits percent/100 times more game code - slowdowns go away, timing stays right
std::atomic<std::uint32_t> g_ee_percent{100};
std::uint32_t g_ee_active = 100;
std::vector<Event> g_events;
bool g_halted = false;
std::string g_halt_reason;
std::uint64_t g_frames = 0;
std::atomic<int> g_full_rate{1};   // shops and menus at 60 too (see apply_patches below)
std::uint64_t g_iop_synced = 0;
bool g_state_request = false;
bool g_resumed = false;
std::atomic<int> g_state_operation{0};
std::mutex g_state_mutex;
std::string g_state_path;
void (*g_state_complete)(bool, bool) = nullptr;

std::atomic<std::uint32_t> g_video_options{0};
std::atomic<int> g_trace_request{0};
int g_trace_active = 0;

std::uint64_t next_event_time() {
    std::uint64_t t = UINT64_MAX;
    for (const Event &e : g_events) t = std::min(t, e.at);
    return t;
}

void run_due_events() {
    sync_iop();
    for (;;) {
        const std::uint64_t t = now();
        auto it = std::min_element(g_events.begin(), g_events.end(), [](const Event &a, const Event &b) { return a.at < b.at; });
        if (it == g_events.end() || it->at > t) return;
        auto action = std::move(it->action);
        g_events.erase(it);
        action();
    }
}

void refill(Cpu &c) {
    const std::uint64_t t = now(), next = next_event_time();
    std::int64_t slice = kMaxSlice;
    if (next != UINT64_MAX) slice = std::clamp<std::int64_t>(static_cast<std::int64_t>(next - std::min(next, t)), 1, kMaxSlice);
    set_budget(c, slice);
}

std::uint64_t frame_cycles() { return kEeClock / (g_options.pal ? 50u : 60u); }

void dump_frame() {
    std::vector<std::uint32_t> rgba;
    std::uint32_t w = 0, h = 0;
    if (!gs::display(rgba, w, h)) return;
    char name[512];
    std::snprintf(name, sizeof name, "%s/frame_%05llu.ppm", g_options.frames_dir.c_str(), static_cast<unsigned long long>(g_frames));
    std::FILE *f = std::fopen(name, "wb");
    if (!f) return;
    std::fprintf(f, "P6\n%u %u\n255\n", w, h);
    for (std::uint32_t p : rgba) {
        const std::uint8_t px[3] = {static_cast<std::uint8_t>(p), static_cast<std::uint8_t>(p >> 8), static_cast<std::uint8_t>(p >> 16)};
        std::fwrite(px, 1, 3, f);
    }
    std::fclose(f);
}

void apply_presses() {
    // Once the last press is over the pad is left alone, so the web page's live input works after a scripted start.
    std::uint64_t last = 0;
    for (const Press &p : g_options.presses) last = std::max<std::uint64_t>(last, p.frame + p.frames);
    if (!g_options.presses.empty() && g_frames <= last) {
        std::uint16_t mask = 0;
        std::uint8_t stick = 0;
        for (const Press &p : g_options.presses)
            if (g_frames >= p.frame && g_frames < p.frame + p.frames) {
                mask |= p.buttons;
                stick |= p.stick;
            }
        iop::sio2::set_buttons(0, mask);
        iop::sio2::set_axis(0, 2, (stick & 4u) ? 0x00 : (stick & 8u) ? 0xFF : 0x80);
        iop::sio2::set_axis(0, 3, (stick & 1u) ? 0x00 : (stick & 2u) ? 0xFF : 0x80);
    }
    if (!g_options.axis_presses.empty()) {
        // Outside a hold the stick rests; within one it takes the given tilt.
        std::uint8_t axes[4] = {0x80, 0x80, 0x80, 0x80};
        for (const AxisPress &p : g_options.axis_presses)
            if (g_frames >= p.frame && g_frames < p.frame + p.frames) axes[p.axis] = p.value;
        for (int a = 0; a < 4; ++a) iop::sio2::set_axis(0, a, axes[a]);
    }
}

void time_frames() {
    static const char *spec = std::getenv("PS2_TIME");
    if (!spec) return;
    static const std::uint64_t from = std::strtoull(spec, nullptr, 10);
    static const std::uint64_t count = std::strchr(spec, ',') ? std::strtoull(std::strchr(spec, ',') + 1, nullptr, 10) : 500;
    static std::chrono::steady_clock::time_point start;
    if (g_frames == from) {
        gs::flush_and_wait();
        start = std::chrono::steady_clock::now();
    } else if (g_frames == from + count) {
        gs::flush_and_wait();
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
        std::fprintf(stderr, "[time] frames %llu-%llu: %.2f ms per frame\n", static_cast<unsigned long long>(from), static_cast<unsigned long long>(from + count), ms / static_cast<double>(count));
    }
}

void apply_patches(bool boot) {
    for (const Patch &p : g_options.patches) {
        if (boot ? p.place == 1 : p.place == 0) continue;
        switch (p.bytes) {
        case 1: st8(p.address, static_cast<std::uint8_t>(p.value)); break;
        case 2: st16(p.address, static_cast<std::uint16_t>(p.value)); break;
        case 4: st32(p.address, static_cast<std::uint32_t>(p.value)); break;
        default: st64(p.address, p.value); break;
        }
    }
}

void vblank() {
    ++g_frames;
    if (g_frames >= 3000 && intro_turbo()) end_intro_skip("intro skip safety stop");
    if (static const char *td = std::getenv("PS2_TRACE_DRAWS"); td) {
        static const std::uint64_t at = std::strtoull(td, nullptr, 10);
        if (g_frames == at) gs::trace_draws(true);
        else if (g_frames == at + 1) gs::trace_draws(false);
    }
    // a capture spans 3 vblanks so at least one whole frame lands in it (the GS runs on its own thread)
    if (g_trace_request.exchange(0) == 1) { gs::trace_draws(true); g_trace_active = 3; }
    else if (g_trace_active && --g_trace_active == 0) gs::trace_draws(false);
    time_frames();
    apply_presses();
    apply_patches(false);
    // Full 60: Tokyo Drift paces each frame to a number of vblanks (0x4DC690, read at 0x33EFD8 when pacing is on):
    // 1 = 60 fps in the city, 2 = 30 fps in shops, garages and menus. Keep it at 1 everywhere.
    if (g_full_rate.load(std::memory_order_relaxed) && ld32(0x004DC690u) == 2u) st32(0x004DC690u, 1u);
    mp::online_debug_log();
    readback_log();
    // PS2_WATCH=addr,words,every: print that many floats from game memory every N frames (reverse engineering aid)
    if (static const char *w = std::getenv("PS2_WATCH"); w) {
        static unsigned addr = 0, words = 0, every = 0;
        if (!every && std::sscanf(w, "%x,%u,%u", &addr, &words, &every) != 3) every = ~0u;
        if (every && every != ~0u && g_frames % every == 0) {
            std::fprintf(stderr, "[watch] %llu:", static_cast<unsigned long long>(g_frames));
            for (unsigned i = 0; i < words; ++i) { const std::uint32_t u = ld32(addr + i * 4); float f; std::memcpy(&f, &u, 4); std::fprintf(stderr, " %.3g", f); }
            std::fprintf(stderr, "\n");
        }
    }
    if (g_options.on_vblank) g_options.on_vblank();
    iop::sio2::flush_cards();
    if (g_options.trace_iop_modules && g_frames % 25 == 0) std::fprintf(stderr, "[frame] %llu prims %llu\n", static_cast<unsigned long long>(g_frames), static_cast<unsigned long long>(gs::primitives_drawn()));
    if (!g_options.frames_dir.empty() && g_options.frame_every && g_frames % g_options.frame_every == 0) dump_frame();
    // headless runs have no presenter: drive the 4:3-menu detector here so PS2_LOG_43 shows its decisions
    static const bool log43 = std::getenv("PS2_LOG_43") != nullptr;
    if (log43) (void)gs::present_as_43();
    hw::vblank_start();
    iop::vblank(true);
    schedule(hw::kEventVblankEnd + 100, now() + hblank_cycles() * 22u, [] { iop::vblank(false); });
    kernel::on_vblank_start();
    if (g_options.max_frames && g_frames >= g_options.max_frames) halt("frame limit reached");
    if (g_options.save_state_frame && g_frames == g_options.save_state_frame) g_state_request = true;
    schedule(hw::kEventVblank, now() + frame_cycles(), vblank);
}

void idle(Cpu &c) {
    std::uint64_t next = next_event_time();
    if (next == UINT64_MAX && iop::idle()) {
        halt("deadlock: every thread waits and no event is pending");
        return;
    }
    next = std::min(next, now() + kEeClock / 2000);
    g_base = std::max(now(), next);
    g_given = 0;
    c.budget = 0;
    run_due_events();
}

}

void save_context(const Cpu &c, ThreadContext &t) {
    std::memcpy(t.r, c.r, sizeof t.r);
    t.hi = c.hi;
    t.lo = c.lo;
    t.sa = c.sa;
    t.pc = c.pc & ~kUnwind;
    std::memcpy(t.f, c.f, sizeof t.f);
    t.facc = c.facc;
    t.fcr31 = c.fcr31;
}

void load_context(Cpu &c, const ThreadContext &t) {
    std::memcpy(c.r, t.r, sizeof t.r);
    c.hi = t.hi;
    c.lo = t.lo;
    c.sa = t.sa;
    c.pc = t.pc;
    std::memcpy(c.f, t.f, sizeof t.f);
    c.facc = t.facc;
    c.fcr31 = t.fcr31;
}

std::uint64_t now() { return g_base + static_cast<std::uint64_t>((g_given - g_cpu.budget) * 100 / static_cast<std::int64_t>(g_ee_active)); }

std::uint64_t hblank_cycles() { return frame_cycles() * 2u / (g_options.pal ? 625u : 525u); }

void set_ee_speed(std::uint32_t percent) { g_ee_percent.store(std::clamp<std::uint32_t>(percent, 50u, 400u)); }
void set_budget(Cpu &c, std::int64_t cycles) {
    g_base = now();
    g_ee_active = g_ee_percent.load(std::memory_order_relaxed);   // a speed change takes effect at the next slice
    std::int64_t units = cycles * static_cast<std::int64_t>(g_ee_active) / 100;
    if (units < 1) units = 1;
    if (units > 0x7FFFFFFF) units = 0x7FFFFFFF;
    g_given = units;
    c.budget = static_cast<std::int32_t>(units);
}

void schedule(int event, std::uint64_t at, std::function<void()> action) {
    g_events.erase(std::remove_if(g_events.begin(), g_events.end(), [&](const Event &e) { return e.id == event; }), g_events.end());
    g_events.push_back({event, at, std::move(action)});
}

std::uint64_t scheduled_at(int event) {
    for (const Event &e : g_events)
        if (e.id == event) return e.at;
    return UINT64_MAX;
}

// Stall watch (hang hunting in the browser, where nothing else can look): when no new frame has come for
// 4 s while the EE keeps running, say where it is going round - the pc it loops back to, its ra and thread.
void stall_watch(const Cpu &c) {
    static std::uint32_t calls = 0;
    if (++calls & 0xFFFu) return;
    static std::uint64_t last_frame = ~0ull;
    static auto since = std::chrono::steady_clock::now(), told_at = since;
    static int told = 0;
    const auto now = std::chrono::steady_clock::now();
    if (g_frames != last_frame) { last_frame = g_frames; since = now; told = 0; return; }
    if (now - since < std::chrono::seconds(4) || told >= 12 || now - told_at < std::chrono::seconds(2)) return;
    told_at = now;
    std::fprintf(stderr, "[stall] frame %llu: ee pc 0x%08X ra 0x%08X sp 0x%08X a0 0x%08X v0 0x%08X thread %d\n", static_cast<unsigned long long>(g_frames),
                 c.pc & ~1u, c.r[31].w[0], c.r[29].w[0], c.r[4].w[0], c.r[2].w[0], kernel::current_thread());
    if (told++ == 0) dmac::dump();
}

bool preempt(Cpu &c) {
    stall_watch(c);
    run_due_events();
    refill(c);
    return g_halted || g_state_request || g_state_operation.load(std::memory_order_relaxed) || kernel::must_unwind();
}

void halt(const std::string &reason) {
    if (!g_halted) std::fprintf(stderr, "[ee] halted: %s\n", reason.c_str());
    g_halted = true;
    g_halt_reason = reason;
}

bool halted() { return g_halted; }
const std::string &halt_reason() { return g_halt_reason; }

bool request_state_operation(bool loading, const char *path, void (*complete)(bool, bool)) {
    std::lock_guard<std::mutex> lock(g_state_mutex);
    if (g_state_operation.load(std::memory_order_acquire)) return false;
    g_state_path = path;
    g_state_complete = complete;
    g_state_operation.store(loading ? 2 : 1, std::memory_order_release);
    return true;
}

void set_video_options(std::uint32_t options) { g_video_options.store(options, std::memory_order_relaxed); }
std::uint32_t video_options() { return g_video_options.load(std::memory_order_relaxed); }
void request_draw_trace() { g_trace_request.store(1); }

namespace {

constexpr char kStateMagic[8] = {'P', 'S', '2', 'S', 'T', 'A', 'T', 'E'};
constexpr std::uint32_t kStateVersion = 4;

std::function<void()> event_action(int id, std::uint64_t at) {
    if (id == hw::kEventVblank) return vblank;
    if (id == hw::kEventVblankEnd + 100) return [] { iop::vblank(false); };
    if (id >= hw::kEventCount) return kernel::alarm_action(id - hw::kEventCount);
    return hw::event_action(id, at);
}

std::atomic<std::uint32_t> g_vu_fence{0};

void sync_vu_thread() {
    if (!gs::queue::vu_active()) return;
    const std::uint32_t seen = g_vu_fence.load();
    gs::queue::vu().post(gs::queue::kVuFence, 0, 0, nullptr, 0);
    while (g_vu_fence.load() == seen) gs::queue::wait(g_vu_fence, seen);
}

void machine_state(state::Stream &s) {
    char magic[8];
    std::memcpy(magic, kStateMagic, sizeof magic);
    s.bytes(magic, sizeof magic);
    std::uint32_t version = kStateVersion;
    s.pod(version);
    if (std::memcmp(magic, kStateMagic, sizeof magic) != 0) throw std::runtime_error("not a state file");
    if (version != kStateVersion && !(s.loading() && (version == 2 || version == 3))) throw std::runtime_error("state file from another version");
    s.set_version(version);
    s.tag("ee");
    s.pod(g_cpu);
    s.bytes(g_ram, kRamSize);
    s.bytes(g_spr, kScratchpadSize);
    s.pod(g_base);
    s.pod(g_given);
    s.pod(g_frames);
    s.pod(g_iop_synced);
    s.pod(g_options.pal);
    s.vec(g_events, [&s](Event &e) {
        s.pod(e.id);
        s.pod(e.at);
        if (s.loading()) e.action = event_action(e.id, e.at);
    });
    kernel::state(s);
    hw::state(s);
    dmac::state(s);
    sync_vu_thread();
    vif::state(s);
    vu::state(s);
    ipu::state(s);
    gs::state(s);
    gif::state(s);
    iop::state(s);
    sif::state(s);
    s.tag("end");
}

}

bool save_state(const std::string &path) {
    try {
        state::Writer w;
        machine_state(w);
        std::ofstream out(path, std::ios::binary);
        out.write(reinterpret_cast<const char *>(w.out.data()), static_cast<std::streamsize>(w.out.size()));
        if (!out) throw std::runtime_error("cannot write " + path);
        std::fprintf(stderr, "[state] saved frame %llu to %s (%zu KB)\n", static_cast<unsigned long long>(g_frames), path.c_str(), w.out.size() >> 10);
        return true;
    } catch (const std::exception &e) {
        std::fprintf(stderr, "[state] cannot save: %s\n", e.what());
        return false;
    }
}

bool load_state(const std::uint8_t *data, std::size_t size) {
    try {
        state::Reader r(data, size);
        machine_state(r);
        g_resumed = true;
        std::fprintf(stderr, "[state] loaded frame %llu\n", static_cast<unsigned long long>(g_frames));
        return true;
    } catch (const std::exception &e) {
        std::fprintf(stderr, "[state] cannot load: %s\n", e.what());
        return false;
    }
}

bool load_state(const std::string &path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        std::fprintf(stderr, "[state] cannot open %s\n", path.c_str());
        return false;
    }
    const std::vector<std::uint8_t> data{std::istreambuf_iterator<char>(in), {}};
    return load_state(data.data(), data.size());
}

std::uint64_t frame_count() { return g_frames; }

bool load_elf(const std::string &path, std::uint32_t &entry) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return false;
    const std::vector<std::uint8_t> data{std::istreambuf_iterator<char>(file), {}};
    if (data.size() < 52 || std::memcmp(data.data(), "\x7f" "ELF", 4) != 0) return false;
    const auto u32 = [&](std::size_t o) { std::uint32_t v; std::memcpy(&v, data.data() + o, 4); return v; };
    const auto u16 = [&](std::size_t o) { std::uint16_t v; std::memcpy(&v, data.data() + o, 2); return v; };
    entry = u32(24);
    const std::uint32_t phoff = u32(28);
    for (std::uint32_t i = 0; i < u16(44); ++i) {
        const std::size_t ph = phoff + i * u16(42);
        if (u32(ph) != 1) continue;
        const std::uint32_t offset = u32(ph + 4), vaddr = physical(u32(ph + 8)), filesz = u32(ph + 16), memsz = u32(ph + 20);
        if (vaddr + memsz > kRamSize || offset + filesz > data.size()) return false;
        std::memcpy(g_ram + vaddr, data.data() + offset, filesz);
        watch_span(vaddr, filesz, "boot:load_exec");
        std::memset(g_ram + vaddr + filesz, 0, memsz - filesz);
    }
    return true;
}

void sync_iop() {
    const std::uint64_t t = now();
    if (t > g_iop_synced) {
        iop::run(t - g_iop_synced);
        g_iop_synced = t;
    }
    sif::pump();
}

void request_iop_sync() {
    if (g_cpu.budget > 64) set_budget(g_cpu, 64);
}

// ===== Skip intros (Tokyo Drift) =====
// Fast-forward the boot: the host skips frame pacing (and mutes audio) while intro_turbo() is true,
// and Cross + Start are tapped every 20 frames to get through the movies. Both stop the moment a
// GSPressStart_c method runs (the title screen is up), or at frame 7200 as a hard stop.
std::atomic<bool> g_intro_turbo{false};
bool intro_turbo() { return g_intro_turbo.load(std::memory_order_relaxed); }
void end_intro_skip(const char *why) {
    if (!g_intro_turbo.exchange(false)) return;
    g_options.presses.clear();
    std::fprintf(stderr, "[skip] %s at frame %llu, back to normal speed\n", why, static_cast<unsigned long long>(g_frames));
}
// which parts of the skip are on (PS2_SKIPPARTS, for testing): 1 legal screens 0 s, 2 movie skip flag, 4 fast-forward
unsigned g_skip_parts = 7;
void install_skip_intro() {
    if (const char *e = std::getenv("PS2_SKIPPARTS")) g_skip_parts = static_cast<unsigned>(std::atoi(e));
    std::fprintf(stderr, "[skip] parts %u\n", g_skip_parts);
    // The boot is a 10-step state machine (update at 0x101CB0, step number at this+0x274):
    //   0 start loading + show the legal/credit screens (LEGALARC1-5, 4 s each), 1-2 wait for them,
    //   3 another wait, 4-8 fade + load the front end, 9 create the Press Start screen.
    // Skipping = jumping the step past the waits; the real loading steps still run, no timers involved.
    // PS2_BOOTSKIP=from:to overrides which jump (default 1:4 = after step 0 has started loading).
    static unsigned from = 0, to = 0;   // no jumping by default: skipping steps 2-3 left career mode hanging
    if (const char *e = std::getenv("PS2_BOOTSKIP")) std::sscanf(e, "%u:%u", &from, &to);
    std::fprintf(stderr, "[skip] boot steps %u -> %u will be skipped\n", from, to);
    set_hook(0x00101CB0u, [](Cpu &c) {
        const std::uint32_t self = c.r[4].w[0], step = ld32(self + 0x274);
        static std::uint32_t last = ~0u;
        if (step != last) { std::fprintf(stderr, "[skip] boot step %u at frame %llu\n", step, static_cast<unsigned long long>(g_frames)); last = step; }
        if (step >= from && step < to) { st32(self + 0x274, to); std::fprintf(stderr, "[skip] jumped boot step %u -> %u\n", step, to); }
        // step 0 handed the legal screens (object at this+0x280) 4 s each (+0x14) and a fade (+0x18):
        // make that 0 s, so they still load, show and clean up the normal way, just instantly
        // step 3 plays the intro movie unless the game's own skip flag (0x4D9390) is set: set it, so the movie
        // is skipped through the game's normal path
        static int set_flag = -1;
        if ((g_skip_parts & 2u) && step == 3 && !ld32(0x004D9390u) && set_flag < 0) { st32(0x004D9390u, 1); set_flag = 1; std::fprintf(stderr, "[skip] intro movie flag set\n"); }
        // put the game's flag back the way it was once the movie step is over (it is read again later)
        if (set_flag == 1 && step >= 4) { st32(0x004D9390u, 0); set_flag = 0; std::fprintf(stderr, "[skip] intro movie flag restored\n"); }
        if ((g_skip_parts & 1u) && step == 1) {
            static bool done = false;
            if (!done) {
                done = true;
                const float show = 0.0f, fade = 0.01f;
                std::uint32_t u;
                std::memcpy(&u, &show, 4); st32(self + 0x280 + 0x14, u);
                std::memcpy(&u, &fade, 4); st32(self + 0x280 + 0x18, u);
                std::fprintf(stderr, "[skip] legal screens set to 0 s\n");
            }
        }
        return false;
    });
    // Everything before PRESS START (F&F logo, "loading...", the memory card check) needs no input, so it
    // runs flat out with the sound muted (the host skips frame pacing while intro_turbo() is true) and
    // drops back to normal speed the moment the Press Start screen runs. No timers, no button presses.
    if (g_skip_parts & 4u) g_intro_turbo.store(true);
    static const std::uint32_t kTitle[] = {0x136F48, 0x1367F0, 0x136B58, 0x136BC0, 0x136C58};
    for (std::uint32_t pc : kTitle) set_hook(pc, [](Cpu &) {
        static bool once = false;
        if (!once) { once = true; std::fprintf(stderr, "[skip] Press Start screen up at frame %llu\n", static_cast<unsigned long long>(g_frames)); }
        end_intro_skip("title screen reached");
        return false;
    });
}

void boot(std::uint32_t entry, const std::vector<std::string> &args) {
    mp::debug_init();
    if (g_options.skip_intro) install_skip_intro();
    if (g_options.real_clutch) clutch::enable();
    init_watch();
    hw::reset();
    kernel::reset();
    if (!g_options.disc_path.empty() && !disc::open(g_options.disc_path))
        std::fprintf(stderr, "[ee] cannot open disc image %s\n", g_options.disc_path.c_str());
    iop::set_trace(g_options.trace_iop_modules, g_options.trace_iop_hle);
    iop::reset();
    std::vector<std::string> guest_args = args;
    if (!guest_args.empty() && guest_args[0].find(':') == std::string::npos) {
        std::string name = guest_args[0].substr(guest_args[0].find_last_of("/\\") + 1);
        for (char &ch : name) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
        guest_args[0] = "cdrom0:\\" + name + ";1";
    }
    std::uint32_t argv = 0x00000800u, payload = argv + 4u * static_cast<std::uint32_t>(guest_args.size() + 1);
    for (std::size_t i = 0; i < guest_args.size(); ++i) {
        store<std::uint32_t>(g_ram + argv + 4 * i, payload);
        std::memcpy(g_ram + payload, guest_args[i].c_str(), guest_args[i].size() + 1);
        payload += static_cast<std::uint32_t>(guest_args[i].size() + 1);
    }
    store<std::uint32_t>(g_ram + argv + 4 * guest_args.size(), 0);
    kernel::start_main_thread(entry, 0, static_cast<std::uint32_t>(guest_args.size()), argv);
    apply_patches(true);
    schedule(hw::kEventVblank, frame_cycles(), vblank);
}

int run() {
    t_is_emulation = true;
    Cpu &c = g_cpu;
    if (!g_resumed) set_budget(c, kMaxSlice);
    while (!g_halted) {
        if (const int operation = g_state_operation.load(std::memory_order_acquire)) {
            // Request fields stay immutable until completion; never serialize
            // from the browser thread while the emulated CPUs are running.
            const bool loading = operation == 2;
            const bool success = loading ? load_state(g_state_path) : save_state(g_state_path);
            const auto complete = g_state_complete;
            g_state_operation.store(0, std::memory_order_release);
            if (complete) complete(loading, success);
            // A malformed state may have partially replaced machine memory.
            if (loading && !success) halt("Quick load failed. Reload the player to continue safely.");
            if (g_halted) break;
        }
        if (g_state_request) {
            g_state_request = false;
            save_state(g_options.save_state_path);
        }
        c.pc &= ~kUnwind;
        run_due_events();
        kernel::service(c);
        if (g_halted) break;
        if (c.pc == kIdle) {
            idle(c);
            continue;
        }
        if (c.budget <= 0) refill(c);
        dispatch(c, 0, 0);
    }
    kernel::dump();
    iop::dump();
    sif::dump();
    if (const char *peek = std::getenv("PS2_PEEK")) {
        std::uint32_t at = 0, len = 0;
        if (std::sscanf(peek, "%x,%x", &at, &len) == 2)
            for (std::uint32_t i = 0; i < len; i += 16) {
                std::fprintf(stderr, "[peek] %08X:", at + i);
                for (std::uint32_t j = 0; j < 16 && i + j < len; j += 4) std::fprintf(stderr, " %08X", ld32(at + i + j));
                std::fprintf(stderr, "\n");
            }
    }
    if (const char *path = std::getenv("PS2_DUMP")) {
        if (std::FILE *f = std::fopen(path, "wb")) {
            std::fwrite(g_ram, 1, kRamSize, f);
            std::fwrite(iop::ram_ptr(0), 1, iop::kRamSize, f);
            std::fwrite(iop::spu2::ram(), 2, 1u << 20, f);
            std::fclose(f);
        }
    }
    gs::stats();
    ipu::stats();
    if (const char *path = std::getenv("PS2_DUMP_AUDIO")) iop::spu2::dump_audio(path);
    if (std::getenv("PS2_TRACE_SPU2")) iop::spu2::dump_voices();
    dmac::stats();
    gif::stats();
    vif::stats();
    std::fprintf(stderr, "[ee] stopped after %llu frames, %llu cycles: %s\n",
                 static_cast<unsigned long long>(g_frames), static_cast<unsigned long long>(now()), g_halt_reason.c_str());
    return 0;
}

bool display_frame(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height) { return gs::display(rgba, width, height); }
bool attach_window(const WindowTarget &t) { return gs::attach_window(static_cast<int>(t.kind), t.display, t.window, t.surface, t.selector, t.width, t.height); }
void resize_window(std::uint32_t width, std::uint32_t height) { gs::resize_window(width, height); }
bool present_frame() { return gs::present(); }
void init_graphics() { gs::init(); }
void start_render_thread() { gs::start_thread(); }
void start_vu_thread() { gs::queue::vu().start(32u << 20); }

std::atomic<double> g_vu_idle_ms{0.0};

double vu_thread_idle_ms() { return g_vu_idle_ms.load(); }
std::uint64_t vu1_interpreted_calls() { return vu::interpreted_calls(); }
std::string vu1_hot_programs() { return vu::hot_programs(); }
void vu1_snap(std::uint64_t key) { vu::snap_program(key); }
std::uint8_t *vu1_snap_data(std::uint32_t *bytes, std::uint32_t *entry, int *pending) { return vu::snap_data(bytes, entry, pending); }

// lab: record exactly what the VU thread is fed (state at a vblank + every message after it, for N frames), so a
// replay bench can run the same work off-line
struct VuRecord {
    std::atomic<int> want{0};
    std::atomic<int> ready{0};
    bool active = false;
    int frames = 0, seen = 0;
    std::vector<std::uint8_t> buf;
} g_vu_rec;
void vu_rec_put(const void *p, std::size_t n) {
    const auto *b = static_cast<const std::uint8_t *>(p);
    g_vu_rec.buf.insert(g_vu_rec.buf.end(), b, b + n);
}
void vu_rec_message(const gs::queue::Header &h, const std::uint8_t *payload) {
    VuRecord &r = g_vu_rec;
    if (!r.active) {
        if (h.type != gs::queue::kVblank) return;
        ps2::state::Writer w;
        vif::state(w);
        vu::state(w);
        gif::state(w);
        r.buf.clear();
        r.buf.reserve(64u << 20);
        vu_rec_put("VUREC01\n", 8);
        const std::uint64_t n = w.out.size();
        vu_rec_put(&n, 8);
        vu_rec_put(w.out.data(), w.out.size());
        r.active = true;
        r.frames = r.want.load();
        r.seen = 0;
        r.ready.store(0);
    }
    vu_rec_put(&h, sizeof h);
    if (h.bytes) vu_rec_put(payload, h.bytes);
    if (h.type == gs::queue::kVblank && ++r.seen > r.frames) {
        r.active = false;
        r.want.store(0);
        r.ready.store(1);
    }
}
void vu_record(int frames) { g_vu_rec.ready.store(0); g_vu_rec.want.store(frames); }
const std::uint8_t *vu_record_data(std::uint32_t *bytes) {
    if (!g_vu_rec.ready.load()) { *bytes = 0; return nullptr; }
    *bytes = static_cast<std::uint32_t>(g_vu_rec.buf.size());
    return g_vu_rec.buf.data();
}

void run_vu_thread() {
    t_is_vu = true;
    gs::queue::role() = gs::queue::Role::Vu;
    gs::queue::Ring &in = gs::queue::vu();
    for (;;) {
        gs::queue::Header h;
        const std::uint8_t *payload = nullptr;
        while (in.peek(h, payload)) {
            if (g_vu_rec.want.load(std::memory_order_relaxed)) [[unlikely]] vu_rec_message(h, payload);
            switch (h.type) {
            case gs::queue::kVif1: vif::transfer(1, payload, h.arg0); break;
            case gs::queue::kVif1Write: vif::write(1, h.arg0, h.arg1); break;
            case gs::queue::kGif: gif::transfer(static_cast<int>(h.arg0), payload, h.arg1); break;
            case gs::queue::kPath3Idle: gif::vif1_idle(); break;
            case gs::queue::kGifReset:
                gif::drop_held();
                gs::queue::render().post(gs::queue::kGifReset, h.arg0, h.arg1, payload, h.bytes);
                break;
            case gs::queue::kVuReset:
                vif::reset_vu_side();
                vu::reset();
                break;
            case gs::queue::kVuFence:
                g_vu_fence.fetch_add(1);
                gs::queue::notify(g_vu_fence);
                break;
            default: gs::queue::render().post(static_cast<gs::queue::Type>(h.type), h.arg0, h.arg1, payload, h.bytes); break;
            }
            in.pop(h);
        }
        const auto start = std::chrono::steady_clock::now();
        gs::queue::render().flush();   // gathered GIF data goes out before the VU thread waits
        { ps2::Where where_("idle"); in.wait_for_work(ps2::g_queue_batch.load() ? 2 : 50); }
        g_vu_idle_ms.store(g_vu_idle_ms.load() + std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count());
    }
}
void post_present() { gs::post_present(); }

Rendered render_pending(bool surface, const std::function<void(const std::uint32_t *, std::uint32_t, std::uint32_t)> &copy,
                        const std::function<void()> &before_present, double budget_ms) {
    static std::vector<std::uint32_t> frame;
    return gs::render_pending([&](const gs::DisplayRegs &regs) {
        if (before_present) before_present();
        if (surface) {
            gs::present(regs);
            if (!copy) return;
        }
        std::uint32_t width = 0, height = 0;
        if (copy && gs::copy_frame(regs, frame, width, height)) copy(frame.data(), width, height);
    }, budget_ms);
}

void wait_render_work(int timeout_ms) { gs::queue::render().wait_for_work(timeout_ms); }
void set_defer_show(bool on) { gs::set_defer_show(on); }
bool frame_waiting_to_show() { return gs::pending_show(); }
bool show_waiting_frame() { return gs::show_pending(); }
std::uint32_t frames_shown() { return gs::show_count(); }
void wake_render_thread() { gs::queue::render().wake(); }
namespace gs::queue { void set_event_loop_thread(); void wait_word_async(std::atomic<std::uint32_t> *word, std::uint32_t seen, int timeout_ms); }
void set_event_loop_thread() { gs::queue::set_event_loop_thread(); }
void wait_word_async(std::atomic<std::uint32_t> *word, std::uint32_t seen, int timeout_ms) { gs::queue::wait_word_async(word, seen, timeout_ms); }
bool copy_frame(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height) { return gs::copy_frame(rgba, width, height); }

bool parse_press(const std::string &spec, Press &press) {
    static const char *const kNames[16] = {"select", "l3", "r3", "start", "up", "right", "down", "left",
                                           "l2", "r2", "l1", "r1", "triangle", "circle", "cross", "square"};
    const auto colon = spec.find(':');
    if (colon == std::string::npos) return false;
    press.frame = std::strtoull(spec.c_str(), nullptr, 10);
    std::string rest = spec.substr(colon + 1);
    press.frames = 6;
    const auto second = rest.find(':');
    if (second != std::string::npos) {
        press.frames = static_cast<std::uint32_t>(std::strtoul(rest.c_str() + second + 1, nullptr, 10));
        rest = rest.substr(0, second);
    }
    press.buttons = 0;
    press.stick = 0;
    static const char *const kStick[4] = {"lup", "ldown", "lleft", "lright"};
    std::size_t start = 0;
    while (start <= rest.size()) {
        const auto plus = rest.find('+', start);
        const std::string name = rest.substr(start, plus == std::string::npos ? std::string::npos : plus - start);
        int bit = -1;
        for (int i = 0; i < 16; ++i)
            if (name == kNames[i]) bit = i;
        int axis = -1;
        for (int i = 0; i < 4; ++i)
            if (name == kStick[i]) axis = i;
        if (bit < 0 && axis < 0) return false;
        if (bit >= 0) press.buttons |= static_cast<std::uint16_t>(1u << bit);
        else press.stick |= static_cast<std::uint8_t>(1u << axis);
        if (plus == std::string::npos) break;
        start = plus + 1;
    }
    return true;
}

bool load_patches(const std::string &path) {
    std::FILE *f = std::fopen(path.c_str(), "r");
    if (!f) return false;
    unsigned place = 0, bytes = 0;
    unsigned long address = 0;
    unsigned long long value = 0;
    while (std::fscanf(f, "%u %lx %u %llx", &place, &address, &bytes, &value) == 4)
        g_options.patches.push_back({static_cast<std::uint8_t>(place), static_cast<std::uint8_t>(bytes), static_cast<std::uint32_t>(address), value});
    std::fclose(f);
    return true;
}

bool parse_axis(const std::string &spec, AxisPress &press) {
    static const char *const kNames[4] = {"rx", "ry", "lx", "ly"};
    std::size_t at = 0;
    const auto field = [&](std::string &out) {
        const auto colon = spec.find(':', at);
        if (colon == std::string::npos) return false;
        out = spec.substr(at, colon - at);
        at = colon + 1;
        return true;
    };
    std::string frame, axis, value;
    if (!field(frame) || !field(axis)) return false;
    const auto tail = spec.find(':', at);
    value = spec.substr(at, tail == std::string::npos ? std::string::npos : tail - at);
    press.frame = std::strtoull(frame.c_str(), nullptr, 10);
    press.axis = -1;
    for (int i = 0; i < 4; ++i)
        if (axis == kNames[i]) press.axis = i;
    if (press.axis < 0) return false;
    press.value = static_cast<std::uint8_t>(std::strtoul(value.c_str(), nullptr, 0));
    press.frames = 6;
    if (tail != std::string::npos) press.frames = static_cast<std::uint32_t>(std::strtoul(spec.c_str() + tail + 1, nullptr, 10));
    return press.frame || press.frames;
}

double gpu_busy_ms() { return gs::gpu_busy_ms(); }
void gpu_profile(std::uint64_t from, std::uint64_t to) { gs::gpu_profile(from, to); }
void set_fast_lane(int on) { gs::set_fast_lane(on); }

#ifdef __EMSCRIPTEN__
EM_ASYNC_JS(void, ps2_browser_yield, (), {
    if (!Module.yieldPort) {
        const channel = new MessageChannel();
        Module.yieldWaiters = [];
        channel.port1.onmessage = () => Module.yieldWaiters.shift()();
        Module.yieldPort = channel.port2;
    }
    await new Promise((resolve) => { Module.yieldWaiters.push(resolve); Module.yieldPort.postMessage(0); });
});
void browser_yield() { ps2_browser_yield(); }
#else
void browser_yield() {}
#endif

std::uint64_t frames_run() { return g_frames; }
void set_full_rate(bool on) { g_full_rate.store(on ? 1 : 0); }
std::uint64_t primitives_drawn() { return gs::primitives_drawn(); }
void set_pad_buttons(std::uint16_t pressed, int pad) { iop::sio2::set_buttons(pad, pressed); }
void set_pad_axis(int axis, std::uint8_t value, int pad) { iop::sio2::set_axis(pad, axis, value); }
void set_pad_pressure(int button, std::uint8_t value, int pad) { iop::sio2::set_pressure(pad, button, value); }
void set_pad_connected(int pad, bool connected) { iop::sio2::set_connected(pad, connected); }
std::uint16_t pad_rumble(int pad) { return iop::sio2::rumble(pad); }
void set_audio_sink(std::function<void(const std::int16_t *, std::size_t)> sink) { iop::spu2::set_sink(std::move(sink)); }

}
