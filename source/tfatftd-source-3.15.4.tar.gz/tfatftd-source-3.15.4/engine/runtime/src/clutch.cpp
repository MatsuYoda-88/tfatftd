// Real clutch for Tokyo Drift (SLUS-21449): L1 becomes a clutch pedal instead of the game's canned clutch kick.
//
// Found in the game:
//   RaceCarClutch object, the player's at car + 0x948 (engine at +0x94C, gearbox at +0x950).
//   clutch + 0x80 = pedal, 1.0 = pressed in (engine free), 0.0 = let out (engaged).
//   0x0029CB30 = the auto-clutch logic that decides the pedal each physics step; it is called once, from
//   the clutch physics (0x0029D010), right before the physics reads the pedal. We hook it: let it decide,
//   then overrule it for the player's car while L1 is held (pedal in) and for a moment after (dump).
// The L1 button itself is taken away from the game while this mode is on (so its built-in kick never fires).
#include "ps2/clutch.hpp"
#include "ps2/generated.hpp"
#include "ps2/memory.hpp"
#include "ps2/mp.hpp"

#include <atomic>
#include <cstring>

namespace ps2::clutch {

namespace {
constexpr std::uint32_t kAutoClutch = 0x0029CB30u;
constexpr std::uint32_t kPedal = 0x80u;
constexpr std::uint32_t kCarClutch = 0x948u;
constexpr std::uint32_t kClutchVtable = 0x0056CCC0u;
constexpr std::uint16_t kL1 = 1u << 10;
constexpr int kDumpSteps = 12;   // physics steps the pedal is held fully out after you let go
// the jolt: for a moment after the dump the clutch grabs harder than stock (its two torque limits at +0x70/+0x74
// get multiplied), so the revs you built up slam into the rear tires and break them loose like the stock kick
constexpr std::uint32_t kGrip = 0x70u, kGrip2 = 0x74u;
constexpr int kJoltSteps = 24;
constexpr float kJolt = 2.5f;

std::atomic<bool> g_on{false}, g_held{false};
bool g_was_held = false;
int g_dump = 0, g_jolt = 0;
float g_grip = 0.0f, g_grip2 = 0.0f;
float ldf(std::uint32_t a) { const std::uint32_t u = ld32(a); float f; std::memcpy(&f, &u, 4); return f; }

void stf(std::uint32_t a, float v) { std::uint32_t u; std::memcpy(&u, &v, 4); st32(a, u); }

bool auto_clutch(Cpu &c) {
    const std::uint32_t self = c.r[4].w[0];
    const std::uint32_t ra = c.r[31].w[0];
    call_original(c, kAutoClutch, 0);
    if (c.pc & kUnwind) return true;   // cut off by a thread switch: the game finishes it itself
    const std::uint32_t car = mp::player_car();
    if (car && ld32(car + kCarClutch) == self && ld32(self + 8) == kClutchVtable) {
        const bool held = g_held.load(std::memory_order_relaxed);
        const auto end_jolt = [&] {
            if (g_jolt > 0) { stf(self + kGrip, g_grip); stf(self + kGrip2, g_grip2); }
            g_jolt = 0;
        };
        if (held) {
            stf(self + kPedal, 1.0f);       // pedal in: engine spins free, rev it up
            g_dump = 0;
            end_jolt();
        } else {
            if (g_was_held) {
                g_dump = kDumpSteps;
                end_jolt();
                g_grip = ldf(self + kGrip);
                g_grip2 = ldf(self + kGrip2);
                if (g_grip > 1.0f && g_grip < 100000.0f && g_grip2 > 1.0f && g_grip2 < 100000.0f) {
                    g_jolt = kJoltSteps;
                    stf(self + kGrip, g_grip * kJolt);
                    stf(self + kGrip2, g_grip2 * kJolt);
                }
            }
            if (g_dump > 0) { stf(self + kPedal, 0.0f); --g_dump; }   // just let go: dump it
            if (g_jolt > 0) {
                if (--g_jolt == 0) { stf(self + kGrip, g_grip); stf(self + kGrip2, g_grip2); }
                else { stf(self + kGrip, g_grip * kJolt); stf(self + kGrip2, g_grip2 * kJolt); }   // keep it on even if the game rewrites it
            }
        }
        g_was_held = held;
    }
    c.pc = ra;
    return true;
}
}

void enable() {
    if (g_on.exchange(true)) return;
    set_hook(kAutoClutch, auto_clutch);
}

bool on() { return g_on.load(std::memory_order_relaxed); }

std::uint16_t filter_buttons(int pad, std::uint16_t pressed) {
    if (pad != 0 || !on()) return pressed;
    g_held.store((pressed & kL1) != 0, std::memory_order_relaxed);
    return static_cast<std::uint16_t>(pressed & ~kL1);
}

}
