#include "ps2/system.hpp"
#include <cstdio>
#include "queue.hpp"

#include <algorithm>
#include <vector>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstring>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#include <emscripten/threading.h>
#elif defined(__linux__)
#include <ctime>
#include <linux/futex.h>
#include <sys/syscall.h>
#include <unistd.h>
#else
#include <chrono>
#include <thread>
#endif

namespace ps2::gs::queue {

namespace {

constexpr std::uint64_t align16(std::uint64_t n) { return (n + 15) & ~15ull; }

Ring g_render, g_vu;
thread_local Role g_role = Role::Emulation;

#if defined(__linux__) && !defined(__EMSCRIPTEN__)
void futex_wait(std::atomic<std::uint32_t> &word, std::uint32_t seen, int timeout_ms) {
    timespec limit{timeout_ms / 1000, static_cast<long>(timeout_ms % 1000) * 1000000L};
    syscall(SYS_futex, reinterpret_cast<std::uint32_t *>(&word), FUTEX_WAIT_PRIVATE, seen, timeout_ms < 0 ? nullptr : &limit, nullptr, 0);
}

void futex_wake(std::atomic<std::uint32_t> &word) { syscall(SYS_futex, reinterpret_cast<std::uint32_t *>(&word), FUTEX_WAKE_PRIVATE, INT_MAX, nullptr, nullptr, 0); }
#endif

}

#ifdef __EMSCRIPTEN__
// threads that must get back to their JS event loop while they wait (the page's thread, and the drawing worker:
// WebGPU callbacks and requestAnimationFrame only run there when it does)
thread_local bool g_event_loop_thread = false;
EM_ASYNC_JS(void, ps2_wait_async, (std::atomic<std::uint32_t> *word, std::uint32_t seen, int timeout_ms), {
    const result = Atomics.waitAsync(HEAP32, word >> 2, seen, timeout_ms);
    if (result.async) await result.value;
});
#endif

void set_event_loop_thread() {
#ifdef __EMSCRIPTEN__
    g_event_loop_thread = true;
#endif
}
void wait_word_async(std::atomic<std::uint32_t> *word, std::uint32_t seen, int timeout_ms) {
    if (word->load() != seen) return;
#ifdef __EMSCRIPTEN__
    if (g_event_loop_thread) ps2_wait_async(word, seen, timeout_ms);
    else emscripten_futex_wait(word, seen, timeout_ms);
#else
    (void)timeout_ms;
#endif
}

void flush_gathered();
void wait(std::atomic<std::uint32_t> &value, std::uint32_t seen) {
    flush_gathered();
#ifdef __EMSCRIPTEN__
    // timed, so a wait that never ends says what it is waiting on (hang hunting in the browser)
    for (int waited = 0; value.load() == seen; ++waited) {
        emscripten_futex_wait(&value, seen, 1000.0);
        if (waited == 3 || (waited > 3 && waited % 10 == 0))
            std::fprintf(stderr, "[wait] %s thread still waiting on %s (%p) after %d s\n", g_role == Role::Emulation ? "emulation" : g_role == Role::Vu ? "vu" : "render",
                         &value == &g_render.freed_ref() ? "render queue room" : &value == &g_vu.freed_ref() ? "vu queue room" : "a signal", static_cast<void *>(&value), waited + 1);
    }
#elif defined(__linux__)
    futex_wait(value, seen, -1);
#else
    value.wait(seen);
#endif
}

void notify(std::atomic<std::uint32_t> &value) {
#ifdef __EMSCRIPTEN__
    emscripten_futex_wake(&value, INT_MAX);
#elif defined(__linux__)
    futex_wake(value);
#else
    value.notify_all();
#endif
}

Ring &render() { return g_render; }
Ring &vu() { return g_vu; }
Role &role() { return g_role; }

Ring &outbox() {
    if (g_role == Role::Emulation && g_vu.active()) return g_vu;
    return g_render;
}

bool active() { return g_render.active(); }
bool vu_active() { return g_vu.active(); }

void post(Type type, std::uint32_t arg0, std::uint32_t arg1, const void *data, std::uint32_t bytes) { outbox().post(type, arg0, arg1, data, bytes); }

void Ring::start(std::size_t capacity) {
    buffer_ = std::make_unique<std::uint8_t[]>(capacity);
    capacity_ = capacity;
}

// The VU thread sends the render thread thousands of small GIF packets a frame (every XGKICK). Each message costs
// atomics and bookkeeping on both sides, so on that path consecutive GIF data for the same path is gathered
// (up to 256 KB) and sent as one message; anything else, or the VU thread going idle, sends it first.
namespace {
// Gathered messages for one ring, owned by the posting thread (each ring has one producer). VU thread -> render ring:
// GIF packets (same path). Emulation thread -> VU ring: GIF packets (same path) and VIF1 data (a byte stream, so
// back-to-back pieces join). The data goes straight into a spot reserved in the ring, so it is copied only once.
constexpr std::uint32_t kGatherBytes = 256u << 10;
struct Gather { Ring *ring = nullptr; std::uint64_t head = 0; std::uint8_t *at = nullptr; Type type = kGif; std::uint32_t path = 0, qwc = 0; };
thread_local Gather t_gather;
}
void Ring::flush() {
    Gather &g = t_gather;
    if (!g.qwc) return;
    if (g.type == kVif1) g.ring->publish(g.head, kVif1, g.qwc, 0, g.qwc * 16);
    else g.ring->publish(g.head, kGif, g.path, g.qwc, g.qwc * 16);
    g.qwc = 0;
    g.at = nullptr;
}
void flush_gathered() { if (t_gather.qwc) t_gather.ring->flush(); }
void Ring::post(Type type, std::uint32_t arg0, std::uint32_t arg1, const void *data, std::uint32_t bytes) {
    const bool vu_side = this == &g_render && g_role == Role::Vu;
    const bool emu_side = this == &g_vu && ps2::t_is_emulation;
    if ((vu_side || emu_side) && ps2::g_queue_batch.load(std::memory_order_relaxed)) {
        Gather &g = t_gather;
        std::uint32_t qwc = 0, path = 0;
        bool joinable = false;
        if (type == kGif && bytes == arg1 * 16u && bytes < (64u << 10)) joinable = true, qwc = arg1, path = arg0;
        else if (emu_side && type == kVif1 && bytes == arg0 * 16u && bytes < (64u << 10)) joinable = true, qwc = arg0;
        if (joinable) {
            if (vu_side) ps2::g_vu_gif_bytes.fetch_add(bytes, std::memory_order_relaxed);
            if (g.qwc && (g.ring != this || g.type != type || g.path != path || g.qwc * 16u + bytes > kGatherBytes)) flush_gathered();
            if (!g.qwc) {
                g.ring = this, g.type = type, g.path = path;
                g.head = reserve(sizeof(Header) + kGatherBytes);
                g.at = buffer_.get() + g.head % capacity_ + sizeof(Header);
            }
            std::memcpy(g.at + static_cast<std::size_t>(g.qwc) * 16, data, bytes);
            g.qwc += qwc;
            return;
        }
        flush_gathered();
    }
    post_now(type, arg0, arg1, data, bytes);
}

// Waits for room for need bytes in one piece (writing a wrap marker first when the end of the buffer is too close)
// and returns where they go. Nothing is visible to the consumer until publish().
std::uint64_t Ring::reserve(std::uint64_t need) {
    if (need > capacity_ / 2) std::fprintf(stderr, "[queue] message of %llu bytes is too big for a %zu byte queue\n", static_cast<unsigned long long>(need), capacity_);
    std::uint64_t head = head_.load(std::memory_order_relaxed);
    for (;;) {
        const std::uint64_t pos = head % capacity_;
        const std::uint64_t pad = pos + need > capacity_ ? capacity_ - pos : 0;
        const std::uint32_t seen = freed_.load(std::memory_order_acquire);
        if (head + pad + need - tail_.load(std::memory_order_acquire) <= capacity_) {
            if (pad) {
                const Header wrap{kWrap, 0, 0, 0};
                std::memcpy(buffer_.get() + pos, &wrap, sizeof wrap);
                head += pad;
                head_.store(head, std::memory_order_release);   // the consumer may skip the marker now
            }
            return head;
        }
        producer_waiting_.store(1);
        if (consumer_waiting_.exchange(0)) notify(posted_);   // a full ring needs its consumer awake
        if (head + pad + need - tail_.load() > capacity_) {
            const auto t0 = std::chrono::steady_clock::now();
            wait(freed_, seen);
            const auto us = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - t0).count();
            const int which = this == &g_vu ? 0 : 1;
            ps2::g_post_wait[which].fetch_add(static_cast<std::uint64_t>(us));
            ps2::g_post_wait[2 + which].fetch_add(1);
            if (us > 100000) {
                const std::uint64_t n = ps2::g_post_wait[4].fetch_add(1);
                if (n < 20) std::fprintf(stderr, "[queue] %s producer waited %lld ms for room (need %llu, head %llu tail %llu cap %llu, consumer waiting %u)\n",
                                         which ? "render" : "vu", static_cast<long long>(us / 1000), static_cast<unsigned long long>(need),
                                         static_cast<unsigned long long>(head), static_cast<unsigned long long>(tail_.load()), static_cast<unsigned long long>(capacity_),
                                         consumer_waiting_.load());
            }
        }
    }
}

// Writes the header at a reserved spot (its payload already in place) and lets the consumer see it.
void Ring::publish(std::uint64_t head, Type type, std::uint32_t arg0, std::uint32_t arg1, std::uint32_t bytes) {
    const std::uint64_t need = sizeof(Header) + align16(bytes);
    if (ps2::t_is_emulation && type < 16) ps2::g_posted_bytes[type].fetch_add(bytes + sizeof(Header), std::memory_order_relaxed);
    const Header h{type, bytes, arg0, arg1};
    std::memcpy(buffer_.get() + head % capacity_, &h, sizeof h);
    head_.store(head + need, std::memory_order_release);
    posted_.fetch_add(1);
    if (ps2::t_is_emulation) ps2::g_post_msgs.fetch_add(1, std::memory_order_relaxed);
    // Waking the consumer is a futex call; doing it for every small message made the two threads ping-pong
    // (Bespoke VIP: ~13 MB of small VIF1/GIF messages per frame). With batching on, wake it per MB of
    // backlog or at messages someone waits on; its own wait times out after a few ms anyway.
    const bool sync_point = type == kPresent || type == kDownload || type == kVuFence || type == kState || type == kGifReset || type == kReset || type == kSoftReset || type == kVblank;
    if (!ps2::g_queue_batch.load(std::memory_order_relaxed) || sync_point || head + need - woke_at_ >= (1u << 20)) {
        if (consumer_waiting_.exchange(0)) { notify(posted_); if (ps2::t_is_emulation) ps2::g_post_wakes.fetch_add(1, std::memory_order_relaxed); }
        woke_at_ = head + need;
    }
}

void Ring::post_now(Type type, std::uint32_t arg0, std::uint32_t arg1, const void *data, std::uint32_t bytes) {
    ps2::Where where_("queue post");
    const std::uint64_t head = reserve(sizeof(Header) + align16(bytes));
    if (bytes) std::memcpy(buffer_.get() + head % capacity_ + sizeof(Header), data, bytes);
    if (ps2::t_is_emulation && bytes > ps2::g_post_big.load(std::memory_order_relaxed)) ps2::g_post_big.store(bytes, std::memory_order_relaxed);
    publish(head, type, arg0, arg1, bytes);
}

bool Ring::peek(Header &header, const std::uint8_t *&payload) {
    std::uint64_t tail = tail_.load(std::memory_order_relaxed);
    const std::uint64_t head = head_.load(std::memory_order_acquire);
    while (tail != head) {
        const std::uint64_t pos = tail % capacity_;
        std::memcpy(&header, buffer_.get() + pos, sizeof header);
        if (header.type != kWrap) {
            payload = buffer_.get() + pos + sizeof header;
            return true;
        }
        tail += capacity_ - pos;
        tail_.store(tail, std::memory_order_release);
        // skipping the wrap marker frees the end of the buffer too: a producer may be waiting for exactly
        // that room (it padded to the end and the next message must start at the front), so tell it.
        // Without this, a full queue that wraps right then never wakes its producer: the game froze for good.
        freed_.fetch_add(1);
        if (producer_waiting_.exchange(0)) notify(freed_);
    }
    return false;
}

void Ring::pop(const Header &header) {
    tail_.store(tail_.load(std::memory_order_relaxed) + sizeof(Header) + align16(header.bytes), std::memory_order_release);
    freed_.fetch_add(1);
    if (producer_waiting_.exchange(0)) notify(freed_);
}

void Ring::wake() {
    posted_.fetch_add(1);
    if (consumer_waiting_.exchange(0)) notify(posted_);
}

void Ring::wait_for_work(int timeout_ms) {
    const std::uint32_t seen = posted_.load();
    consumer_waiting_.store(1);
    if (head_.load() != tail_.load()) {
        consumer_waiting_.store(0);
        return;
    }
#ifdef __EMSCRIPTEN__
    if (g_event_loop_thread) ps2_wait_async(&posted_, seen, timeout_ms);
    else emscripten_futex_wait(&posted_, seen, timeout_ms);
#elif defined(__linux__)
    futex_wait(posted_, seen, timeout_ms);
#else
    (void)seen;
    std::this_thread::sleep_for(std::chrono::milliseconds(std::min(timeout_ms, 1)));
#endif
}

}
