#include "dev9.hpp"

#include "hw.hpp"
#include "iop.hpp"

#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <deque>
#include <mutex>
#include <random>
#include <vector>

namespace ps2::iop::dev9 {

namespace {

// DEV9 control block in the IOP hardware page. DEV9_R_REV tells the driver what is plugged in:
// a high nibble of 3 is the expansion bay of a fat PS2 (2 would be a PCMCIA card).
constexpr std::uint32_t kCtrlBase = 0x1F801460u, kCtrlBytes = 0x20u;
constexpr std::uint32_t kRevOffset = 0x0Eu;
constexpr std::uint16_t kExpansionBay = 0x32u;

// The SPEED ASIC is mapped at IOP physical 0x10000000. Offsets below are relative to that base.
// SPEED's own registers sit in the first 0x100 bytes, the SMAP Ethernet block above them.
constexpr std::uint32_t kSpeedBase = 0x10000000u, kSpeedWindow = 0x10000u, kSpaceBytes = 0x4800u;
constexpr std::uint32_t kSmapBase = 0x100u;

constexpr std::uint32_t kSpdRev1 = 0x00, kSpdRev2 = 0x02, kSpdRev3 = 0x04, kSpdModule = 0x0E, kSpd20 = 0x20;
constexpr std::uint32_t kSpdDmaCtrl = 0x24, kSpdIntrStat = 0x28, kSpdIntrMask = 0x2A, kSpdPioDir = 0x2C, kSpdPioData = 0x2E;
constexpr std::uint16_t kSpeedRevision = 0x11, kCapsSmap = 1u << 0, kDmaToSmap = 1u << 0;

// SMAP control registers, FIFO windows and buffer descriptor tables.
constexpr std::uint32_t kBdMode = 0x102, kIntrClr = 0x128;
constexpr std::uint32_t kTxCtrl = 0x1000, kTxWrPtr = 0x1004, kTxSize = 0x1008, kTxFrameCnt = 0x100C, kTxFrameInc = 0x1010;
constexpr std::uint32_t kRxCtrl = 0x1030, kRxRdPtr = 0x1034, kRxSize = 0x1038, kRxFrameCnt = 0x103C, kRxFrameDec = 0x1040;
constexpr std::uint32_t kTxData = 0x1100, kRxData = 0x1200;
constexpr std::uint32_t kEmac3 = 0x2000, kEmac3End = 0x2070;
constexpr std::uint32_t kBdTx = 0x3000, kBdRx = 0x3200, kBdTableBytes = 0x200;
constexpr std::uint32_t kBds = 64;
constexpr std::uint8_t kFifoReset = 1u << 0, kFifoDmaEn = 1u << 1;

// Interrupt causes as reported in SPD_R_INTR_STAT.
constexpr std::uint16_t kIntrTxDnv = 1u << 2, kIntrTxEnd = 1u << 4, kIntrRxEnd = 1u << 5;
constexpr unsigned kIrqLine = 13;

// EMAC3 registers are 32 bits wide but are accessed as two halves, high half first: the write
// of the second (low) half commits the register.
constexpr std::uint32_t kMode0 = 0x2000, kTxMode0 = 0x2008, kRxMode = 0x2010, kStaCtrl = 0x205C;
constexpr std::uint32_t kRxMacIdle = 1u << 31, kTxMacIdle = 1u << 30, kSoftReset = 1u << 29;
constexpr std::uint32_t kTxGetNewPacket = 1u << 31;
constexpr std::uint32_t kRxPromiscuous = 1u << 24;
constexpr std::uint32_t kPhyOpDone = 1u << 15, kPhyRead = 1u << 12, kPhyWrite = 2u << 12;

// DP83846A PHY registers the drivers poll for the link state.
constexpr unsigned kPhyBmcr = 0x00, kPhyBmsr = 0x01, kPhySts = 0x10;
constexpr std::uint16_t kBmcrReset = 1u << 15, kBmsrLink = 1u << 2, kBmsrAnDone = 1u << 5;
constexpr std::uint16_t kStsLink = 1u << 0, kStsFullDuplex = 1u << 2, kStsAnDone = 1u << 4;   // speed bit clear = 100 Mbit

// Buffer descriptor: ctrl_stat, reserved, length, pointer (16 bits each). TX pointers address the
// TX FIFO from 0x1000, RX pointers the RX FIFO from 0x4000.
constexpr std::uint16_t kBdTxReady = 1u << 15, kBdTxGenPad = 1u << 8, kBdRxEmpty = 1u << 15;
constexpr std::uint16_t kTxFifoOrigin = 0x1000, kRxFifoOrigin = 0x4000;

constexpr std::uint32_t kFifoBytes = 16384, kFifoMask = kFifoBytes - 1;
constexpr std::size_t kMaxFrame = 1514, kMinFrame = 60, kHeader = 14, kQueueLimit = 256;

// The EEPROM is a 93C46 bit-banged through SPD_R_PIO_DATA: chip select and clock are driven
// by the IOP, one command bit per rising clock (start bit, 2 opcode bits, 6 address bits).
constexpr std::uint16_t kPioDout = 1u << 4, kPioDin = 1u << 5, kPioClock = 1u << 6, kPioSelect = 1u << 7;
enum RomState { kRomIdle, kRomOpcode, kRomAddress, kRomData };
constexpr unsigned kRomRead = 2;

struct Rom {
    RomState state = kRomIdle;
    unsigned opcode = 0, count = 0, address = 0;
    int bit = 0;
};

struct Bd {
    std::uint32_t at;
    std::uint16_t ctrl, length, pointer;
};

std::array<std::uint8_t, 6> random_mac() {
    std::random_device seed;
    std::mt19937 gen(seed());
    std::array<std::uint8_t, 6> m{0x02};   // locally administered, unicast
    for (std::size_t i = 1; i < m.size(); ++i) m[i] = static_cast<std::uint8_t>(gen());
    return m;
}

const std::array<std::uint8_t, 6> g_mac = random_mac();

std::uint8_t g_ctrl[kCtrlBytes];
std::uint8_t g_space[kSpaceBytes];
std::uint8_t g_txfifo[kFifoBytes], g_rxfifo[kFifoBytes];
std::uint16_t g_eeprom[64];
std::uint16_t g_phy[32];
std::uint16_t g_cause = 0, g_mask = 0;
std::uint32_t g_rx_wr = 0, g_txbd = 0, g_rxbd = 0;
bool g_bd_swap = false;
Rom g_rom;
std::atomic<int> g_trace{0};   // log this many more register accesses (debugging)
std::uint32_t g_tx_frames = 0;

void trace_access(const char *what, std::uint32_t off, std::uint32_t v, unsigned size) {
    if (g_trace.load(std::memory_order_relaxed) <= 0) return;
    if (off == kTxData || off == kRxData || off == kSpdPioData || off == kSpdPioDir) return;
    g_trace.fetch_sub(1, std::memory_order_relaxed);
    std::fprintf(stderr, "[dev9] %s %04X = %X (%u)\n", what, off, v, size);
}

// Frames arriving from the host wait here until the RX FIFO has room.
std::mutex g_rx_lock;
std::deque<std::vector<std::uint8_t>> g_queue;
std::atomic<bool> g_queued{false};

std::mutex g_tx_lock;
std::function<void(const std::uint8_t *, std::size_t)> g_tx;

std::uint32_t load(const std::uint8_t *base, std::uint32_t off, unsigned size) {
    std::uint32_t v = 0;
    std::memcpy(&v, base + off, size);
    return v;
}

void store(std::uint8_t *base, std::uint32_t off, std::uint32_t v, unsigned size) { std::memcpy(base + off, &v, size); }

std::uint16_t get16(std::uint32_t off) { return static_cast<std::uint16_t>(load(g_space, off, 2)); }
std::uint32_t get32(std::uint32_t off) { return load(g_space, off, 4); }
void set16(std::uint32_t off, std::uint32_t v) { store(g_space, off, v, 2); }
void set32(std::uint32_t off, std::uint32_t v) { store(g_space, off, v, 4); }

void update_irq() {
    if (g_cause & g_mask) hw::raise_interrupt(kIrqLine);
}

void irq(std::uint16_t cause) {
    g_cause |= cause;
    update_irq();
}

// ---- EEPROM ----

void rom_reset() {
    for (std::size_t i = 0; i < 3; ++i) g_eeprom[i] = static_cast<std::uint16_t>(g_mac[2 * i] | g_mac[2 * i + 1] << 8);
    g_eeprom[3] = static_cast<std::uint16_t>(g_eeprom[0] + g_eeprom[1] + g_eeprom[2]);   // checksum the drivers verify
    // The rest of the image of a stock adapter.
    g_eeprom[13] = 0x0010;
    g_eeprom[20] = 0x1000;
    g_eeprom[28] = 0x0010;
}

// Turning DIN into an output with DOUT as input starts a new EEPROM command.
void pio_dir(std::uint16_t v) {
    if ((v & 0xC0u) == 0xC0u && (v & 0x30u) == 0x20u) g_rom.state = kRomIdle;
}

void pio_write(std::uint16_t v) {
    if ((v & (kPioSelect | kPioClock)) != (kPioSelect | kPioClock)) return;
    const unsigned din = (v & kPioDin) ? 1u : 0u;
    Rom &r = g_rom;
    switch (r.state) {
    case kRomIdle:
        r = Rom{kRomOpcode};
        break;
    case kRomOpcode:
        r.opcode = r.opcode << 1 | din;
        if (++r.count == 2) {
            r.state = kRomAddress;
            r.count = 0;
            r.address = 0;
        }
        break;
    case kRomAddress:
        r.address = (r.address << 1 | din) & 63u;
        if (++r.count == 6) {
            r.state = kRomData;
            r.bit = -1;   // a read starts with a dummy zero bit
        }
        break;
    case kRomData:
        break;   // writes are not supported: the MAC address stays fixed
    }
}

// Reads shift the addressed word out MSB first, rolling over to the next word.
std::uint16_t pio_read() {
    Rom &r = g_rom;
    if (r.state != kRomData || r.opcode != kRomRead) return 0;
    std::uint16_t out = 0;
    if (r.bit >= 0 && (g_eeprom[r.address & 63u] >> (15 - r.bit) & 1u)) out = kPioDout;
    if (++r.bit == 16) {
        r.bit = 0;
        ++r.address;
    }
    return out;
}

// ---- buffer descriptors ----

Bd load_bd(std::uint32_t table, std::uint32_t index) {
    const std::uint32_t at = table + index * 8;
    return Bd{at, get16(at), get16(at + 4), get16(at + 6)};
}

bool in_bd_tables(std::uint32_t off) { return off >= kBdTx && off < kBdRx + kBdTableBytes; }

// SMAP_R_BD_MODE can make the descriptors big-endian as seen by the IOP.
std::uint32_t bd_order(std::uint32_t v) {
    return g_bd_swap ? ((v & 0xFFu) << 8 | (v >> 8 & 0xFFu)) : v;
}

// ---- transmit ----

void tx_fifo_push(std::uint32_t v) {
    const std::uint32_t wr = get32(kTxWrPtr) & kFifoMask & ~3u;
    std::memcpy(g_txfifo + wr, &v, 4);
    set32(kTxWrPtr, (wr + 4) & kFifoMask);
}

std::vector<std::uint8_t> tx_frame(const Bd &bd) {
    const std::uint32_t base = (bd.pointer - kTxFifoOrigin) & kFifoMask;
    std::vector<std::uint8_t> f(bd.length);
    for (std::uint32_t i = 0; i < bd.length; ++i) f[i] = g_txfifo[(base + i) & kFifoMask];
    if ((bd.ctrl & kBdTxGenPad) && f.size() < kMinFrame) f.resize(kMinFrame, 0);
    return f;
}

// Drivers probe for the adapter by sending a frame of counting words and expecting both RXEND
// and TXDNV in SPD_R_INTR_STAT afterwards.
bool is_probe(const Bd &bd, const std::vector<std::uint8_t> &f) {
    if (bd.length != 0x5EA || bd.pointer != kTxFifoOrigin) return false;
    for (std::uint32_t i = 0; i + 4 <= f.size(); i += 4)
        if (load(f.data(), i, 4) != i) return false;
    return true;
}

void send(const std::vector<std::uint8_t> &f) {
    ++g_tx_frames;
    std::lock_guard<std::mutex> lock(g_tx_lock);
    if (g_tx) g_tx(f.data(), f.size());
}

// Writing TxMODE0 with GNP_0 set sends every ready descriptor in turn.
void tx_process() {
    unsigned sent = 0;
    for (Bd bd = load_bd(kBdTx, g_txbd); bd.ctrl & kBdTxReady; bd = load_bd(kBdTx, g_txbd)) {
        if (bd.length > kMaxFrame) {
            std::fprintf(stderr, "[dev9] dropping oversized TX frame of %u bytes\n", bd.length);
        } else {
            const std::vector<std::uint8_t> f = tx_frame(bd);
            if (is_probe(bd, f)) irq(kIntrRxEnd | kIntrTxDnv);
            else send(f);
        }
        set16(bd.at, bd.ctrl & ~kBdTxReady);
        g_txbd = (g_txbd + 1) % kBds;
        g_space[kTxFrameCnt]--;
        ++sent;
    }
    irq(sent ? kIntrTxEnd : kIntrTxDnv);
}

// ---- receive ----

std::uint32_t rx_fifo_pop() {
    const std::uint32_t rd = get32(kRxRdPtr) & kFifoMask & ~3u;
    set32(kRxRdPtr, (rd + 4) & kFifoMask);
    return load(g_rxfifo, rd, 4);
}

std::uint32_t emac3_value(std::uint32_t reg) { return static_cast<std::uint32_t>(get16(reg)) << 16 | get16(reg + 2); }

// The EMAC3 address filter: our own address, broadcast and multicast, or everything when promiscuous.
bool accepts(const std::vector<std::uint8_t> &f) {
    if (std::equal(g_mac.begin(), g_mac.end(), f.begin() + 6)) return false;   // our own frame echoed back
    if (emac3_value(kRxMode) & kRxPromiscuous) return true;
    return (f[0] & 1u) || std::equal(g_mac.begin(), g_mac.end(), f.begin());
}

bool rx_room(std::size_t size) {
    if (g_space[kRxFrameCnt] >= kBds) return false;
    if (!(load_bd(kBdRx, g_rxbd).ctrl & kBdRxEmpty)) return false;
    const std::uint32_t used = (g_rx_wr - get32(kRxRdPtr)) & kFifoMask;
    return kFifoBytes - used > ((size + 3) & ~std::size_t{3});
}

// Copies a frame into the RX FIFO (word padded) and hands its descriptor back to the driver.
void rx_deliver(const std::vector<std::uint8_t> &f) {
    const std::uint32_t start = g_rx_wr;
    const std::uint32_t padded = static_cast<std::uint32_t>((f.size() + 3) & ~std::size_t{3});
    for (std::uint32_t i = 0; i < padded; ++i) g_rxfifo[(start + i) & kFifoMask] = i < f.size() ? f[i] : 0;
    g_rx_wr = (start + padded) & kFifoMask;
    const Bd bd = load_bd(kBdRx, g_rxbd);
    set16(bd.at + 4, static_cast<std::uint32_t>(f.size()));
    set16(bd.at + 6, kRxFifoOrigin + start);
    set16(bd.at, bd.ctrl & ~kBdRxEmpty);
    g_rxbd = (g_rxbd + 1) % kBds;
    g_space[kRxFrameCnt]++;
}

// ---- EMAC3 and PHY ----

std::uint16_t phy_read(unsigned reg) {
    std::uint16_t v = g_phy[reg];
    // A DP83846A that has finished auto negotiation with a 100 Mbit full duplex partner.
    switch (reg) {
    case 0x00: v = static_cast<std::uint16_t>((v & ~kBmcrReset) | 0x1000u | 0x2000u | 0x0100u); break;
    case 0x01: v = 0x7809u; break;
    case 0x02: v = 0x2000u; break;
    case 0x03: v = 0x5C23u; break;
    case 0x04: v = v ? v : 0x01E1u; break;
    case 0x05: v = 0x45E1u; break;
    case 0x06: v = 0x0001u; break;
    default: break;
    }
    if (reg == kPhyBmsr) v |= kBmsrLink | kBmsrAnDone;
    if (reg == kPhySts) v |= kStsLink | kStsFullDuplex | kStsAnDone;
    return v;
}

// STA_CTRL runs a management cycle on the PHY: data in the high half, register number in the low bits.
std::uint32_t phy_access(std::uint32_t v) {
    const unsigned reg = v & 0x1Fu;
    if (v & kPhyRead) v = (v & 0xFFFFu) | kPhyOpDone | static_cast<std::uint32_t>(phy_read(reg)) << 16;
    if (v & kPhyWrite) {
        v |= kPhyOpDone;
        std::uint16_t data = static_cast<std::uint16_t>(v >> 16);
        if (reg == kPhyBmcr) data &= ~kBmcrReset;   // reset completes at once
        g_phy[reg] = data;
    }
    return v;
}

void emac3_commit(std::uint32_t reg) {
    std::uint32_t v = emac3_value(reg);
    if (reg == kMode0) {
        v = (v & ~kSoftReset) | kTxMacIdle | kRxMacIdle;
        set16(kStaCtrl + 2, get16(kStaCtrl + 2) | kPhyOpDone);
    } else if (reg == kTxMode0) {
        tx_process();
        v &= ~kTxGetNewPacket;
    } else if (reg == kStaCtrl) {
        v = phy_access(v);
    }
    set16(reg, v >> 16);
    set16(reg + 2, v & 0xFFFFu);
}

void emac3_half(std::uint32_t off, std::uint32_t v) {
    set16(off, v);
    if (off & 2u) emac3_commit(off - 2);
}

void emac3_write(std::uint32_t off, std::uint32_t v, unsigned size) {
    if (size == 4) {
        emac3_half(off, v & 0xFFFFu);
        emac3_half(off + 2, v >> 16);
    } else if (size == 2) {
        emac3_half(off, v);
    } else {
        store(g_space, off, v, size);
    }
}

// ---- FIFO control ----

void tx_ctrl(std::uint32_t v) {
    if (v & kFifoReset) {
        g_txbd = 0;
        g_space[kTxFrameCnt] = 0;
        set32(kTxWrPtr, 0);
        set32(kTxSize, kFifoBytes);
    }
    g_space[kTxCtrl] = static_cast<std::uint8_t>(v & ~kFifoReset);
}

void rx_ctrl(std::uint32_t v) {
    if (v & kFifoReset) {
        g_rxbd = 0;
        g_rx_wr = 0;
        g_space[kRxFrameCnt] = 0;
        set32(kRxRdPtr, 0);
        set32(kRxSize, kFifoBytes);
    }
    g_space[kRxCtrl] = static_cast<std::uint8_t>(v & ~kFifoReset);
}

// ---- register windows ----

std::uint32_t speed_read(std::uint32_t off) {
    switch (off) {
    case kSpdRev1: return 0;
    case kSpdRev2: return kSpeedRevision;
    case kSpdRev3: return kCapsSmap;   // network only, no ATA
    case kSpdModule: return 2;
    case kSpd20: return 1;
    case kSpdIntrStat: return g_cause;
    case kSpdIntrMask: return g_mask;
    case kSpdPioData: return pio_read();
    default: return get16(off);
    }
}

void speed_write(std::uint32_t off, std::uint32_t v, unsigned size) {
    switch (off) {
    case kSpdIntrStat: g_cause = static_cast<std::uint16_t>(v); break;
    case kSpdIntrMask:
        if (g_mask != static_cast<std::uint16_t>(v)) {
            g_mask = static_cast<std::uint16_t>(v);
            update_irq();
        }
        break;
    case kSpdPioDir: pio_dir(static_cast<std::uint16_t>(v)); break;
    case kSpdPioData: pio_write(static_cast<std::uint16_t>(v)); break;
    default: store(g_space, off, v, size); break;
    }
}

std::uint32_t smap_read(std::uint32_t off, unsigned size) {
    if (off == kBdMode) return g_bd_swap ? 1u : 0u;
    if (off == kRxData && size == 4) return rx_fifo_pop();
    if (size == 2 && in_bd_tables(off)) return bd_order(get16(off));
    return load(g_space, off, size);
}

void smap_write(std::uint32_t off, std::uint32_t v, unsigned size) {
    if (size == 2 && in_bd_tables(off)) {
        set16(off, bd_order(v));
        return;
    }
    if (off >= kEmac3 && off < kEmac3End) {
        emac3_write(off, v, size);
        return;
    }
    switch (off) {
    case kBdMode: g_bd_swap = (v & 1u) != 0; break;
    case kIntrClr: g_cause = static_cast<std::uint16_t>(g_cause & ~v); break;
    case kTxFrameInc: g_space[kTxFrameCnt]++; break;
    case kRxFrameDec: g_space[kRxFrameCnt]--; break;
    case kTxCtrl: tx_ctrl(v); break;
    case kRxCtrl: rx_ctrl(v); break;
    case kTxData:
        if (size == 4) tx_fifo_push(v);
        break;
    default: store(g_space, off, v, size); break;
    }
}

std::uint32_t space_read_raw(std::uint32_t off, unsigned size) {
    if (off >= kSpaceBytes) return 0;
    if (off < kSmapBase) return size <= 2 && !(off & 1u) ? speed_read(off) : load(g_space, off, size);
    return smap_read(off, size);
}

std::uint32_t space_read(std::uint32_t off, unsigned size) {
    const std::uint32_t v = space_read_raw(off, size);
    trace_access("read ", off, v, size);
    return v;
}

void space_write(std::uint32_t off, std::uint32_t v, unsigned size) {
    trace_access("write", off, v, size);
    if (off >= kSpaceBytes) return;
    if (off < kSmapBase) {
        if (size <= 2 && !(off & 1u)) speed_write(off, v, size);
        else store(g_space, off, v, size);
        return;
    }
    smap_write(off, v, size);
}

bool in_ctrl(std::uint32_t a) { return a >= kCtrlBase && a < kCtrlBase + kCtrlBytes; }

}

void reset() {
    std::memset(g_ctrl, 0, sizeof g_ctrl);
    store(g_ctrl, kRevOffset, kExpansionBay, 2);
    std::memset(g_space, 0, sizeof g_space);
    std::memset(g_txfifo, 0, sizeof g_txfifo);
    std::memset(g_rxfifo, 0, sizeof g_rxfifo);
    std::memset(g_eeprom, 0, sizeof g_eeprom);
    std::memset(g_phy, 0, sizeof g_phy);
    rom_reset();
    g_rom = Rom{};
    g_cause = g_mask = 0;
    g_rx_wr = g_txbd = g_rxbd = 0;
    g_bd_swap = false;
    if (const char *t = std::getenv("PS2_DEV9_TRACE")) g_trace.store(std::atoi(t));
    set32(kTxSize, kFifoBytes);
    set32(kRxSize, kFifoBytes);
    for (std::uint32_t i = 0; i < kBds; ++i) set16(kBdRx + i * 8, kBdRxEmpty);
    std::lock_guard<std::mutex> lock(g_rx_lock);
    g_queue.clear();
    g_queued.store(false);
}

bool handles(std::uint32_t a) { return in_ctrl(a) || (a >= kSpeedBase && a < kSpeedBase + kSpeedWindow); }

std::uint32_t read(std::uint32_t a, unsigned size) {
    a &= ~(size - 1u);
    if (in_ctrl(a)) return load(g_ctrl, a - kCtrlBase, size);
    return space_read(a - kSpeedBase, size);
}

void write(std::uint32_t a, std::uint32_t v, unsigned size) {
    a &= ~(size - 1u);
    if (in_ctrl(a)) {
        store(g_ctrl, a - kCtrlBase, v, size);
        store(g_ctrl, kRevOffset, kExpansionBay, 2);   // the revision register is read-only
        return;
    }
    space_write(a - kSpeedBase, v, size);
}

// DMA only reaches the SMAP FIFOs when SPD_R_DMA_CTRL selects them and the FIFO has DMA enabled;
// the other target would be the ATA buffer, and no disk is fitted.
void dma(std::uint32_t madr, std::uint32_t bytes, bool to_device) {
    if (!(get16(kSpdDmaCtrl) & kDmaToSmap)) return;
    const std::uint32_t ctrl = to_device ? kTxCtrl : kRxCtrl;
    if (!(g_space[ctrl] & kFifoDmaEn)) return;
    for (std::uint32_t i = 0; i + 4 <= bytes; i += 4) {
        if (to_device) tx_fifo_push(ram32(madr + i));
        else set_ram32(madr + i, rx_fifo_pop());
    }
    g_space[ctrl] = static_cast<std::uint8_t>(g_space[ctrl] & ~kFifoDmaEn);
}

void tx_hook(std::function<void(const std::uint8_t *, std::size_t)> hook) {
    std::lock_guard<std::mutex> lock(g_tx_lock);
    g_tx = std::move(hook);
}

void rx_push(const std::uint8_t *frame, std::size_t size) {
    if (size < kHeader || size > kMaxFrame) return;
    std::lock_guard<std::mutex> lock(g_rx_lock);
    if (g_queue.size() >= kQueueLimit) return;
    g_queue.emplace_back(frame, frame + size);
    g_queued.store(true, std::memory_order_release);
}

void poll() {
    if (!g_queued.load(std::memory_order_acquire)) return;
    bool delivered = false;
    {
        std::lock_guard<std::mutex> lock(g_rx_lock);
        while (!g_queue.empty()) {
            const std::vector<std::uint8_t> &f = g_queue.front();
            if (accepts(f)) {
                if (!rx_room(f.size())) break;
                rx_deliver(f);
                delivered = true;
            }
            g_queue.pop_front();
        }
        g_queued.store(!g_queue.empty(), std::memory_order_release);
    }
    if (delivered) irq(kIntrRxEnd);
}

std::array<std::uint8_t, 6> mac() { return g_mac; }

void trace(int accesses) {
    std::fprintf(stderr, "[dev9] state: tx frames %u, txbd %u, rxbd %u, cause %X mask %X, phy0 %X\n", g_tx_frames, g_txbd, g_rxbd,
                 g_cause, g_mask, g_phy[0]);
    g_trace.store(accesses);
}

}
