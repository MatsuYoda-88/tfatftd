#include "io.hpp"
#include "kernel.hpp"

#include "ps2/disc.hpp"

#include "ps2/state.hpp"

#include <algorithm>
#include <cstdio>
#include <map>

namespace ps2::iop::io {

namespace {

constexpr int kNoEntry = -2;
constexpr int kBadFd = -9;
constexpr int kTooMany = -24;

struct File {
    std::uint32_t sector = 0;
    std::uint32_t size = 0;
    std::uint64_t position = 0;
    std::vector<std::uint8_t> memory;
    bool in_memory = false;
};

std::map<int, File> g_files;

std::string device_of(const std::string &path) {
    const auto colon = path.find(':');
    std::string d = colon == std::string::npos ? "" : path.substr(0, colon);
    for (char &ch : d) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    while (!d.empty() && std::isdigit(static_cast<unsigned char>(d.back()))) d.pop_back();
    return d;
}

int allocate() {
    for (int fd = 3; fd < 64; ++fd)
        if (!g_files.count(fd)) return fd;
    return kTooMany;
}

}

// ---- a ready-made network configuration ("Your Network Configuration file") on memory card 1, so the game's
// LAN mode finds one without the separate setup disc: Ethernet adaptor, DHCP (the page answers the DHCP).
// The attached ifc/dev files are stored encoded with the console id (ours is all zero), like the real ones.
namespace {

std::vector<std::uint8_t> netcnf_encode(const std::string &text) {
    // NETCNF: each 16-bit word rotated left by (id-derived count, 1 for an all-zero id), then inverted
    std::vector<std::uint8_t> out(text.begin(), text.end());
    std::size_t i = 0;
    for (; i + 1 < out.size(); i += 2) {
        std::uint16_t w = static_cast<std::uint16_t>(out[i] | (out[i + 1] << 8));
        w = static_cast<std::uint16_t>((w << 1) | (w >> 15));
        w ^= 0xFFFFu;
        out[i] = static_cast<std::uint8_t>(w);
        out[i + 1] = static_cast<std::uint8_t>(w >> 8);
    }
    if (i < out.size()) out[i] = static_cast<std::uint8_t>(((out[i] << 1) | (out[i] >> 7)) ^ 0xFFu);
    return out;
}

std::string lower(std::string s) {
    for (char &ch : s) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    return s;
}

}

const std::vector<std::uint8_t> *netcnf_file(const std::string &path) {
    static const std::map<std::string, std::vector<std::uint8_t>> files = [] {
        std::map<std::string, std::vector<std::uint8_t>> m;
        const std::string index = "0,1,net000.cnf,Combination1\n1,1,ifc000.dat,tfatftd.xyz LAN\n2,1,dev000.dat,Network Adaptor\n";
        m["mc0:/bwnetcnf/bwnetcnf"] = {index.begin(), index.end()};
        const std::string net = "# <Sony Computer Entertainment Inc.>/<net>\n\ninterface \"tfatftd.xyz LAN\" \"ifc000.dat\" \"dev000.dat\"\n";
        m["mc0:/bwnetcnf/net000.cnf"] = {net.begin(), net.end()};
        m["mc0:/bwnetcnf/ifc000.dat"] = netcnf_encode("# <Sony Computer Entertainment Inc.>/<ifc>\n\ntype eth\ndhcp\n");
        m["mc0:/bwnetcnf/dev000.dat"] = netcnf_encode(
            "# <Sony Computer Entertainment Inc.>/<dev>\n\ntype nic\nvendor \"SCE\"\nproduct \"Ethernet (Network Adaptor)\"\nphy_config auto\n");
        return m;
    }();
    auto it = files.find(lower(path));
    return it == files.end() ? nullptr : &it->second;
}

bool netcnf_dir(const std::string &path) {
    const std::string p = lower(path);
    return p == "mc0:/bwnetcnf" || p == "mc0:/bwnetcnf/";
}

int open(const std::string &path, std::uint32_t flags) {
    const std::string device = device_of(path);
    File f;
    if (const auto *cnf = netcnf_file(path)) {
        std::fprintf(stderr, "[io] network config %s\n", path.c_str());
        f.memory = *cnf;
        f.in_memory = true;
        f.size = static_cast<std::uint32_t>(f.memory.size());
    } else if (device == "cdrom") {
        const auto entry = disc::find(path);
        if (!entry || entry->directory) return kNoEntry;
        f.sector = entry->sector;
        f.size = entry->size;
    } else if (device == "rom") {
        std::string name = path.substr(path.find(':') + 1);
        if (name == "ROMVER") {
            const std::string text = "0220EC20060210\n";
            f.memory.assign(text.begin(), text.end());
        } else if (name == "OSDSYS" || name.rfind("rom0:", 0) == 0) {
            return kNoEntry;
        } else {
            return kNoEntry;
        }
        f.in_memory = true;
        f.size = static_cast<std::uint32_t>(f.memory.size());
    } else {
        std::fprintf(stderr, "[io] open %s (flags 0x%X) on unsupported device\n", path.c_str(), flags);
        return kNoEntry;
    }
    const int fd = allocate();
    if (fd < 0) return fd;
    g_files[fd] = std::move(f);
    if (kernel::g_trace_hle) std::fprintf(stderr, "[io] open %s -> %d\n", path.c_str(), fd);
    return fd;
}

int close(int fd) { return g_files.erase(fd) ? 0 : kBadFd; }

int read(int fd, std::uint8_t *out, std::uint32_t size) {
    auto it = g_files.find(fd);
    if (it == g_files.end()) return kBadFd;
    File &f = it->second;
    if (f.position >= f.size) return 0;
    const std::uint32_t n = static_cast<std::uint32_t>(std::min<std::uint64_t>(size, f.size - f.position));
    if (f.in_memory) {
        std::memcpy(out, f.memory.data() + f.position, n);
    } else {
        const std::uint64_t start = f.position, end = f.position + n;
        const std::uint32_t first = static_cast<std::uint32_t>(start / disc::kSector);
        const std::uint32_t last = static_cast<std::uint32_t>((end + disc::kSector - 1) / disc::kSector);
        std::vector<std::uint8_t> buffer(static_cast<std::size_t>(last - first) * disc::kSector);
        disc::read(f.sector + first, last - first, buffer.data());
        std::memcpy(out, buffer.data() + (start - static_cast<std::uint64_t>(first) * disc::kSector), n);
    }
    f.position += n;
    return static_cast<int>(n);
}

int write(int fd, const std::uint8_t *, std::uint32_t size) {
    if (fd == 1 || fd == 2) return static_cast<int>(size);
    return g_files.count(fd) ? static_cast<int>(size) : kBadFd;
}

std::int64_t seek(int fd, std::int64_t offset, int whence) {
    auto it = g_files.find(fd);
    if (it == g_files.end()) return kBadFd;
    File &f = it->second;
    std::int64_t base = whence == 1 ? static_cast<std::int64_t>(f.position) : whence == 2 ? f.size : 0;
    const std::int64_t target = std::clamp<std::int64_t>(base + offset, 0, f.size);
    f.position = static_cast<std::uint64_t>(target);
    return target;
}

bool stat(const std::string &path, std::uint32_t &mode, std::uint32_t &size) {
    if (const auto *cnf = netcnf_file(path)) { mode = 0x0017u; size = static_cast<std::uint32_t>(cnf->size()); return true; }
    if (netcnf_dir(path)) { mode = 0x0027u; size = 0; return true; }
    if (device_of(path) != "cdrom") return false;
    const auto entry = disc::find(path);
    if (!entry) return false;
    mode = entry->directory ? 0x0027u : 0x0017u;
    size = entry->size;
    return true;
}

void reset() { g_files.clear(); }

}

namespace ps2::iop::kernel {

namespace {

std::uint32_t arg(const Cpu &c, int i) { return i < 4 ? c.r[4 + i] : read32(c.r[29] + 16u + static_cast<std::uint32_t>(i - 4) * 4u); }

void def(const char *library, std::uint32_t index, const char *name, std::function<void(Cpu &)> body) {
    register_hle(library, index, [library, name, body = std::move(body)](Cpu &c) {
        trace_hle(library, name, c);
        body(c);
    });
}

}


namespace {

// ---- ioman devices: drivers (mcman's "mc", dev9...) register with AddDrv; opening "mc0:..." runs the driver's
// own IOP code, in the calling thread, exactly like the real ioman (so a driver may block on semaphores etc.)
// iop_device_t: name, type, version, desc, ops. iop_file_t: mode, unit, device, privdata (16 bytes).
// Ops table offsets: init 0, deinit 4, format 8, open C, close 10, read 14, write 18, lseek 1C, ioctl 20,
// remove 24, mkdir 28, rmdir 2C, dopen 30, dclose 34, dread 38, getstat 3C, chstat 40.
struct Device { std::uint32_t drv; };
std::map<std::string, Device> g_devices;           // "mc" -> device struct in IOP RAM
struct DevFile { std::uint32_t file; bool dir; };
std::map<int, DevFile> g_dev_files;                 // fd (>= 64) -> iop_file_t
std::vector<std::uint32_t> g_free_file_structs;
std::map<int, int> g_pending_fd;                    // thread id -> fd being opened
std::uint32_t g_open_return = 0, g_close_return = 0, g_log_return = 0;
std::map<int, std::string> g_pending_log;          // thread id -> "getstat mc0:/x" (logged with its result)
std::map<int, std::uint32_t> g_caller_ra;          // thread id -> where the ioman call returns after our return stub
constexpr int kFirstDeviceFd = 64;

int thread_id() { const Thread *t = current(); return t ? t->id : -1; }

std::uint32_t file_struct() {
    if (!g_free_file_structs.empty()) { const std::uint32_t f = g_free_file_structs.back(); g_free_file_structs.pop_back(); return f; }
    return kernel_alloc(16);
}

// "mc0:/BWNETCNF/x" -> device "mc", unit 0, path "/BWNETCNF/x"
bool split(const std::string &full, std::string &name, std::uint32_t &unit, std::size_t &rest) {
    const auto colon = full.find(':');
    if (colon == std::string::npos) return false;
    std::string d = full.substr(0, colon);
    std::size_t digits = d.size();
    while (digits > 0 && std::isdigit(static_cast<unsigned char>(d[digits - 1]))) --digits;
    name = d.substr(0, digits);
    for (char &ch : name) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    unit = digits < d.size() ? static_cast<std::uint32_t>(std::stoul(d.substr(digits))) : 0u;
    rest = colon + 1;
    return true;
}

// jump into the driver's op with the given arguments; the op returns to `ret` (or straight to our caller)
void tail_call(Cpu &c, std::uint32_t op, std::uint32_t a0, std::uint32_t a1, std::uint32_t a2, std::uint32_t a3, std::uint32_t ret) {
    c.r[4] = a0; c.r[5] = a1; c.r[6] = a2; c.r[7] = a3;
    if (ret) { g_caller_ra[thread_id()] = c.r[31]; c.r[31] = ret; }   // otherwise ra still points at the caller (the HLE stub already set pc = ra)
    c.pc = op;
    c.npc = op + 4;
}

// a return stub runs with pc = its own address (ra); continue at the ioman caller instead
void back_to_caller(Cpu &c) {
    auto it = g_caller_ra.find(thread_id());
    if (it == g_caller_ra.end()) return;
    c.pc = it->second;
    c.npc = c.pc + 4;
    c.r[31] = it->second;
    g_caller_ra.erase(it);
}

std::uint32_t op_of(std::uint32_t file, std::uint32_t offset) {
    const std::uint32_t drv = read32(file + 8), ops = read32(drv + 16);
    return read32(ops + offset);
}

// a path call (open, dopen, remove, mkdir, rmdir, getstat, chstat): true when a device took it
bool path_call(Cpu &c, std::uint32_t offset, bool opens, std::uint32_t a2, std::uint32_t a3, bool dir) {
    const std::uint32_t name_at = arg(c, 0);
    const std::string full = ram_string(name_at);
    std::string name; std::uint32_t unit = 0; std::size_t rest = 0;
    if (!split(full, name, unit, rest)) return false;
    auto it = g_devices.find(name);
    if (it == g_devices.end()) return false;
    const std::uint32_t file = file_struct();
    write32(file + 0, a2);  // mode (open flags) - harmless for the other calls
    write32(file + 4, unit);
    write32(file + 8, it->second.drv);
    write32(file + 12, 0);
    const std::uint32_t op = read32(read32(it->second.drv + 16) + offset);
    if (!op) { g_free_file_structs.push_back(file); c.r[2] = static_cast<std::uint32_t>(-48); return true; }
    std::fprintf(stderr, "[ioman] %s %s\n", opens ? (dir ? "dopen" : "open") : "call", full.c_str());
    if (opens) {
        int fd = kFirstDeviceFd;
        while (g_dev_files.count(fd)) ++fd;
        g_dev_files[fd] = {file, dir};
        g_pending_fd[thread_id()] = fd;
        tail_call(c, op, file, name_at + static_cast<std::uint32_t>(rest), a2, a3, g_open_return);
    } else {
        // the temp file struct is only needed during the call; reuse it later (drivers don't keep it)
        g_free_file_structs.push_back(file);
        g_pending_log[thread_id()] = full;
        tail_call(c, op, file, name_at + static_cast<std::uint32_t>(rest), a2, a3, g_log_return);
    }
    return true;
}

// an fd call (close, read, write, lseek, ioctl, dclose, dread): true when the fd belongs to a device
bool fd_call(Cpu &c, std::uint32_t offset, bool closes) {
    const int fd = static_cast<int>(arg(c, 0));
    auto it = g_dev_files.find(fd);
    if (it == g_dev_files.end()) return false;
    const std::uint32_t file = it->second.file;
    const std::uint32_t op = op_of(file, offset);
    if (!op) { c.r[2] = static_cast<std::uint32_t>(-48); return true; }
    if (closes) g_pending_fd[thread_id()] = fd;
    tail_call(c, op, file, arg(c, 1), arg(c, 2), arg(c, 3), closes ? g_close_return : 0);
    return true;
}

void install_devices() {
    g_devices.clear();
    g_dev_files.clear();
    g_free_file_structs.clear();
    g_pending_fd.clear();
    g_pending_log.clear();
    g_caller_ra.clear();
    // after the driver's open: >= 0 means it worked, hand back our fd
    g_open_return = hle_stub([](Cpu &c) {
        back_to_caller(c);
        const int fd = g_pending_fd[thread_id()];
        g_pending_fd.erase(thread_id());
        std::fprintf(stderr, "[ioman]   -> %d (fd %d)\n", static_cast<std::int32_t>(c.r[2]), fd);
        if (static_cast<std::int32_t>(c.r[2]) < 0) {
            g_free_file_structs.push_back(g_dev_files[fd].file);
            g_dev_files.erase(fd);
            return;
        }
        c.r[2] = static_cast<std::uint32_t>(fd);
    });
    g_log_return = hle_stub([](Cpu &c) {
        back_to_caller(c);
        std::fprintf(stderr, "[ioman]   %s -> %d\n", g_pending_log[thread_id()].c_str(), static_cast<std::int32_t>(c.r[2]));
        g_pending_log.erase(thread_id());
    });
    g_close_return = hle_stub([](Cpu &c) {
        back_to_caller(c);
        const int fd = g_pending_fd[thread_id()];
        g_pending_fd.erase(thread_id());
        auto it = g_dev_files.find(fd);
        if (it != g_dev_files.end()) { g_free_file_structs.push_back(it->second.file); g_dev_files.erase(it); }
        (void)c;
    });
    def("ioman", 20, "AddDrv", [](Cpu &c) {
        const std::uint32_t drv = arg(c, 0);
        std::string name = ram_string(read32(drv));
        for (char &ch : name) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        std::fprintf(stderr, "[iop] AddDrv %s\n", name.c_str());
        g_devices[name] = {drv};
        // the driver's init(device)
        const std::uint32_t init = read32(read32(drv + 16));
        if (init) tail_call(c, init, drv, 0, 0, 0, 0);
        else c.r[2] = 0;
    });
    def("ioman", 21, "DelDrv", [](Cpu &c) {
        std::string name = ram_string(arg(c, 0));
        for (char &ch : name) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        g_devices.erase(name);
        c.r[2] = 0;
    });
    def("ioman", 9, "ioctl", [](Cpu &c) { if (!fd_call(c, 0x20, false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 10, "remove", [](Cpu &c) { if (!path_call(c, 0x24, false, 0, 0, false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 11, "mkdir", [](Cpu &c) { if (!path_call(c, 0x28, false, arg(c, 1), 0, false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 12, "rmdir", [](Cpu &c) { if (!path_call(c, 0x2C, false, 0, 0, false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 13, "dopen", [](Cpu &c) { if (!path_call(c, 0x30, true, 0, 0, true)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 14, "dclose", [](Cpu &c) { if (!fd_call(c, 0x34, true)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 15, "dread", [](Cpu &c) { if (!fd_call(c, 0x38, false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    def("ioman", 17, "chstat", [](Cpu &c) { if (!path_call(c, 0x40, false, arg(c, 1), arg(c, 2), false)) c.r[2] = static_cast<std::uint32_t>(-1); });
    for (std::uint32_t i : {25u, 27u, 31u})
        def("ioman", i, "ioman", [](Cpu &c) { c.r[2] = static_cast<std::uint32_t>(-1); });
}

}

void install_io() {
    io::reset();
    register_hle_library("ioman", 0x0104);
    def("ioman", 4, "open", [](Cpu &c) {
        if ((arg(c, 1) & 3u) <= 1u && io::netcnf_file(ram_string(arg(c, 0)))) {
            c.r[2] = static_cast<std::uint32_t>(io::open(ram_string(arg(c, 0)), arg(c, 1)));
            return;
        }
        if (path_call(c, 0x0C, true, arg(c, 1), 0, false)) return;
        c.r[2] = static_cast<std::uint32_t>(io::open(ram_string(arg(c, 0)), arg(c, 1)));
    });
    def("ioman", 5, "close", [](Cpu &c) { if (!fd_call(c, 0x10, true)) c.r[2] = static_cast<std::uint32_t>(io::close(static_cast<int>(arg(c, 0)))); });
    def("ioman", 6, "read", [](Cpu &c) {
        if (fd_call(c, 0x14, false)) return;
        std::vector<std::uint8_t> buffer(arg(c, 2));
        const int n = io::read(static_cast<int>(arg(c, 0)), buffer.data(), arg(c, 2));
        for (int i = 0; i < n; ++i) write8(arg(c, 1) + static_cast<std::uint32_t>(i), buffer[static_cast<std::size_t>(i)]);
        c.r[2] = static_cast<std::uint32_t>(n);
    });
    def("ioman", 7, "write", [](Cpu &c) {
        if (fd_call(c, 0x18, false)) return;
        if (arg(c, 0) == 1 || arg(c, 0) == 2) std::fprintf(stderr, "[iop-tty] %s", ram_string(arg(c, 1), arg(c, 2)).c_str());
        c.r[2] = static_cast<std::uint32_t>(io::write(static_cast<int>(arg(c, 0)), nullptr, arg(c, 2)));
    });
    def("ioman", 8, "lseek", [](Cpu &c) {
        if (fd_call(c, 0x1C, false)) return;
        c.r[2] = static_cast<std::uint32_t>(io::seek(static_cast<int>(arg(c, 0)), static_cast<std::int32_t>(arg(c, 1)), static_cast<int>(arg(c, 2))));
    });
    def("ioman", 16, "getstat", [](Cpu &c) {
        const std::string gpath = ram_string(arg(c, 0));
        if (!io::netcnf_file(gpath) && !io::netcnf_dir(gpath) && path_call(c, 0x3C, false, arg(c, 1), 0, false)) return;
        std::uint32_t mode = 0, size = 0;
        if (!io::stat(ram_string(arg(c, 0)), mode, size)) { c.r[2] = static_cast<std::uint32_t>(-2); return; }
        const std::uint32_t p = arg(c, 1);
        std::memset(ram_ptr(p), 0, 40);
        write32(p, mode);
        write32(p + 8, size);
        c.r[2] = 0;
    });
    install_devices();
}

}

namespace ps2::iop::io {

void state(ps2::state::Stream &s) {
    s.tag("iopio");
    s.map(g_files, [&s](File &f) {
        s.pod(f.sector);
        s.pod(f.size);
        s.pod(f.position);
        s.vec(f.memory);
        s.pod(f.in_memory);
    });
}

}
