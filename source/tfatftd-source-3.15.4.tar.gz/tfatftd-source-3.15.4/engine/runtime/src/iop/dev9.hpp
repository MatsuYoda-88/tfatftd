#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>

// DEV9 expansion bay with the network adapter fitted: the SPEED ASIC and its SMAP Ethernet
// controller (EMAC3 MAC, DP83846A PHY, 93C46 EEPROM holding the MAC address). No hard disk.
namespace ps2::iop::dev9 {

void reset();

// DEV9 control registers 0x1F801460-0x1F80147F and the SPEED/SMAP window at 0x10000000.
bool handles(std::uint32_t a);
std::uint32_t read(std::uint32_t a, unsigned size);
void write(std::uint32_t a, std::uint32_t v, unsigned size);

// IOP DMA channel 8: moves `bytes` between IOP RAM at `madr` and the SMAP FIFOs.
void dma(std::uint32_t madr, std::uint32_t bytes, bool to_device);

// Frame interface. tx_hook's callback runs on the emulator thread for every frame the PS2 sends;
// rx_push may be called from any thread and poll() hands queued frames to the adapter.
void tx_hook(std::function<void(const std::uint8_t *, std::size_t)> hook);
void rx_push(const std::uint8_t *frame, std::size_t size);
void poll();
std::array<std::uint8_t, 6> mac();

// debugging: print the adapter state and log the next `accesses` register accesses
void trace(int accesses);

}
