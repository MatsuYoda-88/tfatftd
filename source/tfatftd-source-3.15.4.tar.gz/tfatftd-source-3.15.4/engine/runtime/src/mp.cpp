#include <cmath>
// Multiplayer puppets for Tokyo Drift (SLUS-21449).
// A puppet is a car in the game world that shows a remote player instead of whatever drove it:
// after the game's own car update (GSRaceCar_c, 0x311F20) writes the car's matrix from physics,
// we overwrite it with the remote player's pose. The physics body is left alone (it is NovodeX's),
// so a puppet is never solid - ghost mode by construction.
#include "ps2/generated.hpp"
#include "ps2/memory.hpp"
#include "ps2/mp.hpp"

#include <cstdio>
#include <cstdlib>
#include <atomic>
#include <algorithm>
#include <cstring>
#include <mutex>
#include <utility>
#include "ps2/system.hpp"
#include <unordered_map>
#include <cstdarg>
#include <string>
#include <vector>

namespace ps2::mp {

namespace {

constexpr std::uint32_t kCarUpdate = 0x00311F20u;  // GSRaceCar_c::Update(this) - copies mover pose into the car matrix
constexpr std::uint32_t kCarVtable = 0x00521480u;  // GSRaceCar_c vptr, stored at object + 8
constexpr std::uint32_t kMatrix = 0x10u;            // 4x4 world matrix (rows right/up/forward/position) at object + 0x10

std::mutex g_lock;
std::unordered_map<std::uint32_t, Pose> g_puppets;  // car object -> pose
std::uint32_t g_follow_car = 0, g_follow_leader = 0;  // debug: puppet that mirrors another car, offset forward
float g_follow_ahead = 0, g_follow_side = 0;
bool g_installed = false;
std::uint32_t g_friend_puppets[4] = {};   // friends' cars this load (their g_puppets entries)
std::uint32_t guest_call(Cpu &c, std::uint32_t fn, std::initializer_list<std::uint32_t> args);

void stf(std::uint32_t a, float v) { std::uint32_t u; std::memcpy(&u, &v, 4); st32(a, u); }
float ldf(std::uint32_t a) { const std::uint32_t u = ld32(a); float v; std::memcpy(&v, &u, 4); return v; }

}
bool read_car(std::uint32_t car, Pose &out);
namespace {
// ---- online v0.01 state ----
struct Slot { bool want = false; Pose pose; std::uint32_t car = 0; std::uint64_t car_seen = 0; float wrote[3] = {}; bool has_wrote = false; };
std::unordered_map<std::uint32_t, int> g_bad_cars;   // cars that something else moves after our write (buses, scripted traffic)
Slot g_slots[kSlots];
std::unordered_map<std::uint32_t, std::uint64_t> g_live;   // car object -> last update tick
std::uint64_t g_tick = 0;
std::uint32_t g_local = 0;                                    // the car the player drives (see local_car())
std::uint32_t local_car();
bool slot_car(std::uint32_t car) { for (const Slot &s : g_slots) if (s.car == car) return true; return false; }

bool car_update(Cpu &c) {
    const std::uint32_t self = c.r[4].w[0];
    const std::uint32_t ra = c.r[31].w[0];
    // a borrowed car must stay where we put it last frame; if its own code moved it again (a bus or other
    // scripted traffic overrides the matrix after this update), give it back and borrow a plain car instead
    {
        std::lock_guard lock(g_lock);
        for (Slot &sl : g_slots) {
            if (sl.car != self || !sl.has_wrote) continue;
            const float dx = ldf(self + kMatrix + 48) - sl.wrote[0], dz = ldf(self + kMatrix + 56) - sl.wrote[2];
            if (dx * dx + dz * dz > 0.25f) {
                std::fprintf(stderr, "[mp] car %08X won't hold the pose, giving it back\n", self);
                g_bad_cars[self] = 1; g_puppets.erase(self); sl.car = 0; sl.has_wrote = false;
            }
        }
    }
    call_original(c, kCarUpdate, 0);
    if (c.pc & kUnwind) return true;   // the game switched threads inside: it finishes the update itself later
    {
        std::lock_guard lock(g_lock);
        g_live[self] = ++g_tick;
    }
    if (self == g_follow_car && g_follow_leader) {
        Pose lead;
        if (read_car(g_follow_leader, lead)) {
            for (int k = 0; k < 3; ++k) lead.pos[k] += lead.rot[2][k] * g_follow_ahead + lead.rot[0][k] * g_follow_side;
            std::lock_guard lock(g_lock);
            g_puppets[self] = lead;
        }
    }
    Pose p;
    bool puppet = false;
    {
        std::lock_guard lock(g_lock);
        auto it = g_puppets.find(self);
        if (it != g_puppets.end()) { p = it->second; puppet = true; }
        // online players: each one borrows a car the game already drives (traffic), and the game draws it
        // at that player's pose - same camera, lighting and shadows as every other car, so it never slides
        int mine = -1;
        for (int i = 0; i < kSlots; ++i) if (g_slots[i].car == self) mine = i;
        if (mine < 0 && self != local_car() && !g_bad_cars.count(self)) {
            for (int i = 0; i < kSlots; ++i) {
                Slot &sl = g_slots[i];
                if (sl.want && !sl.car) { sl.car = self; mine = i; std::fprintf(stderr, "[mp] player slot %d borrows car %08X\n", i, self); break; }
            }
        }
        if (mine >= 0) {
            Slot &sl = g_slots[mine];
            sl.car_seen = g_tick;
            if (sl.want) { p = sl.pose; puppet = true; for (int k = 0; k < 3; ++k) sl.wrote[k] = p.pos[k]; sl.has_wrote = true; }
        }
    }
    if (puppet) {
        const std::uint32_t m = self + kMatrix;
        for (int r = 0; r < 3; ++r)
            for (int k = 0; k < 3; ++k) stf(m + r * 16 + k * 4, p.rot[r][k]);
        for (int k = 0; k < 3; ++k) stf(m + 48 + k * 4, p.pos[k]);
        // a friend's car: its BODY is a separate model (car + 0x104) with its own position, which only the game's
        // SetPosition / SetOrientation move (car vtable +0x298 = 0x23D030, +0x2A0 = 0x23D410). We move the car, so
        // without this his body stayed where it was built (~17 m off) while his wheels followed - wheels, no body.
        bool friend_car = false;
        { std::lock_guard lock(g_lock); for (std::uint32_t fp : g_friend_puppets) if (fp == self) friend_car = true; }
        if (friend_car && ld32(self + 0x104)) {
            guest_call(c, 0x0023D030u, {self});
            guest_call(c, 0x0023D410u, {self});
        }
    }
    c.pc = ra;
    return true;
}

}

void vt_log(int method, std::uint32_t fn, std::uint32_t car, std::uint32_t ra);
// research: which GSRaceCar_c methods run on which car (my car vs a friend's) - logged once per (method, car)
constexpr std::uint32_t kCarMethods[] = {0x00199460u, 0x001966D0u, 0x001995A0u, 0x00199608u, 0x00198038u, 0x00196AC8u, 0x00198200u, 0x00196EF0u, 0x00246B80u, 0x00246E98u, 0x00390870u, 0x00271B48u, 0x00271CD0u, 0x003908B8u, 0x003908C8u, 0x003908D8u, 0x001995F8u, 0x00149CB8u, 0x00149CC0u, 0x00149CC8u, 0x002713C0u, 0x00271590u, 0x0023DEE0u, 0x00169CF8u, 0x0024DD00u, 0x00275860u, 0x002418B8u, 0x001980B8u, 0x002476B0u, 0x0023BC78u, 0x0024ABC8u, 0x00275B48u, 0x00275AF8u, 0x002759A8u, 0x002467E8u, 0x00271E58u, 0x00271FD0u, 0x00248280u, 0x002418E0u, 0x00241158u, 0x002418E8u, 0x00271A90u, 0x0023DD20u, 0x0023DE80u, 0x002716F0u, 0x00271850u, 0x002418F0u, 0x00272220u, 0x00248628u, 0x00248778u, 0x0023E2F8u, 0x0023E2A8u, 0x00273548u, 0x00196CD0u, 0x002737D0u, 0x0023E3F0u, 0x0024D568u, 0x00273CD0u, 0x00273D00u, 0x0024A510u, 0x0024DD78u, 0x0024DD88u, 0x0024DD80u, 0x0024DDC0u, 0x00241928u, 0x00241930u, 0x00241938u, 0x00241940u, 0x00198960u, 0x00246838u, 0x00247590u, 0x002475E0u, 0x00241958u, 0x00241960u, 0x0024D9B8u, 0x0023E428u, 0x00241968u, 0x0024C978u, 0x00275438u, 0x00241568u, 0x002415B8u, 0x0024C9D8u, 0x0023EFB8u, 0x0023D030u, 0x0023D410u, 0x00241970u, 0x0024DD20u, 0x0024B290u, 0x00198C58u, 0x0024DD60u, 0x00248E28u, 0x00198D68u, 0x00198AE0u, 0x00197088u, 0x00196A08u, 0x0024DE00u, 0x001969B0u, 0x002514F0u, 0x0024ED40u, 0x0024ED48u, 0x0024EFC8u, 0x00250960u, 0x002477D8u, 0x0026D4F0u, 0x00198B78u, 0x0026E8D0u};
std::mutex g_vt_lock;
std::unordered_map<std::uint64_t, int> g_vt_seen;
template <int I> bool car_method(Cpu &c) {
    const std::uint32_t self = c.r[4].w[0], ra = c.r[31].w[0];
    if (self && self < ps2::kRamSize && ld32(self + 8) == kCarVtable) {
        std::lock_guard lock(g_vt_lock);
        const std::uint64_t k = (static_cast<std::uint64_t>(I) << 32) | self;
        // logged the first time, and again at its 600th call (= it runs every frame: the per-frame work, drawing included)
        if (g_vt_seen.size() < 2000) { const int n = ++g_vt_seen[k]; if (n == 1 || n == 600) vt_log(n == 600 ? I + 1000 : I, kCarMethods[I], self, ra); }
    }
    call_original(c, kCarMethods[I], 0);
    if (c.pc & kUnwind) return true;
    c.pc = ra;
    return true;
}
template <int... Is> void hook_car_methods(std::integer_sequence<int, Is...>) { (set_hook(kCarMethods[Is], car_method<Is>), ...); }

void install() {
    if (g_installed) return;
    g_installed = true;
    set_hook(kCarUpdate, car_update);
    // research (?players2=1): the session reports 2 players (like split screen), so the per-player world-load loop
    // (0x1BA3C0) builds a second player's car with the game's own player-car builder (0x2A8C40)
    // wheel spin angle guard: a wheel's update (0x296390, from the axle part's virtual 0x2971B0, wheel = this + 0x70)
    // wraps its spin angle (+0x2C0) into -pi..pi by adding/subtracting 2 pi in a loop. A teleported car (a friend
    // jumping to his spot after a load) can get an angle so big (1.7e8) that +-2 pi doesn't change the float: the
    // loop never ends and the whole game freezes (seen after warping out of a shop with a friend in the city).
    set_hook(0x002971B0u, [](Cpu &c) {
        const std::uint32_t self = c.r[4].w[0];
        if (!self || self >= ps2::kRamSize) return false;
        const std::uint32_t wheel = ld32(self + 0x70);
        if (!wheel || wheel >= ps2::kRamSize) return false;
        const float a = ldf(wheel + 0x2C0);
        if (!std::isfinite(a) || std::fabs(a) > 64.0f) {
            const float w = std::isfinite(a) ? std::remainder(a, 6.28318530718f) : 0.0f;
            stf(wheel + 0x2C0, std::isfinite(w) ? w : 0.0f);
            static int n = 0; if (n++ < 20) std::fprintf(stderr, "[mp] wheel %08X spin angle %g wrapped (would have frozen the game)\n", wheel, a);
        }
        // and the spin RATE this update adds (0x296F88: tyre T = wheel+0x70, rate T+0xEC, or ground speed wheel+0x2DC /
        // radius): one absurd value makes angle += rate*dt land past 3.4e7 in a single step and the loop never ends.
        // 2000 rad/s is ~2000 km/h on a road car's wheel, so real driving never gets near it.
        auto clamp = [](std::uint32_t a, float lim) {
            const float v = ldf(a);
            if (!std::isfinite(v) || std::fabs(v) > lim) {
                stf(a, std::isfinite(v) ? std::copysign(lim, v) : 0.0f);
                static int n = 0; if (n++ < 20) std::fprintf(stderr, "[mp] wheel value at %08X was %g, clamped\n", a, v);
            }
        };
        clamp(wheel + 0x2DC, 600.0f);
        const std::uint32_t tyre = ld32(wheel + 0x70);
        if (tyre && tyre < ps2::kRamSize) clamp(tyre + 0xEC, 2000.0f);
        return false;
    });
    if (std::getenv("PS2_MP_PLAYERS2")) set_hook(0x00316340u, [](Cpu &c) {
        const std::uint32_t ra = c.r[31].w[0];
        if (ra != 0x001BA3A0u && ra != 0x001BA3B0u) return false;   // only the world load's per-player loop
        std::fprintf(stderr, "[mp] world load asks for the player count (ra %08X): 2\n", ra);
        c.r[2].sd[0] = 2;
        return true;
    });
    // research (page link ?carresearch=1): log which race-car methods run on my car vs a friend's car
    if (std::getenv("PS2_CAR_RESEARCH")) hook_car_methods(std::make_integer_sequence<int, static_cast<int>(sizeof kCarMethods / sizeof kCarMethods[0])>{});
    // Bigger "Graphics" picture closet. At boot the game sizes its memory banks per game mode (table at 0x5FAAB8:
    // 10 modes x {data, graphics} in 16 KB slots), then makes the Global bank as big as the hungriest mode
    // (0x12F990 works that out). Each city load carves "Graphics" (842 slots in Career) out of Global. A friend's
    // car fills most of what's left, and then the pause map can't get its 43 slots: blank map, pad stuck,
    // and warps that wait forever. With 64 MB of RAM there's room: every mode gets kExtraGraphics more slots
    // (and Global grows with them) before the game does its sums.
    set_hook(0x0012F990u, [](Cpu &) {
        constexpr std::uint32_t kExtraGraphics = 512;   // 8 MB
        static bool done = false;
        if (done) return false;
        done = true;
        for (std::uint32_t i = 0; i < 10; ++i) {
            const std::uint32_t at = 0x005FAAB8u + i * 8 + 4, n = ld32(at);
            if (n && n < 0x10000) st32(at, n + kExtraGraphics);
        }
        std::fprintf(stderr, "[mp] graphics banks +%u slots in every mode (room for friends' cars and the map)\n", kExtraGraphics);
        return false;
    });
    // The Online menu runs the DNAS check (Sony's old online ID check) by loading a DLL from the disc
    // (dnasdll.rel) and jumping into it. That code only exists at run time, so it has no recompiled twin:
    // running it stops the game ("missing code" - the online menu freeze). The DNAS servers are long gone
    // anyway, so the step that would load it (virtual method 0x2266E0: -1 = still working, 0 = done)
    // now reports "done" without it, and the game moves on to its own online error.
    set_hook(0x002266E0u, [](Cpu &c) {
        const std::uint32_t self = c.r[4].w[0];
        if (!self || self >= ps2::kRamSize || ld32(self + 0xA2C) == 0 || ld32(self + 0xA28) != 0) return false;
        static int told = 0;
        if (!told++) std::fprintf(stderr, "[mp] DNAS check skipped (its DLL can't run here; LAN never needs it)\n");
        c.r[2].sd[0] = 0;
        return true;
    });
    // Calls into the DNAS DLL are 'jal 0' in the game until the DLL loader patches them, so without the
    // DLL they land at address 0. Answer them like the DNAS servers do today: the status check (called
    // from 0x2268F0) says "error" (2) and the error code (0x226920) is -603, so the game shows its own
    // DNAS error and backs out instead of stopping. Any other such call just returns 0.
    set_hook(0x00000000u, [](Cpu &c) {
        const std::uint32_t ra = c.r[31].w[0];
        std::int32_t v = 0;
        if (ra == 0x002268F8u) v = 2;
        else if (ra == 0x00226928u) v = -0x25B;
        static int told = 0;
        if (told++ < 8) std::fprintf(stderr, "[mp] DNAS call from %08X answered %d\n", ra, v);
        c.r[2].sd[0] = v;
        return true;
    });
}

void set_puppet(std::uint32_t car, const Pose &pose) {
    install();
    std::lock_guard lock(g_lock);
    g_puppets[car] = pose;
}

void clear_puppet(std::uint32_t car) {
    std::lock_guard lock(g_lock);
    g_puppets.erase(car);
}

bool read_car(std::uint32_t car, Pose &out) {
    if (ld32(car + 8) != kCarVtable) return false;
    const std::uint32_t m = car + kMatrix;
    for (int r = 0; r < 3; ++r)
        for (int k = 0; k < 3; ++k) out.rot[r][k] = ldf(m + r * 16 + k * 4);
    for (int k = 0; k < 3; ++k) out.pos[k] = ldf(m + 48 + k * 4);
    return true;
}

// Debug: PS2_MP_FOLLOW=car,leader,ahead,side makes car mirror leader's pose, offset (a stand-in for network data).
// Debug: PS2_MP_TEST=car,x,y,z parks that car's picture at a fixed spot (heading kept) to prove puppets work.
namespace { void online_hooks(); }
void debug_init() {
    // called from boot() on the game thread: the only safe place to add hooks
    install();
    online_hooks();
    if (const char *f = std::getenv("PS2_MP_FOLLOW")) {
        unsigned car = 0, lead = 0;
        if (std::sscanf(f, "%x,%x,%f,%f", &car, &lead, &g_follow_ahead, &g_follow_side) == 4) {
            g_follow_car = car;
            g_follow_leader = lead;
            install();
            std::fprintf(stderr, "[mp] follow: car %08X mirrors %08X, %.1f ahead %.1f side\n", car, lead, g_follow_ahead, g_follow_side);
        }
    }
    // Debug: PS2_MP_FRIENDCAR=file gives friend slot 1 that packed car (as if a friend sent it), for headless tests
    if (const char *fc = std::getenv("PS2_MP_FRIENDCAR")) {
        if (FILE *f = std::fopen(fc, "rb")) {
            std::vector<std::uint8_t> b(8192); const std::size_t n = std::fread(b.data(), 1, b.size(), f); std::fclose(f);
            set_friend_car(1, b.data(), static_cast<int>(n)); set_friend_unlist(0);
            std::fprintf(stderr, "[mp] friend 1 car from %s (%zu bytes)\n", fc, n);
        }
    }
    const char *spec = std::getenv("PS2_MP_TEST");
    if (!spec) return;
    unsigned car = 0;
    float x = 0, y = 0, z = 0;
    if (std::sscanf(spec, "%x,%f,%f,%f", &car, &x, &y, &z) != 4) return;
    Pose p{};
    p.rot[0][0] = 1; p.rot[1][1] = 1; p.rot[2][2] = 1;
    p.pos[0] = x; p.pos[1] = y; p.pos[2] = z;
    set_puppet(car, p);
    std::fprintf(stderr, "[mp] test puppet: car %08X shown at %.1f %.1f %.1f\n", car, x, y, z);
}


// ===== online v0.01 =====
// Found in free roam (career, hub + Wangan): two global GSGameCamera_c objects.
//   0x5C9E40: the view camera, world matrix (rows right/up/forward/position) at +0x10
//   0x5C9F30: the chase camera, the car it follows (= the player's car) at +0x2FC
// Free roam = GSCruiseModeState_c is running (its methods are hooked below); anything else
// (touge / race / garage / menus) counts as "elsewhere", so players there are solo.
namespace {
constexpr std::uint32_t kViewCam = 0x005C9E40u, kChaseCam = 0x005C9F30u, kCamVtable = 0x00513EA0u, kCamTarget = 0x2FCu;
constexpr std::uint32_t kCruiseMethods[] = {0x1E9380u, 0x1E8350u, 0x1E8468u, 0x1E8680u, 0x1E8B08u, 0x1E9F98u, 0x1EA068u};
std::atomic<std::uint64_t> g_cruise_frame{0};
std::atomic<std::uint32_t> g_cruise_hits[7];
bool g_online_hooks = false;
std::uint32_t local_car() {
    if (ld32(kChaseCam + 8) != kCamVtable) return 0;
    const std::uint32_t car = ld32(kChaseCam + kCamTarget);
    return (car && car < ps2::kRamSize && ld32(car + 8) == kCarVtable) ? car : 0;
}
int current_world() {
    const std::uint64_t f = ps2::frames_run(), seen = g_cruise_frame.load(std::memory_order_relaxed);
    return seen && f - seen < 30 ? 1 : 0;
}
// ---- car spawning (research + online cars) ----
// GameMode::SpawnCar 0x1A0300(mode, desc, id, a3, t0) queues a car in the mode's spawner (mode + 0xA24).
// desc comes from 0x3736D0(model index); a custom (career) car is spawned with its base model's desc and
// its own id, and the car picks its parts / paint up from the custom car manager by that id.
constexpr std::uint32_t kSpawnCar = 0x001A0300u, kModelDesc = 0x003736D0u, kCustomDesc = 0x0031DDD8u;
std::mutex g_log_lock;
std::string g_log;
void mplog(const char *fmt, ...) {
    char buf[512];
    va_list ap; va_start(ap, fmt); std::vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    std::fprintf(stderr, "%s", buf);
    std::lock_guard lock(g_log_lock);
    g_log += buf;
    if (g_log.size() > 32000) g_log.erase(0, g_log.size() - 24000);
}
std::atomic<std::uint32_t> g_spawn_mode{0};
}
void vt_log(int method, std::uint32_t fn, std::uint32_t car, std::uint32_t ra) { mplog("[vt] method %d (%08X) car %08X ra %08X\n", method, fn, car, ra); }
namespace {
std::atomic<std::uint32_t> g_cruise_this[7];
constexpr std::uint32_t kSpawnEntity = 0x0013D960u;
// research: guest calls queued from the page, run on the next cruise frame
struct GuestCallReq { std::uint32_t fn; std::uint32_t args[6]; int n; };
std::vector<GuestCallReq> g_calls;
std::atomic<std::uint32_t> g_call_result{0};
std::atomic<int> g_call_done{0};
// the game's own stream (net packet) code serializes cars; a fake stream address routes its raw byte
// reads / writes (0x39E4C8 reserve, 0x39E660 write, 0x39E6C0 read) into these buffers instead
constexpr std::uint32_t kFakeStream = 0x00000F00u;
constexpr std::uint32_t kStreamReserve = 0x0039E4C8u, kStreamWrite = 0x0039E660u, kStreamRead = 0x0039E6C0u;
constexpr std::uint32_t kCustomById = 0x00319E68u;
std::vector<std::uint8_t> g_fs_out, g_fs_in;
// research: probes the page installs at run time (only for functions reached through dispatch:
// virtual methods, function pointers and the hooks.txt list). Each logs its first `left` calls.
struct Probe { int left; };
std::unordered_map<std::uint32_t, Probe> g_probes;
std::vector<std::pair<std::uint32_t, int>> g_probe_reqs;
std::size_t g_fs_pos = 0;
std::unordered_map<std::uint32_t, std::uint32_t> g_custom_override;   // custom car id -> object (remote players' cars)
// career car in LAN: when the game writes the local player's car into a net message (GSNetPlayer::WriteGameData,
// a virtual method), point that player's car shelf entry at the career (custom) car first, so the game sends - and
// races with - the player's own built car. -1 = off, 0 = the first car in the garage, else that custom car id.
constexpr std::uint32_t kWriteGameData = 0x0017D9F0u, kGetCarData = 0x0017DE88u, kCarManager = 0x004DC554u;
std::atomic<int> g_career_car{-1};
std::atomic<std::uint32_t> g_load_slot[4];
std::atomic<int> g_friend_unlist{1};
std::atomic<int> g_friend_physics{1};   // 1 = friends' cars are awake and driven by the game's physics (LAN way)
// career room friends (slots 1-3 of the world loader): their car build (SDCustomVehicle stream bytes) and live pose
struct Friend { std::vector<std::uint8_t> car; bool want = false; Pose pose; std::uint32_t built = 0; bool swap = false; };
Friend g_friends[4];
std::vector<std::uint8_t> g_my_car;       // my career car, packed by the game (sent to the room)
std::atomic<int> g_my_car_req{0};
std::atomic<int> g_spawn_model{-1}, g_spawn_id{-1};
// run a guest function from inside a hook, on the game's own stack below the caller's frame
std::uint32_t guest_call(Cpu &c, std::uint32_t fn, std::initializer_list<std::uint32_t> args) {
    Cpu saved = c;
    int k = 0;
    for (std::uint32_t a : args) {
        const int reg = k < 4 ? 4 + k : 8 + (k - 4);   // a0-a3, then t0-t3 (EE ABI)
        c.r[reg].sd[0] = static_cast<std::int32_t>(a);
        ++k;
    }
    c.r[29].sd[0] = static_cast<std::int32_t>((saved.r[29].w[0] - 0x800u) & ~15u);
    c.r[31].sd[0] = static_cast<std::int32_t>(kHandlerReturn);
    c.pc = fn;
    while (!halted()) {
        c.pc &= ~kUnwind;
        if (c.pc == kHandlerReturn) break;
        if (c.budget <= 0) set_budget(c, 20000);
        dispatch(c, 0, 0);
    }
    const std::uint32_t v0 = c.r[2].w[0];
    const std::int32_t budget = c.budget;
    c = saved;
    c.budget = budget;
    return v0;
}
void install_probes() {
{
    std::vector<std::pair<std::uint32_t, int>> reqs;
    { std::lock_guard lock(g_lock); reqs.swap(g_probe_reqs); }
    for (auto [addr, n] : reqs) {
        const bool fresh = !g_probes.count(addr);
        g_probes[addr].left = n;
        if (!fresh) continue;
        set_hook(addr, [addr](Cpu &c) {
            auto it = g_probes.find(addr);
            if (it == g_probes.end() || it->second.left <= 0) return false;
            --it->second.left;
            const std::uint32_t sp = c.r[29].w[0];
            mplog("[probe] %08X a0 %08X a1 %08X a2 %08X a3 %08X ra %08X up", addr, c.r[4].w[0], c.r[5].w[0], c.r[6].w[0], c.r[7].w[0], c.r[31].w[0]);
            for (int i = 0; i < 64; ++i) {
                const std::uint32_t w = ld32(sp + i * 4);
                if (w >= 0x100000u && w < 0x45E1C8u && (w & 3u) == 0) mplog(" %08X", w);
            }
            mplog("\n");
            return false;   // the original runs as usual
        });
    }
}
}
// ---- friend car, the LAN way ----
// A LAN race's remote car is AWAKE (PhysX body flags clear, car+0x270 = 0) and the game's own physics moves it, so the
// mover manager (0x3111B0) runs its wheel probes, suspension and tyres every frame. We do the same for a career friend:
// wake him once (0x23D9C8, the game's Wake), then every frame - right after the physics step, in his mover vt+0x1B8 call
// (0x23E3F0) - set his speed so the next physics step carries him onto his player's spot, using the game's own setters:
//   GSRaceCar::SetVelocity 0x2716F0(car, vec3*)        PhysX linear velocity + every tyre's spin rate (T+0xEC = v / r)
//   GSRaceCar::SetAngularVelocity 0x271850(car, vec3*)
//   Mover::SetPosition 0x23DD60(car, vec3*) / SetOrientation 0x23DDF8(car, 3 rows of 16 bytes)  (only for a big jump:
//   first spawn, a warp, a lag spike) - these push into PhysX properly (setGlobalPosition/Orientation + model sync).
// No position writes into the body any more: those skipped PhysX's own bookkeeping and gave the wheels absurd speeds.
struct FriendDrive { bool parked = false; int snaps = 0; int frames = 0; bool net = false; int reads = 0; bool setup = false; int since = 0; };
FriendDrive g_drive[4];
// LAN packets (3.5-as): exactly what a LAN race sends per car (message type 16 payload): my car is packed with the
// game's GSRaceCar::NetWrite (vt+0x40 0x246B80) and each friend's packet is applied with NetRead (vt+0x48 0x246E98),
// which sets his controls/gear/rpm/wheel spin and arms the game's own 200 ms physics blend (car+0xA40..+0xA80,
// applied by vt+0x1A0 0x273548 every frame). The car is then moved by the game exactly like a LAN remote car.
std::vector<std::uint8_t> g_my_state;
std::vector<std::uint8_t> g_friend_state[4];
bool g_friend_state_new[4] = {};
constexpr std::uint32_t kNetWrite = 0x00246B80u, kNetRead = 0x00246E98u;
// friends on the radar (07-maps.md): the game's own HudMap target, like a race opponent's - it follows the car pointer
struct RadarDot { std::uint32_t hud = 0, car = 0; };
RadarDot g_radar[4];
constexpr std::uint32_t kHudMap = 0x005CA284u, kAddTarget = 0x0030ACD0u, kRemoveTarget = 0x0030B890u;
bool hud_ready(std::uint32_t hud) { return hud && hud < ps2::kRamSize && ld32(hud + 0x354) && ld32(hud + 0x360) == 1; }
std::uint32_t guest_call(Cpu &c, std::uint32_t fn, std::initializer_list<std::uint32_t> args);
void radar_drop(Cpu &c, int k) {
    RadarDot &r = g_radar[k];
    if (r.car && r.hud && r.hud == ld32(kHudMap) && hud_ready(r.hud)) guest_call(c, kRemoveTarget, {r.hud, r.car});
    r = RadarDot{};
}
std::uint32_t race_icon_impl(Cpu &c);
static std::uint32_t race_icon(Cpu &c) { return race_icon_impl(c); }
void radar_show(Cpu &c, int k, std::uint32_t car) {
    const std::uint32_t hud = ld32(kHudMap);
    if (!hud_ready(hud)) return;
    RadarDot &r = g_radar[k];
    if (r.hud == hud && r.car == car) return;
    if (r.car) radar_drop(c, k);
    const std::uint32_t d = (c.r[29].w[0] - 0x400u) & ~15u;   // desc on the game's stack (AddTarget copies it)
    for (std::uint32_t i = 0; i < 0x60; i += 4) st32(d + i, 0);
    guest_call(c, 0x00307B20u, {d}); guest_call(c, 0x00307AA0u, {d});
    const std::uint32_t img = race_icon(c);
    st32(d + 0x08, car); st32(d + 0x20, 0x00FF8000u);   // light blue (red = race opponents, green = you)
    st32(d + 0x24, img); st32(d + 0x2C, 1); st32(d + 0x30, 16); st32(d + 0x34, 16);
    st32(d + 0x40, 1);   // turns with his heading
    st32(d + 0x44, 1);   // far away: stays on the rim pointing at him
    st32(d + 0x4C, 1);   // drawn above my marker
    if (guest_call(c, kAddTarget, {hud, d}) == 1) { r.hud = hud; r.car = car; mplog("[mp] friend %d on the radar (car %08X)\n", k, car); }
}
// late joiners (3.5-at): a friend who shows up after the city loaded gets his car built WHILE driving, the way the
// game builds a roll-up challenger in free roam (03-loading.md section 7a/9): spare race-car-manager entries are
// reserved at load (loader+0x284 raised before state 18), then: GSNetDriverData_c + record (his stream) ->
// request 0x2E5DE0 / record vt+0x40 0x142778 -> 0x2E5B38(*0x4D93FC, req, 0) -> poll 0x244478(world, id) ->
// parts 0x198F48, NET flag +0x90C, GSRaceBrain 0x196CF0(car, 2), Activate 0x271B48.
struct LateSpawn { bool pending = false; bool failed = false; std::int32_t id = -1; int waited = 0; std::int32_t free_id = -1; std::uint32_t swap_old = 0; };
LateSpawn g_late[4];
std::atomic<int> g_friends_here{0};
std::atomic<int> g_cam_next{0};   // page asked: next camera view (the game's own CycleView, 10-camera.md)
// friends' arrows on the pause map: where the game would draw them (GUI units = 640x448 framebuffer px), for the page
struct PmFriend { int slot; float cx, cy, w, h, deg; std::uint32_t rgba; };
PmFriend g_pm[3] = {}, g_pm_last = {};
int g_pm_n = 0;
bool g_pm_catch = false, g_pm_caught = false;
std::atomic<std::uint32_t> g_pausemap_r{0};
std::atomic<std::uint64_t> g_pausemap_frame{0};
constexpr std::uint32_t kRaceCarRoom = 2;   // a 3rd car slot starved the roll-up challenger's car (stuck loading screen)   // the spare is only added while the room is below this (solo load: 1 -> 2)
void wr3(std::uint32_t a, const float v[3]) { for (int q = 0; q < 3; ++q) stf(a + q * 4, v[q]); }
void friend_drive(Cpu &c, int k, std::uint32_t car, const Pose &p, bool want) {
    FriendDrive &d = g_drive[k];
    const std::uint32_t scratch = (c.r[29].w[0] - 0x300u) & ~15u;   // below the caller's frame, above guest_call's
    const bool frozen = guest_call(c, 0x003116E0u, {car}) != 0;
    if (!want) {
        if (!d.parked) {   // nobody here: put him away and let the game freeze him (0x311618 sleep + freeze)
            const float away[3] = {ldf(car + 0x40), -500.0f, ldf(car + 0x48)}, zero[3] = {};
            wr3(scratch, away); guest_call(c, 0x002713C0u, {car, scratch});
            wr3(scratch, zero); guest_call(c, 0x002716F0u, {car, scratch}); guest_call(c, 0x00271850u, {car, scratch});
            guest_call(c, 0x00311618u, {car});
            d.parked = true;
        }
        return;
    }
    bool snap = d.parked || d.frames == 0;
    if (frozen) { st32(car + 0x274, 0); guest_call(c, 0x0023D9C8u, {car}); snap = true; }
    d.parked = false;
    const float cur[3] = {ldf(car + 0x40), ldf(car + 0x44), ldf(car + 0x48)};
    float e[3]; float d2 = 0;
    for (int q = 0; q < 3; ++q) { e[q] = p.pos[q] - cur[q]; d2 += e[q] * e[q]; }
    if (!(d2 < 8.0f * 8.0f)) snap = true;
    float v[3], w[3] = {};
    if (snap) {
        wr3(scratch, p.pos); guest_call(c, 0x002713C0u, {car, scratch});
        for (int r = 0; r < 3; ++r) { wr3(scratch + 0x10 + r * 16, p.rot[r]); stf(scratch + 0x1C + r * 16, 0.0f); }
        guest_call(c, 0x00271590u, {car, scratch + 0x10});
        for (int q = 0; q < 3; ++q) v[q] = p.vel[q];
        if (d.snaps++ < 30) mplog("[mp] friend %d car %08X placed (jump %.1f m%s)\n", k, car, std::sqrt(d2), frozen ? ", woke him" : "");
    } else {
        // position: his real speed plus a pull toward the spot (gets 0.25 s to close the gap), at most 15 m/s extra
        float pull[3], pl = 0;
        for (int q = 0; q < 3; ++q) { pull[q] = e[q] * 4.0f; pl += pull[q] * pull[q]; }
        pl = std::sqrt(pl);
        const float s = pl > 15.0f ? 15.0f / pl : 1.0f;
        for (int q = 0; q < 3; ++q) v[q] = p.vel[q] + pull[q] * s;
        // rotation: turn from where the car points now to where he points. World-from-car matrix columns are the
        // rows (right, up, forward) of the car matrix; error E = Wt * Wc^T, spin = its axis * angle * 6 per second.
        float E[3][3];
        for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) {
            float sum = 0;
            for (int r = 0; r < 3; ++r) sum += p.rot[r][i] * ldf(car + 0x10 + r * 16 + j * 4);
            E[i][j] = sum;
        }
        const float ax[3] = {E[2][1] - E[1][2], E[0][2] - E[2][0], E[1][0] - E[0][1]};
        const float sn = 0.5f * std::sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
        const float cs = 0.5f * (E[0][0] + E[1][1] + E[2][2] - 1.0f);
        const float ang = std::atan2(sn, cs);
        if (sn > 1e-5f) for (int q = 0; q < 3; ++q) w[q] = ax[q] / (2.0f * sn) * ang * 6.0f;
        if (ang > 1.2f) { // more than ~70 degrees off (spun out, flipped): just put him right
            for (int r = 0; r < 3; ++r) { wr3(scratch + 0x10 + r * 16, p.rot[r]); stf(scratch + 0x1C + r * 16, 0.0f); }
            guest_call(c, 0x00271590u, {car, scratch + 0x10});
            for (float &x : w) x = 0;
        }
    }
    for (int q = 0; q < 3; ++q) if (!std::isfinite(v[q])) v[q] = 0;
    for (int q = 0; q < 3; ++q) if (!std::isfinite(w[q])) w[q] = 0;
    wr3(scratch, v); guest_call(c, 0x002716F0u, {car, scratch});
    wr3(scratch, w); guest_call(c, 0x00271850u, {car, scratch});
    if (d.frames++ % 600 == 0) mplog("[mp] friend %d drive: off by %.2f m, frozen %d, body flags %08X\n", k, std::sqrt(d2), frozen ? 1 : 0, [&] {
        const std::uint32_t a = ld32(car + 0xF0), b = a && a < ps2::kRamSize ? ld32(a + 0x28) : 0; return b && b < ps2::kRamSize ? ld32(b + 0x160) : 0u; }());
}
// FindImage("IMG_MAPRACECAR"): the race-opponent marker, a white picture the game tints (friends: light blue)
std::uint32_t race_icon_impl(Cpu &c) {
    if (const std::uint32_t rr = ld32(0x004DA8A8u); rr && rr < ps2::kRamSize) {
        const std::uint32_t vt = ld32(rr + 0x174);
        if (vt && vt < ps2::kRamSize) {
            const std::int32_t adj = static_cast<std::int16_t>(ld32(vt + 0x110) & 0xFFFFu);
            return guest_call(c, ld32(vt + 0x114), {static_cast<std::uint32_t>(rr + adj), 0x005384F8u, 0u});
        }
    }
    return 0;
}
void desc_words(std::uint32_t d, std::uint32_t out[4]) { for (int i = 0; i < 4; ++i) out[i] = d && d < ps2::kRamSize ? ld32(d + i * 4) : 0; }
void online_hooks() {
    if (g_online_hooks) return;
    g_online_hooks = true;
    // the pause-menu map (GSMapLocationRenderer_c) draws the location list and ONE player arrow (0x2017E0, from the map
    // draw 0x201A80). Draw the same arrow again for every friend whose car is here: his position and heading through the
    // game's own math (0x200AA8 reads the owner car 0x5CA22C, 0x200D08 world -> map), then put mine back (07-maps.md 6.2)
    // Image DrawRotated(img, x, y, z, w, h, rgba, f12 = degrees): while a friend's arrow is placed, note it, don't draw
    set_hook(0x0035B990u, [](Cpu &c) {
        if (!g_pm_catch) return false;
        g_pm_last.cx = static_cast<float>(static_cast<std::int32_t>(c.r[5].w[0]));
        g_pm_last.cy = static_cast<float>(static_cast<std::int32_t>(c.r[6].w[0]));
        g_pm_last.w = static_cast<float>(static_cast<std::int32_t>(c.r[8].w[0]));
        g_pm_last.h = static_cast<float>(static_cast<std::int32_t>(c.r[9].w[0]));
        g_pm_last.rgba = c.r[10].w[0];
        std::uint32_t fb = c.f[12]; float deg; std::memcpy(&deg, &fb, 4); g_pm_last.deg = deg;
        g_pm_caught = true;
        c.pc = c.r[31].w[0];
        return true;
    });
    set_hook(0x002017E0u, [](Cpu &c) {
        static bool inside = false;
        if (inside) return false;
        g_pausemap_r.store(c.r[4].w[0]); g_pausemap_frame.store(ps2::frames_run());   // the page draws the sharp map over it
        std::uint32_t cars[3]; int slots[3]; int n = 0;
        { std::lock_guard lock(g_lock); g_pm_n = 0; for (int k = 1; k < 4; ++k) if (g_friends[k].built && g_friends[k].want) { slots[n] = k; cars[n++] = g_friends[k].built; } }
        if (!n) return false;
        const std::uint32_t ra = c.r[31].w[0], R = c.r[4].w[0];
        const std::uint32_t a0 = c.r[4].w[0], a1 = c.r[5].w[0], a2 = c.r[6].w[0], a3 = c.r[7].w[0], t0 = c.r[8].w[0], t1 = c.r[9].w[0], t2 = c.r[10].w[0], t3 = c.r[11].w[0];
        if (!R || R >= ps2::kRamSize) return false;
        inside = true;
        guest_call(c, 0x002017E0u, {a0, a1, a2, a3, t0, t1, t2, t3});   // my arrow, as the game draws it
        std::uint32_t save[8]; for (int i = 0; i < 8; ++i) save[i] = ld32(R + 0x78 + i * 4);
        const std::uint32_t mine = ld32(0x005CA22Cu);
        PmFriend got[3] = {}; int ng = 0;
        for (int i = 0; i < n; ++i) {
            const std::uint32_t car = cars[i];
            if (!car || car >= ps2::kRamSize || ld32(car + 8) != kCarVtable) continue;
            st32(0x005CA22Cu, car);
            guest_call(c, 0x00200AA8u, {R, 0u});
            st32(0x005CA22Cu, mine);
            guest_call(c, 0x00200D08u, {R, car + 0x40, R + 0x78});
            // the game places his arrow with its own math, but the draw (0x35B990) is caught: the page draws it in light
            // blue with his name (the game only has the one green arrow picture loaded in this menu)
            g_pm_catch = true; g_pm_caught = false;
            guest_call(c, 0x002017E0u, {a0, a1, a2, a3, t0, t1, t2, t3});
            g_pm_catch = false;
            if (g_pm_caught && ng < 3) { got[ng] = g_pm_last; got[ng].slot = slots[i]; ++ng; }
        }
        for (int i = 0; i < 8; ++i) st32(R + 0x78 + i * 4, save[i]);
        { std::lock_guard lock(g_lock); g_pm_n = ng; for (int i = 0; i < ng; ++i) g_pm[i] = got[i]; }
        inside = false;
        c.pc = ra;
        return true;
    });
    // every mover, every frame, right after the physics step (0x3111B0 loop, "always vt+0x1B8"): drive friends' cars
    set_hook(0x0023E3F0u, [](Cpu &c) {
        const std::uint32_t car = c.r[4].w[0];
        if (g_cam_next.load(std::memory_order_relaxed) && car && car == ld32(0x005FAE70u)) {
            g_cam_next.store(0);
            // same as the game's own "change view" action (0x14CFA8): CycleView 0x169B18(cam, +1), then the name goes into
            // the profile (0x1435D8) so it is saved with the game. Player 1's camera 0x5C9E40, profile 0x5CAB50.
            const std::uint32_t cam = 0x005C9E40u, prof = 0x005CAB50u;
            if (ld32(0x004DDC2Cu) == 1 && ld32(0x004DDBC4u) == 0 && ld32(cam + 8) == 0x00513EA0u && guest_call(c, 0x002BA690u, {cam}) == 0) {
                // the camera's own index goes stale after the menu / a load (they set the view by name): sync it first
                char cur[17] = {}; for (int i = 0; i < 16; ++i) cur[i] = static_cast<char>(ld8(prof + 0x168 + i));
                for (int k = 0; k < 4; ++k) {
                    const std::uint32_t np = ld32(cam + 0xD0 + k * 4);
                    if (!np || np >= ps2::kRamSize) continue;
                    bool same = true;
                    for (int i = 0; i < 16; ++i) { const char ch = static_cast<char>(ld8(np + i)); if (ch != cur[i]) { same = false; break; } if (!ch) break; }
                    if (same) { st32(cam + 0xE0, static_cast<std::uint32_t>(k)); break; }
                }
                guest_call(c, 0x00169B18u, {cam, 1u});
                const std::uint32_t k = ld32(cam + 0xE0);
                if (k < 4) guest_call(c, 0x001435D8u, {prof, ld32(cam + 0xD0 + k * 4)});
                mplog("[mp] camera view -> %u\n", k);
            }
        }
        if (!g_friend_physics.load(std::memory_order_relaxed)) return false;
        if (!car || car >= ps2::kRamSize || ld32(car + 8) != kCarVtable) return false;
        // my own car: pack its LAN state packet every other frame (30 a second) for the page to send
        if (car == ld32(0x005FAE70u)) {
            static int tick = 0;
            if ((++tick & 1) == 0) {
                g_fs_out.clear();
                guest_call(c, kNetWrite, {car, kFakeStream});
                std::lock_guard lock(g_lock);
                g_my_state.swap(g_fs_out); g_fs_out.clear();
                static int told = 0; if (told++ < 2) mplog("[mp] my LAN state packet: %d bytes\n", static_cast<int>(g_my_state.size()));
            }
            return false;
        }
        int k = -1; Pose p; bool want = false; std::vector<std::uint8_t> pkt;
        {
            std::lock_guard lock(g_lock);
            for (int i = 1; i < 4; ++i) if (g_friend_puppets[i] == car && g_friends[i].built == car) {
                k = i; p = g_friends[i].pose; want = g_friends[i].want;
                if (g_friend_state_new[i]) { pkt = g_friend_state[i]; g_friend_state_new[i] = false; }
            }
        }
        if (k < 0) return false;
        FriendDrive &d = g_drive[k];
        if (!d.setup) {   // a LAN remote car has no owner and no AI: nothing overwrites the controls NetRead sets
            st32(car + 0xA1C, 0); st32(car + 0xDAC, 0); stf(car + 0xA80, -1.0f); d.setup = true;
        }
        ++d.since;
        if (want && !pkt.empty()) {
            d.since = 0;
            if (d.parked || d.frames == 0) friend_drive(c, k, car, p, want);   // place him first (wake + snap) after parking
            g_fs_in = pkt; g_fs_pos = 0;
            guest_call(c, kNetRead, {car, kFakeStream});
            g_fs_in.clear(); g_fs_pos = 0;
            d.net = true;
            if (!std::isfinite(ldf(car + 0x40)) || !std::isfinite(ldf(car + 0x44)) || !std::isfinite(ldf(car + 0x48))) { d.frames = 0; friend_drive(c, k, car, p, want); mplog("[mp] friend %d: bad LAN packet, placed him from his pose\n", k); }
            if (d.reads++ % 300 == 0) mplog("[mp] friend %d LAN packet %d (%d bytes) -> NetRead, frozen %d\n", k, d.reads, static_cast<int>(pkt.size()), guest_call(c, 0x003116E0u, {car}) ? 1 : 0);
            return false;
        }
        // packets drive him (the game blends between them); without packets (an older page) steer him ourselves.
        // No packet for half a second (he paused, opened the map, went into a shop): let go of his gas/brake/steer
        // (car+0x978..+0x984, what NetRead writes) and hold him at the spot the page keeps him at
        if (d.net && want && d.since < 30) return false;
        if (d.net && want) for (std::uint32_t o = 0x978; o <= 0x984; o += 4) st32(car + o, 0);
        friend_drive(c, k, car, p, want);
        return false;   // then the game's own vt+0x1B8
    });
    for (int i = 0; i < 7; ++i) {
        set_hook(kCruiseMethods[i], [i](Cpu &c) {
            g_cruise_frame.store(ps2::frames_run(), std::memory_order_relaxed);
            if (g_cruise_this[i].exchange(c.r[4].w[0]) != c.r[4].w[0]) mplog("[mp] cruise method %d this %08X\n", i, c.r[4].w[0]);
            g_cruise_hits[i].fetch_add(1, std::memory_order_relaxed);
            install_probes();
            if (i == 0) {
                if (g_my_car_req.exchange(0)) {   // pack my career car the way LAN races send it
                    const std::uint32_t h0 = ld32(0x005FAE50u), d0 = h0 && h0 < ps2::kRamSize ? ld32(h0 + 0xC) : 0, obj = d0 && d0 < ps2::kRamSize ? ld32(d0 + 0xC) : 0;
                    if (obj && obj < ps2::kRamSize) {
                        g_fs_out.clear();
                        guest_call(c, 0x0031E0D0u, {obj, kFakeStream});
                        std::lock_guard lock(g_lock); g_my_car = g_fs_out; g_fs_out.clear();
                    }
                }
                // friends' cars are loaded as players 2-4: keep the camera and player 1 on my own car (slot 0)
                {
                    const std::uint32_t me = ld32(0x005FAE70u);
                    auto is_friend = [](std::uint32_t car) { for (int k = 1; k < 4; ++k) if (car && ld32(0x005FAE70u + k * 4) == car) return true; return false; };
                    if (me && me < ps2::kRamSize && ld32(0x005FAE74u)) {
                        static int told = 0;
                        if (ld32(kChaseCam + 8) == kCamVtable && is_friend(ld32(kChaseCam + kCamTarget))) { st32(kChaseCam + kCamTarget, me); if (told++ < 3) mplog("[mp] camera back on my car %08X\n", me); }
                        if (is_friend(ld32(0x005CA020u + 0x20C))) { st32(0x005CA020u + 0x20C, me); if (told++ < 3) mplog("[mp] player 1 back on my car\n"); }

                    }
                }
                // friends: their cars (built by the world loader as players 2-4, list at 0x5FAE70). Take them off the
                // player list once built (the map and pause menus walk that list and choke on players with no pad),
                // keep them in our own table, and put each one where its player is: the car's matrix and its physics
                // body (mover +0xF0, body +0x28: position +0x10/+0x60, rotation quaternion +0x20/+0x70, speeds 0)
                static std::uint32_t own[4] = {};
                // Only the city load builds friends' cars into player slots 2-4. Later, the game puts its OWN racers
                // there (a roll race's opponent): taking those for a friend hid them and parked them under the road
                // (solo roll race: AI invisible, one fell through the ground). So a listed car is a friend's only if a
                // friend owns that slot and it showed up in the first 20 s after the city load (my car changes on a load).
                static std::uint32_t load_me = 0; static int since_load = 0;
                if (const std::uint32_t m = ld32(0x005FAE70u); m != load_me) { load_me = m; since_load = 0; } else if (since_load < 100000) ++since_load;
                for (int k = 1; k < 4; ++k) {
                    std::uint32_t listed = ld32(0x005FAE70u + k * 4);
                    if (listed && listed != own[k]) {
                        bool friend_slot;
                        { std::lock_guard lock(g_lock); friend_slot = g_friends[k].want || !g_friends[k].car.empty() || g_friends[k].built; }
                        if (!friend_slot || since_load > 1200) {
                            static int told = 0;
                            if (told++ < 6) mplog("[mp] car %08X in player slot %d is the game's own (race), not a friend's: leaving it alone\n", listed, k + 1);
                            listed = 0;
                        }
                    }
                    if (listed && listed < ps2::kRamSize && ld32(listed + 8) == 0x00521480u) {
                        own[k] = listed;
                        // ...but only once its graphics are switched on (car + 0x180: 4 slots of 0x14 bytes, state at +0x10:
                        // 2 = loaded, 3 = in the world). The game switches them on for listed players in the first frames;
                        // taken off the list before that, the car never shows (only its wheels' shadow). 10 s at most.
                        static int waited[4] = {};
                        const bool on = ld32(listed + 0x190) == 3;
                        if (g_friend_unlist.load() && (on || ++waited[k] > 600)) {
                            st32(0x005FAE70u + k * 4, 0); st32(0x005FAE50u + k * 4, 0); waited[k] = 0;
                            mplog("[mp] friend %d car %08X off the player list (graphics %s)\n", k, listed, on ? "on" : "NOT on");
                        }
                    }
                    bool late_ready = false;
                    {   // car swap: build his NEW car first (into a free car slot), and only then drop the old one - so he is
                        // never a box. No free slot: keep showing the old car; the new one shows on the next load.
                        bool swap = false;
                        { std::lock_guard lock(g_lock); swap = g_friends[k].swap; g_friends[k].swap = false; }
                        if (swap && own[k] && !listed && g_friends_here.load() && !g_late[k].pending) {
                            g_late[k] = LateSpawn{}; g_late[k].swap_old = own[k];
                            mplog("[mp] friend %d changed cars: building the new one next to the old\n", k);
                        }
                    }
                    if (!listed && (!own[k] || g_late[k].swap_old) && g_friends_here.load()) {
                        bool need; std::vector<std::uint8_t> carb;
                        { std::lock_guard lock(g_lock); need = g_friends[k].want && (!g_friends[k].built || g_late[k].swap_old) && !g_friends[k].car.empty(); if (need) carb = g_friends[k].car; }
                        LateSpawn &ls = g_late[k];
                        const std::uint32_t rcm = ld32(0x004D93FCu);
                        if (ls.free_id >= 0 && rcm && rcm < ps2::kRamSize) {   // the released slot frees itself once its files leave memory
                            // (the game frees it once that car's files leave memory - never, while another car of the same model is
                            // loaded: then after ~10 s just ask anyway, the spare slot takes it)
                            if (guest_call(c, 0x002E79B8u, {rcm, static_cast<std::uint32_t>(ls.free_id)}) == 1 || ++ls.waited > 45) { ls.free_id = -1; ls.waited = 0; } else need = false;
                        }
                        if (need && !ls.pending && !ls.failed && rcm && rcm < ps2::kRamSize) {
                            const std::uint32_t drv = guest_call(c, 0x0021DF08u, {0x2Cu}), req = guest_call(c, 0x0021DF08u, {0x150u}), parts = guest_call(c, 0x0021DF08u, {0x10u});
                            if (drv && req && parts && drv < ps2::kRamSize && req < ps2::kRamSize && parts < ps2::kRamSize) {
                                guest_call(c, 0x001ACD10u, {drv, 1u});
                                const std::uint32_t rec = ld32(drv + 0xC);
                                if (ld32(drv + 8) == 0x0052AC38u && rec && rec < ps2::kRamSize) {
                                    g_fs_in = carb; g_fs_pos = 0;
                                    guest_call(c, 0x0031DFC0u, {rec, kFakeStream});
                                    g_fs_in.clear(); g_fs_pos = 0;
                                    guest_call(c, 0x002E5DE0u, {req});
                                    st32(parts, 0);
                                    guest_call(c, 0x00142778u, {rec, parts, req});
                                    st32(req + 0x114, ld32(req + 0x114) | 0x20u);   // player-quality detail, like a human car
                                    const std::int32_t id = static_cast<std::int32_t>(guest_call(c, 0x002E5B38u, {rcm, req, 0u}));
                                    mplog("[mp] friend %d joined late: building his car while we drive (model %X, request id %d)\n", k, ld32(rec + 0x1C), id);
                                    if (id < 0) {
                                        ls.failed = true;
                                        if (ls.swap_old) { mplog("[mp] friend %d: no free car slot, keeping his old car until the next load\n", k); ls.swap_old = 0; }
                                    } else { ls.pending = true; ls.id = id; ls.waited = 0; }
                                } else ls.failed = true;
                            } else ls.failed = true;
                        }
                        if (ls.pending) {
                            const std::uint32_t built = guest_call(c, 0x00244478u, {0x005C9580u, static_cast<std::uint32_t>(ls.id)});
                            if (built && built < ps2::kRamSize && ld32(built + 8) == kCarVtable) {
                                guest_call(c, 0x00198F48u, {built});           // parts pass (step 20)
                                st32(built + 0x90C, 1);
                                guest_call(c, 0x00196CF0u, {built, 2u});       // GSRaceBrain, like a LAN remote car
                                guest_call(c, 0x00271B48u, {built});           // Activate: shown, physics on
                                if (ls.swap_old && ls.swap_old != built && ld32(ls.swap_old + 8) == kCarVtable) {   // new car is in: drop the old one
                                    const std::uint32_t old = ls.swap_old, rcm2 = ld32(0x004D93FCu);
                                    const std::int32_t oid = static_cast<std::int16_t>(ld32(old + 0x21C) & 0xFFFFu);
                                    if (g_radar[k].car == old) radar_drop(c, k);   // the radar keeps a raw pointer: off it before the car is freed
                                    { std::lock_guard lock(g_lock); g_friend_puppets[k] = 0; g_puppets.erase(old); }
                                    g_drive[k] = FriendDrive{};
                                    for (std::uint32_t mgr : {ld32(0x004D9408u), ld32(0x004D940Cu)}) if (mgr && mgr < ps2::kRamSize) guest_call(c, 0x002FB0F0u, {mgr, old});
                                    guest_call(c, 0x00271CD0u, {old});
                                    if (rcm2 && rcm2 < ps2::kRamSize) guest_call(c, 0x002E7918u, {rcm2, static_cast<std::uint32_t>(oid), 1u, 1u});
                                    mplog("[mp] friend %d: new car %08X in, old car %08X (id %d) released\n", k, built, old, oid);
                                    ls.swap_old = 0;
                                }
                                own[k] = built; ls.pending = false; late_ready = true;
                                mplog("[mp] friend %d late car ready: %08X after %d ticks\n", k, built, ls.waited);
                            } else if (++ls.waited > 600) { ls.pending = false; ls.failed = true; ls.swap_old = 0; mplog("[mp] friend %d late car never arrived (id %d)\n", k, ls.id); }
                        }
                    }
                    std::uint32_t car;
                    { std::lock_guard lock(g_lock); if (!g_friends[k].built && !listed && !late_ready) own[k] = 0; car = own[k]; }
                    if (!car || car >= ps2::kRamSize || ld32(car + 8) != 0x00521480u) { own[k] = 0; continue; }
                    Pose p; bool want;
                    { std::lock_guard lock(g_lock); want = g_friends[k].want; p = g_friends[k].pose; g_friends[k].built = car; }
                    if (!want) { p = Pose{}; p.rot[0][0] = p.rot[1][1] = p.rot[2][2] = 1; p.pos[1] = -500; }   // nobody: parked out of sight
                    // a car whose state (+0x8FC) is 0 counts as not started: each frame the game parks it and hides it
                    // (0x311E80, then vtable +0x74 clears its shown byte +0xD); 2 is a car on the road, like mine
                    // what the game itself does for a LAN race's remote car (0x196AC8, "disabling switch to LOD0 on
                    // RaceCar for NET race"): +0x90C = 1. Without it the car's vt+0x100 (0x275AF8) drops it to level 0
                    // every frame (0x273A98 -> 0x311E80 parks it at 0,0,0), and he only showed on the frames we put
                    // him back - blinking in and out.
                    st32(car + 0x90C, 1);
                    if (ld32(car + 0x8FC) == 0) st32(car + 0x8FC, 2);
                    if (g_friend_physics.load()) {
                        // LAN way (3.5-ar): the car is awake and the game's own physics moves it; each frame (hook on
                        // mover vt+0x1B8, friend_drive) we steer its speed toward his spot, like a LAN remote car.
                        { std::lock_guard lock(g_lock); g_puppets.erase(car); g_friend_puppets[k] = car; }
                        // shown while his player is here - and near: past 500 m he's too far to see, has no road loaded under
                        // him on our side, and drawing him costs a whole car (body parts + wheels + 2 extra passes) every frame
                        bool near = true;
                        if (const std::uint32_t me = ld32(0x005FAE70u); me && me < ps2::kRamSize) {
                            const float dx = ldf(car + 0x40) - ldf(me + 0x40), dz = ldf(car + 0x48) - ldf(me + 0x48);
                            near = !(dx * dx + dz * dz > 500.0f * 500.0f);
                        }
                        st8(car + 0xD, want && near ? 1 : 0);
                        if (want) radar_show(c, k, car); else if (g_radar[k].car) radar_drop(c, k);
                        continue;
                    }
                    for (int r = 0; r < 3; ++r) for (int q = 0; q < 3; ++q) stf(car + 0x10 + r * 16 + q * 4, p.rot[r][q]);
                    for (int q = 0; q < 3; ++q) stf(car + 0x40 + q * 4, p.pos[q]);
                    // and again right after the game's own update of this car (it copies the body into the matrix)
                    { std::lock_guard lock(g_lock); g_puppets[car] = p; g_friend_puppets[k] = car; }
                    const std::uint32_t mover = ld32(car + 0xF0), body = mover && mover < ps2::kRamSize ? ld32(mover + 0x28) : 0;
                    if (body && body < ps2::kRamSize) {
                        // rotation rows (right, up, forward) -> quaternion (x, y, z, w)
                        const float m00 = p.rot[0][0], m01 = p.rot[0][1], m02 = p.rot[0][2], m10 = p.rot[1][0], m11 = p.rot[1][1], m12 = p.rot[1][2],
                                    m20 = p.rot[2][0], m21 = p.rot[2][1], m22 = p.rot[2][2];
                        float qx, qy, qz, qw; const float tr = m00 + m11 + m22;
                        if (tr > 0) { const float s4 = std::sqrt(tr + 1.0f) * 2; qw = 0.25f * s4; qx = (m12 - m21) / s4; qy = (m20 - m02) / s4; qz = (m01 - m10) / s4; }
                        else if (m00 > m11 && m00 > m22) { const float s4 = std::sqrt(1.0f + m00 - m11 - m22) * 2; qw = (m12 - m21) / s4; qx = 0.25f * s4; qy = (m01 + m10) / s4; qz = (m20 + m02) / s4; }
                        else if (m11 > m22) { const float s4 = std::sqrt(1.0f + m11 - m00 - m22) * 2; qw = (m20 - m02) / s4; qx = (m01 + m10) / s4; qy = 0.25f * s4; qz = (m12 + m21) / s4; }
                        else { const float s4 = std::sqrt(1.0f + m22 - m00 - m11) * 2; qw = (m01 - m10) / s4; qx = (m20 + m02) / s4; qy = (m12 + m21) / s4; qz = 0.25f * s4; }
                        for (std::uint32_t base : {0x10u, 0x60u}) for (int q = 0; q < 3; ++q) stf(body + base + q * 4, p.pos[q]);
                        for (std::uint32_t base : {0x20u, 0x70u}) { stf(body + base, qx); stf(body + base + 4, qy); stf(body + base + 8, qz); stf(body + base + 12, qw); }
                        // speed: their real velocity (so the game turns the wheels), no spin
                        for (int q = 0; q < 6; ++q) stf(body + 0x30 + q * 4, q < 3 && want ? p.vel[q] : 0.0f);
                        // ghost mode (no ramming): a friend's car weighs 1 kg here (body +0xF8 = 1 / mass, +0x100..+0x108 =
                        // 1 / spin resistance; a real car is ~1270 kg). If his body ever takes part in crashes, hitting him
                        // is like hitting a cardboard box: you don't feel it, and his spot is put back every frame anyway.
                        // (Tested: today his body doesn't take part at all - this keeps it that way if that changes.)
                        stf(body + 0xF8, 1.0f);
                        for (int q = 0; q < 3; ++q) stf(body + 0x100 + q * 4, 4.0f);
                    }
                    // his BODY is a separate model (car + 0x104) that only SetPosition / SetOrientation move
                    // (car vtable +0x298 = 0x23D030, +0x2A0 = 0x23D410): without this it stays where it was built
                    if (ld32(car + 0x104)) { guest_call(c, 0x0023D030u, {car}); guest_call(c, 0x0023D410u, {car}); }
                    // and the world draw (0x243E18) skips anything whose shown byte (+0xD) is 0: the game clears it while
                    // he is parked out of sight, and nothing turns it back on. Shown while his player is here.
                    st8(car + 0xD, want ? 1 : 0);
                }
            }
            {
                std::vector<GuestCallReq> calls;
                { std::lock_guard lock(g_lock); calls.swap(g_calls); }
                for (const GuestCallReq &q : calls) {
                    std::uint32_t r = 0;
                    switch (q.n) {
                    case 0: r = guest_call(c, q.fn, {}); break;
                    case 1: r = guest_call(c, q.fn, {q.args[0]}); break;
                    case 2: r = guest_call(c, q.fn, {q.args[0], q.args[1]}); break;
                    case 3: r = guest_call(c, q.fn, {q.args[0], q.args[1], q.args[2]}); break;
                    case 4: r = guest_call(c, q.fn, {q.args[0], q.args[1], q.args[2], q.args[3]}); break;
                    default: r = guest_call(c, q.fn, {q.args[0], q.args[1], q.args[2], q.args[3], q.args[4], q.args[5]}); break;
                    }
                    mplog("[mp] call %08X(%08X %08X %08X %08X %08X %08X) -> %08X\n", q.fn, q.args[0], q.args[1], q.args[2], q.args[3], q.args[4], q.args[5], r);
                    g_call_result.store(r);
                    g_call_done.fetch_add(1);
                }
            }
            const int model = g_spawn_model.exchange(-1);
            const std::uint32_t mode = g_spawn_mode.load();
            if (model >= 0 && mode) {
                const int id = g_spawn_id.load();
                const std::uint32_t desc = guest_call(c, kModelDesc, {static_cast<std::uint32_t>(model)});
                std::uint32_t w[4]; desc_words(desc, w);
                mplog("[mp] spawn model %d -> desc %08X [%08X %08X %08X %08X] id %d\n", model, desc, w[0], w[1], w[2], w[3], id);
                const std::uint32_t ent = guest_call(c, kSpawnCar, {mode, desc, static_cast<std::uint32_t>(id), 0u, 0xFFFFFFFFu});
                mplog("[mp] spawned entity %08X\n", ent);
            }
            return false;
        });
    }
    set_hook(kStreamReserve, [](Cpu &c) {
        if (c.r[4].w[0] != kFakeStream) return false;
        c.r[2].sd[0] = 1;
        return true;
    });
    set_hook(kStreamWrite, [](Cpu &c) {
        if (c.r[4].w[0] != kFakeStream) return false;
        const std::uint32_t src = c.r[6].w[0], n = c.r[7].w[0];
        for (std::uint32_t i = 0; i < n && i < 4096; ++i) g_fs_out.push_back(ld8(src + i));
        c.r[2].sd[0] = 1;
        return true;
    });
    set_hook(kStreamRead, [](Cpu &c) {
        if (c.r[4].w[0] != kFakeStream) return false;
        const std::uint32_t dst = c.r[5].w[0], n = c.r[6].w[0];
        for (std::uint32_t i = 0; i < n && i < 4096; ++i) st8(dst + i, g_fs_pos < g_fs_in.size() ? g_fs_in[g_fs_pos++] : 0);
        c.r[2].sd[0] = 1;
        return true;
    });
    set_hook(kWriteGameData, [](Cpu &c) {
        const int want = g_career_car.load();
        if (want < 0) return false;
        const std::uint32_t player = c.r[4].w[0];
        const std::uint32_t mgr = ld32(kCarManager);
        if (!mgr || mgr >= ps2::kRamSize) return false;
        std::uint32_t id = static_cast<std::uint32_t>(want);
        if (!id) {   // first car in the garage (custom car list at manager + 0x50)
            const std::uint32_t list = ld32(mgr + 0x50), count = ld32(mgr + 0x54);
            if (list && list < ps2::kRamSize && count && count < 64) { const std::uint32_t car0 = ld32(list); if (car0 && car0 < ps2::kRamSize) id = ld32(car0); }
        }
        if (!id) return false;
        const std::uint32_t car = guest_call(c, kCustomById, {mgr, id});
        const std::uint32_t entry = guest_call(c, kGetCarData, {player});
        mplog("[mp] career car: player %08X entry %08X custom %X -> %08X (was %08X)\n", player, entry, id, car, entry && entry < ps2::kRamSize ? ld32(entry + 0xC) : 0u);
        if (car && entry && entry < ps2::kRamSize && car < ps2::kRamSize) st32(entry + 0xC, car);
        return false;   // the original now writes the career car
    });
    set_hook(0x001B8838u, [](Cpu &c) {
        const std::uint32_t self = c.r[4].w[0];
        if (!self || self >= ps2::kRamSize) return false;
        static std::uint32_t last_state = 0xFFFFFFFFu;
        const std::uint32_t state = ld32(self + 0x210);
        if (state != last_state) {
            last_state = state; mplog("[mp] load state %08X: %u slots %08X %08X %08X %08X\n", self, state, ld32(self + 0x2A8), ld32(self + 0x2AC), ld32(self + 0x2B0), ld32(self + 0x2B4));
            if (state == 47) {   // city loaded: how full is the Graphics bank (0x4D92BC)?
                const std::uint32_t g = ld32(0x004D92BCu);
                if (g && g < ps2::kRamSize) {
                    const std::uint32_t tab = ld32(g + 0x5C), n = ld32(g + 0x60);
                    std::uint32_t used = 0;
                    for (std::uint32_t i = 0; tab && tab < ps2::kRamSize && i < n && i < 8192; ++i) used += ld32(tab + i * 0x14) & 1u;
                    mplog("[mp] Graphics bank: %u of %u slots used\n", used, n);
                }
            }
        }
        if (!ld32(self + 0x2A8)) return false;
        // the extra room is only for building the cars (race car manager, made in state 18; models requested in 19, cars
        // made in 20 once every model is in - with the count back at 1 too soon, a friend's own model never arrived): after that this + 0x284
        // goes back to 1 player, or the menus and the map wait for a second player's pad that never comes
        static std::uint32_t players_before = 0;
        static const std::uint32_t restore_at = [] { const char *e = std::getenv("PS2_MP_RESTORE"); return e ? static_cast<std::uint32_t>(std::atoi(e)) : 21u; }();
        if (state >= restore_at && players_before && ld32(self + 0x284) != players_before) { st32(self + 0x284, players_before); mplog("[mp] players back to %u after building friends' cars\n", players_before); players_before = 0; }
        if (state == 0) {
            { std::lock_guard lock(g_lock); for (auto &fp : g_friend_puppets) { if (fp) g_puppets.erase(fp); fp = 0; } for (auto &d : g_drive) d = FriendDrive{}; for (auto &l : g_late) l = LateSpawn{}; for (auto &r : g_radar) r = RadarDot{}; }   // last load's friend cars are gone (the HUD reloads its target list too)
            // a fresh load: make each friend a driver of their own (copies of mine wearing their car)
            const std::uint32_t h0 = ld32(self + 0x2A8), d0 = ld32(h0 + 0xC);
            // Friends only come along into free roam (the city: no SDEvent at this+0x27C). Shops, garages and races
            // load with an event; a friend's car there took over the shop's car camera (part previews showed the street).
            const std::uint32_t event = ld32(self + 0x27C);
            char sub[33] = {}; for (int k = 0; k < 32; ++k) { sub[k] = static_cast<char>(ld8(self + 0x234 + k)); if (!sub[k]) break; }
            // Career's city itself is an event too: the Hub ("hb000"). Friends come along there; shops, garages and races
            // (other events) stay friend-free.
            const bool hub = sub[0] == 'h' && sub[1] == 'b';
            const bool friends_here = !event || hub;
            mplog("[mp] loading: event %08X sub \"%s\" -> %s\n", event, sub, friends_here ? "city, friends come along" : "no friends here");
            g_friends_here.store(friends_here ? 1 : 0);
            for (int i = 1; i < 4; ++i) {
                // every load frees last load's cars: forget the friend's car now, even when he doesn't come along
                // (a shop / race). Before, a warp into a shop kept his dead car, and we kept writing into it and
                // calling its SetPosition while the next place loaded - the city came back frozen.
                { std::lock_guard lock(g_lock); g_friends[i].built = 0; }
                if (!friends_here) { g_load_slot[i].store(0); continue; }
                std::vector<std::uint8_t> car;
                { std::lock_guard lock(g_lock); car = g_friends[i].car; g_friends[i].built = 0; }
                if (car.empty() || !d0 || d0 >= ps2::kRamSize) { g_load_slot[i].store(0); continue; }
                // his driver is the game's own LAN remote-player driver, built exactly like the game does it (the
                // "NetDriver" factory 0x1A9B10: 0x2C bytes, GSNetDriverData_c ctor 0x1ACD10(drv, 1), which also makes
                // its one car record at drv + 0xC), and his car record is read from his stream like ReadGameData does
                // (record vt+0x78 = 0x31DFC0). Before, his driver was a copy of MY player driver, so the game ran his
                // car like a local player's (mover +0x270 = 3) and skipped a remote car's per-frame steps
                // (vt+0x1A0/+0x1A8/+0x1B0: road checks for the wheels...) - his wheels never followed him.
                const std::uint32_t drv = guest_call(c, 0x0021DF08u, {0x2Cu}), h = guest_call(c, 0x0021DF08u, {0x20u});
                if (!drv || !h || drv >= ps2::kRamSize || h >= ps2::kRamSize) continue;
                guest_call(c, 0x001ACD10u, {drv, 1u});
                const std::uint32_t obj = ld32(drv + 0xC);
                if (ld32(drv + 8) != 0x0052AC38u || !obj || obj >= ps2::kRamSize) { mplog("[mp] friend %d: net driver build failed (vt %08X rec %08X)\n", i, ld32(drv + 8), obj); continue; }
                g_fs_in = car; g_fs_pos = 0;
                guest_call(c, 0x0031DFC0u, {obj, kFakeStream});
                for (std::uint32_t k = 0; k < 0x20; k += 4) st32(h + k, ld32(h0 + k));
                st32(h + 0xC, drv); st32(h + 0x14, 0); st32(h + 0x18, drv);
                g_load_slot[i].store(h);
                mplog("[mp] friend %d: car %08X (%u bytes, model %X) driver %08X handle %08X\n", i, obj, static_cast<unsigned>(car.size()), ld32(obj + 0x1C), drv, h);
            }
        }
        for (int i = 1; i < 4; ++i) {
            const std::uint32_t h = g_load_slot[i].load();
            if (h && !ld32(self + 0x2A8 + i * 4)) { st32(self + 0x2A8 + i * 4, h); mplog("[mp] load slot %d <- %08X (state %u)\n", i, h, state); }
            // the race car manager is made with room for this + 0x284 cars (1 in Career): make room for the extra ones
            if (h && ld32(self + 0x284) < static_cast<std::uint32_t>(i + 1) && state < 18) { if (!players_before) players_before = ld32(self + 0x284); st32(self + 0x284, i + 1); mplog("[mp] race car room -> %d\n", i + 1); }
        }
        // in the city: always room for 3 friends' cars, so a friend who comes later can be built while we drive
        // ONE spare: 4 spares (3.5-at) ran the Graphics bank dry - my own car never finished streaming (entry stuck in
        // state 3) and the load sat at step 20 forever. One extra car is what a friend at load already costs, and works.
        static bool spared = false;
        if (state == 0) spared = false;
        if (!spared && state >= 1 && state < 18 && g_friends_here.load() && ld32(self + 0x284) && ld32(self + 0x284) < kRaceCarRoom) {
            if (!players_before) players_before = ld32(self + 0x284);
            st32(self + 0x284, ld32(self + 0x284) + 1); spared = true;
            mplog("[mp] race car room -> %u (one spare for a late friend)\n", ld32(self + 0x284));
        }
        return false;
    });
    set_hook(kCustomById, [](Cpu &c) {
        {   // research: log each new (id, caller) pair once
            static std::unordered_map<std::uint64_t, int> seen;
            const std::uint64_t k = (static_cast<std::uint64_t>(c.r[5].w[0]) << 32) | c.r[31].w[0];
            if (seen.size() < 400 && !seen.count(k)) { seen[k] = 1; mplog("[mp] CustomById id %X ra %08X\n", c.r[5].w[0], c.r[31].w[0]); }
        }
        std::lock_guard lock(g_lock);
        auto it = g_custom_override.find(c.r[5].w[0]);
        if (it == g_custom_override.end()) return false;
        c.r[2].sd[0] = static_cast<std::int32_t>(it->second);
        return true;
    });
}
}

bool camera_pose(float out[12]) {
    if (ld32(kViewCam + 8) != kCamVtable) return false;
    for (int i = 0; i < 12; ++i) out[i] = ldf(kViewCam + 0x10 + (i / 3) * 16 + (i % 3) * 4);
    return true;
}

void online_debug_log() {
    static const bool on = std::getenv("PS2_MP_LOG") != nullptr;
    if (!on) return;
    if (ps2::frames_run() % 60) return;
    Pose p; int w = 0;
    const bool ok = local_pose(p, w);
    float cam[12] = {};
    camera_pose(cam);
    std::fprintf(stderr, "[mp] frame %llu local %s car %08X pos %.1f %.1f %.1f world %d cam %.1f %.1f %.1f hits",
                 static_cast<unsigned long long>(ps2::frames_run()), ok ? "yes" : "no", local_car(), p.pos[0], p.pos[1], p.pos[2], w, cam[9], cam[10], cam[11]);
    for (auto &h : g_cruise_hits) std::fprintf(stderr, " %u", h.exchange(0));
    std::fprintf(stderr, "\n");
}

bool local_pose(Pose &out, int &world) {
    const std::uint32_t car = local_car();
    if (!car || !read_car(car, out)) return false;
    // velocity from the physics body (mover at +0xF0, body at mover+0x28, velocity at body+0x30)
    const std::uint32_t mover = ld32(car + 0xF0), body = mover && mover < ps2::kRamSize ? ld32(mover + 0x28) : 0;
    if (body && body < ps2::kRamSize) for (int k = 0; k < 3; ++k) out.vel[k] = ldf(body + 0x30 + k * 4);
    world = current_world();
    return true;
}

void set_remote(int slot, const Pose &pose, bool present) {
    if (slot < 0 || slot >= kSlots) return;
    std::lock_guard lock(g_lock);
    Slot &s = g_slots[slot];
    s.want = present;
    s.pose = pose;
    if (!present && s.car) { g_puppets.erase(s.car); s.car = 0; s.has_wrote = false; }
    // the car it used stopped updating (despawned): find another one
    if (s.car && g_tick - s.car_seen > 200) { g_puppets.erase(s.car); s.car = 0; s.has_wrote = false; }
}

std::uint32_t player_car() { return local_car(); }

void request_spawn(int model, int id) { g_spawn_id.store(id); g_spawn_model.store(model); }
void queue_call(std::uint32_t fn, const std::uint32_t *args, int n) {
    GuestCallReq q{fn, {}, n};
    for (int i = 0; i < n && i < 6; ++i) q.args[i] = args[i];
    std::lock_guard lock(g_lock);
    g_calls.push_back(q);
}
void request_probe(std::uint32_t addr, int n) { std::lock_guard lock(g_lock); g_probe_reqs.push_back({addr, n}); }
std::uint32_t call_result(int &done) { done = g_call_done.load(); return g_call_result.load(); }
std::vector<std::uint8_t> stream_take() { std::vector<std::uint8_t> v; v.swap(g_fs_out); return v; }
void stream_feed(const std::uint8_t *p, int n) { g_fs_in.assign(p, p + n); g_fs_pos = 0; }
void set_custom_override(std::uint32_t id, std::uint32_t obj) {
    std::lock_guard lock(g_lock);
    if (obj) g_custom_override[id] = obj; else g_custom_override.erase(id);
}
void set_career_car(int id) { g_career_car.store(id); }
void set_friend_unlist(int on) { g_friend_unlist.store(on); }
void set_friend_car(int slot, const std::uint8_t *p, int n) {
    if (slot < 1 || slot > 3) return;
    std::lock_guard lock(g_lock);
    std::vector<std::uint8_t> nw(p, p + (n > 0 ? n : 0));
    // he changed cars (dealership / Robo Garage) while his old car is in our city: swap it right away (friend loop)
    if (g_friends[slot].built && !nw.empty() && !g_friends[slot].car.empty() && nw != g_friends[slot].car) g_friends[slot].swap = true;
    g_friends[slot].car.swap(nw);
}
void set_friend_pose(int slot, const Pose &pose, bool present) {
    if (slot < 1 || slot > 3) return;
    // a pose that isn't a real number (seen once while he was in a garage: +inf) would throw his car to infinity: keep the last good one
    if (present) {
        for (float v : pose.pos) if (!std::isfinite(v) || std::fabs(v) > 1e6f) return;
        for (const auto &r : pose.rot) for (float v : r) if (!std::isfinite(v)) return;
        for (float v : pose.vel) if (!std::isfinite(v)) return;
    }
    std::lock_guard lock(g_lock); g_friends[slot].want = present; g_friends[slot].pose = pose;
}
// he came back into the world from a loading screen (garage, shop, dealership, race): rebuild his car fresh
void refresh_friend(int slot) { if (slot < 1 || slot > 3) return; std::lock_guard lock(g_lock); if (g_friends[slot].built) g_friends[slot].swap = true; }
std::uint32_t friend_built(int slot) { if (slot < 1 || slot > 3) return 0; std::lock_guard lock(g_lock); return g_friends[slot].built; }
// only while driving and not paused: a press in the map or pause menu is dropped (it used to wait and fire on unpause)
void camera_next() { if (ld32(0x004DDC2Cu) == 1 && ld32(0x004DDBC4u) == 0) g_cam_next.store(1); }
// friends' pause-map arrows: n, then per friend {slot, cx, cy, w, h, deg, alpha 0..1} as floats
int pausemap_friends(float *out, int max) {
    if (!pausemap()) return 0;
    std::lock_guard lock(g_lock);
    int n = 0;
    for (int i = 0; i < g_pm_n && n < max; ++i, ++n) {
        const PmFriend &f = g_pm[i]; float *o = out + n * 7;
        o[0] = static_cast<float>(f.slot); o[1] = f.cx; o[2] = f.cy; o[3] = f.w; o[4] = f.h; o[5] = f.deg;
        o[6] = std::min(1.0f, static_cast<float>(f.rgba >> 24) / 128.0f);
    }
    return n;
}
std::uint32_t pausemap() { const std::uint64_t f = g_pausemap_frame.load(); return f && ps2::frames_run() - f <= 3 ? g_pausemap_r.load() : 0u; }
std::vector<std::uint8_t> my_state() { std::lock_guard lock(g_lock); return g_my_state; }
void set_friend_state(int slot, const std::uint8_t *p, int n) {
    if (slot < 1 || slot > 3 || !p || n <= 0 || n > 1024) return;
    std::lock_guard lock(g_lock); g_friend_state[slot].assign(p, p + n); g_friend_state_new[slot] = true;
}
std::vector<std::uint8_t> my_car() { g_my_car_req.store(1); std::lock_guard lock(g_lock); return g_my_car; }
// career room, friends on load: the world loader (virtual 0x1B8838, this = load state) builds a race car for each
// filled entry of its 4-slot driver list at this + 0x2A8 (slot 0 = you). Before it runs, empty slots 1-3 get the
// driver handles the page asked for, so the game builds those cars itself while the city loads.
void set_load_slot(int slot, std::uint32_t handle) { if (slot > 0 && slot < 4) g_load_slot[slot].store(handle); }
// research: make a player slot borrow one particular car (0 = any)
void force_slot_car(int slot, std::uint32_t car) {
    if (slot < 0 || slot >= kSlots) return;
    std::lock_guard lock(g_lock);
    Slot &s = g_slots[slot];
    if (s.car) g_puppets.erase(s.car);
    s.car = car; s.has_wrote = false; s.car_seen = g_tick;
    g_bad_cars.erase(car);
}
// research: every car the game updated recently (object, vptr) - up to max pairs
int live_cars(std::uint32_t *out, int max) {
    std::lock_guard lock(g_lock);
    int n = 0;
    for (auto &kv : g_live) {
        if (g_tick - kv.second > 120 || n >= max) continue;
        out[n * 2] = kv.first; out[n * 2 + 1] = ld32(kv.first + 8); ++n;
    }
    return n;
}
std::string take_log() { std::lock_guard lock(g_log_lock); std::string s; s.swap(g_log); return s; }

std::uint32_t slot_car(int slot) {
    if (slot < 0 || slot >= kSlots) return 0;
    std::lock_guard lock(g_lock);
    return g_slots[slot].want ? g_slots[slot].car : 0;
}


namespace {
struct Stamp { float cam[12] = {}; float loc[16] = {}; bool cam_ok = false, loc_ok = false; };
constexpr std::uint32_t kStamps = 32;
Stamp g_stamps[kStamps];
std::mutex g_stamp_lock;
std::atomic<std::uint32_t> g_shown{0};
std::atomic<bool> g_any_shown{false};
}

void note_frame(std::uint32_t seq) {
    install_probes();   // game thread: safe place to add hooks the page asked for
    Stamp s;
    s.cam_ok = camera_pose(s.cam);
    Pose p; int w = 0;
    if ((s.loc_ok = local_pose(p, w))) {
        std::memcpy(s.loc, p.pos, 12); std::memcpy(s.loc + 3, p.rot, 36); std::memcpy(s.loc + 12, p.vel, 12);
        s.loc[15] = static_cast<float>(w);
    }
    std::lock_guard lock(g_stamp_lock);
    g_stamps[seq % kStamps] = s;
}

void note_shown(std::uint32_t seq) {
    g_shown.store(seq, std::memory_order_relaxed);
    g_any_shown.store(true, std::memory_order_relaxed);
}

bool shown_camera(int back, float out[12]) {
    if (!g_any_shown.load(std::memory_order_relaxed)) return camera_pose(out);
    std::lock_guard lock(g_stamp_lock);
    const Stamp &s = g_stamps[(g_shown.load(std::memory_order_relaxed) - static_cast<std::uint32_t>(back)) % kStamps];
    if (!s.cam_ok) return false;
    std::memcpy(out, s.cam, sizeof s.cam);
    return true;
}

bool shown_local(int back, float out[16]) {
    std::lock_guard lock(g_stamp_lock);
    const Stamp &s = g_stamps[(g_shown.load(std::memory_order_relaxed) - static_cast<std::uint32_t>(back)) % kStamps];
    if (!s.loc_ok) return false;
    std::memcpy(out, s.loc, sizeof s.loc);
    return true;
}

}
