#include "ps2/generated.hpp"
#include "ps2/vu_ops.hpp"
#include "ps2/disc.hpp"
#include "ps2/state_request.hpp"
#include "ps2/system.hpp"
#include "ps2/video.hpp"
#include "../runtime/src/iop/dev9.hpp"
#include "../runtime/src/iop/iop.hpp"

#include <emscripten.h>
#include <emscripten/threading.h>
#include <pthread.h>
#include <unistd.h>

#include <algorithm>
#include <mutex>
#include <deque>
#include <atomic>
#include <cstring>
#include "ps2/mp.hpp"
#include "ps2/memory.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
namespace ps2::gs::queue { void flush_gathered(); }
namespace ps2::gs { extern std::atomic<std::uint32_t> g_presented; extern std::uint32_t g_posted_presents; }
std::atomic<int> g_uncap{0};   // benchmark: no frame pacing, so the frame counter shows how fast it can really go
std::atomic<int> g_pace_present{1};   // even frame spacing on screen (see the render loop in main)

void register_generated_code();
void register_generated_vu();

EM_JS_DEPS(ps2web, "$stringToNewUTF8,$UTF8ToString,$findCanvasEventTarget");

EM_JS(void, ps2web_fetch, (const char *url, double offset, int size, void *out, std::atomic<std::uint32_t> *state), {
    const target = UTF8ToString(url);
    const finish = (value) => {
        Atomics.store(HEAP32, state >> 2, value);
        Atomics.notify(HEAP32, state >> 2);
    };
    if (Module.discRead) {
        // the page supplies the disc (the player's own ISO kept in browser storage, or the game server)
        Module.discRead(offset, size).then((bytes) => {
            HEAPU8.set(bytes.subarray(0, Math.min(bytes.length, size)), out);
            finish(3);
        }).catch((e) => {
            console.warn('disc read failed', e);
            finish(4);
        });
        return;
    }
    fetch(target, {headers: {Range: 'bytes=' + offset + '-' + (offset + size - 1)}})
        .then((response) => {
            if (response.status !== 206 && response.status !== 200) throw new Error('status ' + response.status);
            return response.arrayBuffer().then((buffer) => {
                let bytes = new Uint8Array(buffer);
                if (response.status === 200) bytes = bytes.subarray(offset, offset + size);
                HEAPU8.set(bytes.subarray(0, Math.min(bytes.length, size)), out);
                finish(3);
            });
        })
        .catch((e) => {
            console.warn('disc read failed', e);
            finish(4);
        });
});

// A VU1 program the build lacks: keep a copy on the page (main thread) for the performance report,
// so it can be baked into the next build. No network, no waiting.
int ps2web_save_program(const char *name, const std::uint8_t *code, int size) {
    return MAIN_THREAD_EM_ASM_INT({
        try {
            const list = Module.newVuPrograms || (Module.newVuPrograms = []);
            if (list.length >= 100) return 201;
            const bytes = HEAPU8.slice($1, $1 + $2);
            let bin = '';
            for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
            list.push({ name: UTF8ToString($0), data: btoa(bin) });
            return 201;
        } catch (e) { return 0; }
    }, name, code, size);
}

EM_JS(double, ps2web_disc_size, (), { return Module.discSize || 0; });
EM_JS(char *, ps2web_state_url, (), { return Module.stateUrl ? stringToNewUTF8(new URL(Module.stateUrl, location.href).href) : 0; });
EM_JS(double, ps2web_url_size, (const char *url), {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('HEAD', UTF8ToString(url), false);
        xhr.send();
        return xhr.status === 200 ? Number(xhr.getResponseHeader('Content-Length') || 0) : 0;
    } catch (e) {
        return 0;
    }
});
EM_JS(double, ps2web_url_read, (const char *url, std::uint8_t *out, double size), {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', UTF8ToString(url), false);
        xhr.responseType = 'arraybuffer';
        xhr.send();
        if (xhr.status !== 200) return 0;
        const bytes = new Uint8Array(xhr.response);
        HEAPU8.set(bytes.subarray(0, size), out);
        return bytes.length;
    } catch (e) {
        return 0;
    }
});
// the page can keep its memory card somewhere else (the lab uses its own test card so tests never touch the player's)
EM_JS(char *, ps2web_card_path, (), { return stringToNewUTF8(Module.cardPath || "/memcard/Mcd001.ps2"); });
EM_JS(char *, ps2web_disc_url, (), { return stringToNewUTF8(new URL(Module.discUrl, location.href).href); });
EM_JS(void, ps2web_frame_done, (), {
    if (!Module.shownChannel) {
        Module.shownChannel = new MessageChannel();
        Module.shownWaiters = [];
        Module.shownChannel.port1.onmessage = () => {
            Module.shownPending = false;
            const waiters = Module.shownWaiters;
            Module.shownWaiters = [];
            for (const resolve of waiters) resolve();
        };
    }
    Module.shownPending = true;
    requestAnimationFrame(() => Module.shownChannel.port2.postMessage(0));
    if (Module.onFrame) Module.onFrame();
});
// one display refresh, so the picture lands right when the screen wants it. When the browser holds refreshes back
// (window behind another one, not focused, tab hidden, power saving) we don't wait on it at all: the game keeps
// its own steady 60 fps clock instead (it used to fall back to a 20 ms timer = stuck around 43-50 fps).
EM_ASYNC_JS(void, ps2web_wait_tick, (), {
    const g = globalThis, now = performance.now();
    if (!g.__tdRaf) {
        g.__tdRaf = { last: 0, gaps: [] };
        const tick = (t) => { const r = g.__tdRaf; if (r.last) { r.gaps.push(t - r.last); if (r.gaps.length > 30) r.gaps.shift(); } r.last = t; requestAnimationFrame(tick); };
        requestAnimationFrame(tick);
    }
    const r = g.__tdRaf;
    const gaps = r.gaps.slice().sort((a, b) => a - b), mid = gaps.length ? gaps[gaps.length >> 1] : 1000;
    // refreshes are coming steadily at >= ~55 Hz and the last one was recent: line up with the next one
    if (mid > 18.5 || now - r.last > 40) return;
    await new Promise((resolve) => { let done = false; const go = () => { if (!done) { done = true; resolve(); } }; requestAnimationFrame(go); setTimeout(go, 17); });
});
// ms until the browser's next display refresh, from the refresh times ps2web_wait_tick keeps (-1 = unknown / not steady)
EM_JS(double, ps2web_until_vsync, (), {
    const r = globalThis.__tdRaf;
    if (!r || r.gaps.length < 8) return -1;
    const gaps = r.gaps.slice().sort((a, b) => a - b), g = gaps[gaps.length >> 1], now = performance.now();
    if (g > 18.5 || g < 2 || now - r.last > 40) return -1;
    const k = Math.ceil((now - r.last) / g);
    return r.last + Math.max(1, k) * g - now;
});
EM_ASYNC_JS(void, ps2web_wait_shown, (), {
    if (Module.shownPending) await new Promise((resolve) => Module.shownWaiters.push(resolve));
});
EM_JS(void, ps2web_stream_frame, (const std::uint32_t *rgba, int width, int height), {
    if (Module.onStreamFrame) Module.onStreamFrame(HEAPU8.subarray(rgba, rgba + width * height * 4), width, height);
});

EM_JS(void, ps2web_blit, (const std::uint32_t *rgba, int width, int height, int aspect10k), {
    const canvas = Module.canvas;
    if (!Module.blitContext) Module.blitContext = canvas.getContext('2d');
    if (!Module.blitImage || Module.blitImage.width !== width || Module.blitImage.height !== height) {
        Module.blitImage = new ImageData(width, height);
        Module.blitSource = new OffscreenCanvas(width, height);
    }
    Module.blitImage.data.set(HEAPU8.subarray(rgba, rgba + width * height * 4));
    Module.blitSource.getContext('2d').putImageData(Module.blitImage, 0, 0);
    const ctx = Module.blitContext;
    const across = aspect10k / 10000, down = 1;
    const scale = Math.min(canvas.width / across, canvas.height / down);
    const w = scale * across, h = scale * down;
    const sx = Math.max(1, Math.floor(w / width)), sy = Math.max(1, Math.floor(h / height));
    let source = Module.blitSource;
    if (sx > 1 || sy > 1) {
        if (!Module.blitSharp || Module.blitSharp.width !== width * sx || Module.blitSharp.height !== height * sy)
            Module.blitSharp = new OffscreenCanvas(width * sx, height * sy);
        const sharp = Module.blitSharp.getContext('2d');
        sharp.imageSmoothingEnabled = false;
        sharp.drawImage(Module.blitSource, 0, 0, width * sx, height * sy);
        source = Module.blitSharp;
    }
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(source, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
});

namespace {

constexpr std::size_t kChunk = 256u << 10;
constexpr std::uint32_t kSlots = 256;
constexpr std::uint64_t kReadAhead = 16;
constexpr std::uint32_t kAudioFrames = 1u << 14;

enum : std::uint32_t { kEmpty, kWanted, kLoading, kReady, kFailed };

struct Slot {
    std::atomic<std::uint32_t> state{kEmpty};
    std::uint64_t index = 0, used = 0;
    std::uint32_t size = 0;
    std::uint8_t *data = nullptr;
};

struct AudioRing {
    std::atomic<std::uint32_t> write{0}, read{0};
    std::uint32_t capacity = kAudioFrames;
    std::atomic<std::uint32_t> active{0};
    std::int16_t samples[kAudioFrames * 2];
};

AudioRing g_audio;
Slot g_slots[kSlots];
std::uint64_t g_disc_size = 0, g_use_clock = 0, g_last_chunk = ~0ull, g_run = 0;
char *g_disc_url = nullptr;
char *g_state_url = nullptr;

// disc requests wake whichever thread fetches chunks (the page's thread; the drawing thread too in the old layout)
std::atomic<std::uint32_t> g_disc_wake{0};
void wake_disc() {
    g_disc_wake.fetch_add(1);
    emscripten_futex_wake(&g_disc_wake, INT_MAX);
    ps2::wake_render_thread();
}

Slot *find_slot(std::uint64_t index) {
    for (Slot &s : g_slots)
        if (s.state.load(std::memory_order_acquire) != kEmpty && s.index == index) return &s;
    return nullptr;
}

Slot *want(std::uint64_t index) {
    if (index * kChunk >= g_disc_size) return nullptr;
    if (Slot *s = find_slot(index)) return s;
    Slot *victim = nullptr;
    for (Slot &s : g_slots) {
        const std::uint32_t state = s.state.load(std::memory_order_acquire);
        if (state == kEmpty) {
            victim = &s;
            break;
        }
        if ((state == kReady || state == kFailed) && (!victim || s.used < victim->used)) victim = &s;
    }
    if (!victim) return nullptr;
    if (!victim->data) victim->data = new std::uint8_t[kChunk];
    victim->index = index;
    victim->size = static_cast<std::uint32_t>(std::min<std::uint64_t>(kChunk, g_disc_size - index * kChunk));
    victim->used = ++g_use_clock;
    victim->state.store(kWanted, std::memory_order_release);
    wake_disc();
    return victim;
}

void advance(std::uint64_t index) {
    if (index <= g_last_chunk && g_last_chunk - index <= kReadAhead * 4) return;
    g_run = index == g_last_chunk + 1 ? g_run + 1 : 0;
    g_last_chunk = index;
}

void read_ahead(std::uint64_t index) {
    for (std::uint64_t k = 1; k <= std::min(g_run * 2, kReadAhead); ++k) want(index + k);
}

const Slot *chunk(std::uint64_t index) {
    Slot *s = want(index);
    advance(index);
    read_ahead(std::max(index, g_last_chunk));
    for (int attempt = 0; s && attempt < 4; ++attempt) {
        int waited = 0;
        for (std::uint32_t state = s->state.load(); state != kReady && state != kFailed; state = s->state.load()) {
            emscripten_futex_wait(&s->state, state, 1000.0);
            if (++waited == 4 || (waited > 4 && waited % 10 == 0))
                std::fprintf(stderr, "[disc] still waiting %d s for disc chunk %llu (state %u, attempt %d)\n", waited, static_cast<unsigned long long>(index), state, attempt);
        }
        if (s->state.load() == kReady) {
            s->used = ++g_use_clock;
            return s;
        }
        usleep(100000);
        s->state.store(kWanted, std::memory_order_release);
        wake_disc();
    }
    return nullptr;
}

bool disc_ready(std::uint64_t offset, std::size_t size) {
    if (!size) return true;
    const std::uint64_t last = (offset + size - 1) / kChunk;
    bool ready = true;
    for (std::uint64_t index = offset / kChunk; index <= last; ++index) {
        Slot *s = want(index);
        if (s && s->state.load(std::memory_order_acquire) == kFailed) {
            s->state.store(kWanted, std::memory_order_release);
            wake_disc();
        }
        ready = ready && s && s->state.load(std::memory_order_acquire) == kReady;
        advance(index);
    }
    read_ahead(std::max(last, g_last_chunk));
    return ready;
}

std::size_t read_disc(std::uint64_t offset, void *out, std::size_t size) {
    std::size_t done = 0;
    auto *to = static_cast<std::uint8_t *>(out);
    while (done < size && offset + done < g_disc_size) {
        const std::uint64_t at = offset + done;
        const Slot *c = chunk(at / kChunk);
        if (!c) break;
        const std::size_t within = static_cast<std::size_t>(at % kChunk);
        const std::size_t take = std::min<std::size_t>(size - done, c->size - within);
        std::memcpy(to + done, c->data + within, take);
        done += take;
    }
    return done;
}

void service_disc() {
    for (Slot &s : g_slots) {
        std::uint32_t expected = kWanted;
        if (s.state.compare_exchange_strong(expected, kLoading, std::memory_order_acq_rel))
            ps2web_fetch(g_disc_url, static_cast<double>(s.index * kChunk), static_cast<int>(s.size), s.data, &s.state);
    }
}

void push_audio(const std::int16_t *samples, std::size_t frames) {
    if (ps2::intro_turbo() || g_uncap.load(std::memory_order_relaxed)) return;  // fast-forwarded intro: silence instead of chipmunk noise
    std::uint32_t write = g_audio.write.load(std::memory_order_relaxed);
    const std::uint32_t read = g_audio.read.load(std::memory_order_acquire);
    for (std::size_t i = 0; i < frames && write - read < kAudioFrames; ++i, ++write) {
        const std::uint32_t at = (write & (kAudioFrames - 1)) * 2;
        g_audio.samples[at] = samples[i * 2];
        g_audio.samples[at + 1] = samples[i * 2 + 1];
    }
    g_audio.write.store(write, std::memory_order_release);
}

double audio_queued_ms() { return static_cast<double>(g_audio.write.load() - g_audio.read.load()) / 48.0; }

double g_next_frame = 0.0;
std::atomic<double> g_emulation_idle{0.0}, g_render_idle{0.0}, g_render_busy{0.0};
std::atomic<double> g_render_yield{0.0}, g_render_show{0.0}, g_render_yields{0.0}, g_render_tick{0.0};   // lab: drawing thread time handed to the browser / showing frames

void pace() {
    ps2::post_present();
    if (g_uncap.load(std::memory_order_relaxed)) { g_next_frame = 0.0; return; }
    double period = ps2::g_options.pal ? 20.0 : 1000.0 / 59.94;
    if (g_audio.active.load()) {
        // Frames go out on a steady clock, not when the sound card takes its next 10 ms bite (that made frames
        // land 8-40 ms apart: 60 fps on paper, stutter on screen). The sound queue only nudges the clock a hair
        // (at most 2%) so it stays near 60 ms; way too full = catch up the old way.
        const double queued = audio_queued_ms();
        if (queued > 160.0) {
            while (audio_queued_ms() > 80.0) usleep(1000);
            g_next_frame = 0.0;
            return;
        }
        period *= 1.0 + std::clamp((queued - 60.0) / 2000.0, -0.02, 0.02);
    }
    const double now = emscripten_get_now();
    if (g_next_frame == 0.0 || now - g_next_frame > 200.0) g_next_frame = now;
    g_next_frame += period;
    if (g_next_frame > now) usleep(static_cast<useconds_t>((g_next_frame - now) * 1000.0));
}

std::atomic<int> g_paused{0};

// profiling: one row per frame [game work ms, waiting for queue room ms, vu thread idle ms, render idle ms, paced sleep ms]
constexpr int kFrameLog = 1024;
double g_frame_log[kFrameLog][5];
std::atomic<std::uint32_t> g_frame_log_n{0};
double g_last_vblank_end = 0.0, g_last_post_wait = 0.0, g_last_vu_idle = 0.0, g_last_render_idle = 0.0;

void on_vblank() {
    const std::uint32_t prof_fn = ps2::g_ee_fn;
    ps2::g_ee_fn = 1;   // lab profiling: 1 = waiting for the next frame (see PS2_FN)
    ps2::gs::queue::flush_gathered();
    const double start = emscripten_get_now();
    // in-game settings menu open: hold the game at the end of this frame (pace() re-syncs afterwards)
    while (g_paused.load(std::memory_order_relaxed)) usleep(16000);
    if (!ps2::intro_turbo()) pace();
    const double end = emscripten_get_now();
    g_emulation_idle.store(g_emulation_idle.load() + end - start);
    {
        const double post = static_cast<double>(ps2::g_post_wait[0].load() + ps2::g_post_wait[1].load()) / 1000.0;
        const double vu = ps2::vu_thread_idle_ms(), render = g_render_idle.load();
        const std::uint32_t n = g_frame_log_n.load(std::memory_order_relaxed);
        double *row = g_frame_log[n % kFrameLog];
        row[0] = g_last_vblank_end > 0.0 ? start - g_last_vblank_end : 0.0;
        row[1] = post - g_last_post_wait; row[2] = vu - g_last_vu_idle; row[3] = render - g_last_render_idle; row[4] = end - start;
        g_last_post_wait = post; g_last_vu_idle = vu; g_last_render_idle = render; g_last_vblank_end = end;
        g_frame_log_n.store(n + 1, std::memory_order_release);
    }
    ps2::g_ee_fn = prof_fn;
}

struct Launch {
    std::vector<std::string> args;
};

void *emulate(void *data) {
    const Launch &launch = *static_cast<const Launch *>(data);
    if (g_disc_size && !ps2::disc::open("disc", g_disc_size, read_disc, disc_ready)) std::fprintf(stderr, "[web] cannot read the disc image\n");
    std::uint32_t entry = 0;
    ps2::load_patches("/game/patches.txt");
    if (!ps2::load_elf("/game/core.elf", entry)) {
        std::fprintf(stderr, "cannot load the game executable\n");
        return nullptr;
    }
    ps2::boot(entry, launch.args);
    if (g_state_url) {
        const double size = ps2web_url_size(g_state_url);
        std::vector<std::uint8_t> data(static_cast<std::size_t>(size));
        if (size <= 0 || ps2web_url_read(g_state_url, data.data(), size) != size || !ps2::load_state(data.data(), data.size())) {
            std::fprintf(stderr, "[web] cannot load the state %s\n", g_state_url);
            return nullptr;
        }
    }
    ps2::run();
    EM_ASM({
        if (typeof Module.onHalt === 'function')
            Module.onHalt(UTF8ToString($0));
    }, ps2::halt_reason().c_str());
    return nullptr;
}

}

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_pad(int pad, int buttons, int lx, int ly, int rx, int ry) {
    ps2::set_pad_buttons(static_cast<std::uint16_t>(buttons), pad);
    ps2::set_pad_axis(0, static_cast<std::uint8_t>(rx), pad);
    ps2::set_pad_axis(1, static_cast<std::uint8_t>(ry), pad);
    ps2::set_pad_axis(2, static_cast<std::uint8_t>(lx), pad);
    ps2::set_pad_axis(3, static_cast<std::uint8_t>(ly), pad);
}

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_pad_connected(int pad, int connected) { ps2::set_pad_connected(pad, connected != 0); }

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_pressure(int pad, int a, int b, int c, int d) {
    const int packed[4] = {a, b, c, d};
    for (int i = 0; i < 16; ++i) ps2::set_pad_pressure(i, static_cast<std::uint8_t>(static_cast<unsigned>(packed[i / 4]) >> (i % 4 * 8)), pad);
}

extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_rumble(int pad) { return ps2::pad_rumble(pad); }

struct GfxStart {
    bool worker = false, no_surface = false, copy = false, surface = false;
    std::uint32_t width = 0, height = 0;
    std::atomic<int> ready{0};
} g_gfx;
std::atomic<std::uint32_t> g_resize{0};       // page canvas size (w | h << 16) for a worker-owned canvas

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_resize(int width, int height) {
    if (g_gfx.worker) g_resize.store((static_cast<std::uint32_t>(width) & 0xFFFFu) | (static_cast<std::uint32_t>(height) << 16));   // the drawing thread applies it
    else ps2::resize_window(static_cast<std::uint32_t>(width), static_cast<std::uint32_t>(height));
}

extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_quick_state(int loading) {
    return ps2::request_state_operation(loading != 0, "/quicksave.state", [](bool load, bool success) {
        MAIN_THREAD_ASYNC_EM_ASM({
            if (Module.onQuickState) Module.onQuickState(!!$0, !!$1);
        }, load, success);
    }) ? 1 : 0;
}

std::atomic<bool> g_streaming{false};

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_stream(int on) { g_streaming.store(on != 0); }

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_trace_frame() { ps2::request_draw_trace(); }
namespace ps2 { void ctrace(std::uint32_t car_a, std::uint32_t car_b, bool on); }
// research (lab): log every dispatched call that gets a pointer into car A or car B (on = 1 starts, 0 stops)
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_ctrace(std::uint32_t car_a, std::uint32_t car_b, int on) { ps2::ctrace(car_a, car_b, on != 0); }
// Online v0.01: 16 floats = pos[3] rot[9] vel[3] world
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_local(float *out) {
    ps2::mp::Pose p;
    int world = 0;
    if (!ps2::mp::local_pose(p, world)) return 0;
    std::memcpy(out, p.pos, 12); std::memcpy(out + 3, p.rot, 36); std::memcpy(out + 12, p.vel, 12);
    out[15] = static_cast<float>(world);
    return 1;
}
// the game's view camera: 12 floats = right[3] up[3] forward[3] position[3]
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_camera(float *out) { return ps2::mp::camera_pose(out) ? 1 : 0; }
// the camera / local car of the picture on screen (`back` frames earlier), so ghosts line up with what you see
// debugging aid: copy `words` 32-bit words of game memory starting at `addr` into out (returns words copied)
// ---- LAN cable: the emulated PS2 network adapter <-> the page (which talks to the server) ----
namespace {
std::mutex g_lan_lock;
std::deque<std::vector<std::uint8_t>> g_lan_out;   // frames the PS2 sent, waiting for the page
void lan_init() {
    static bool done = false;
    if (done) return;
    done = true;
    ps2::iop::dev9::tx_hook([](const std::uint8_t *p, std::size_t n) {
        std::lock_guard lock(g_lan_lock);
        if (g_lan_out.size() < 512) g_lan_out.emplace_back(p, p + n);
    });
}
}
// next frame the PS2 sent (0 = none); the page passes it to the server
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_net_tx(std::uint8_t *out, int max) {
    lan_init();
    std::lock_guard lock(g_lan_lock);
    if (g_lan_out.empty()) return 0;
    std::vector<std::uint8_t> f = std::move(g_lan_out.front());
    g_lan_out.pop_front();
    const int n = std::min<int>(max, static_cast<int>(f.size()));
    std::memcpy(out, f.data(), n);
    return n;
}
// a frame from the server (another player's PS2) for our network adapter
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_dev9_trace(int n) { ps2::iop::dev9::trace(n); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_net_rx(const std::uint8_t *in, int n) { lan_init(); ps2::iop::dev9::rx_push(in, static_cast<std::size_t>(n)); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uint32_t ps2web_mp_slot_car(int slot) { return ps2::mp::slot_car(slot); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_spawn(int model, int id) { ps2::mp::request_spawn(model, id); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_call(std::uint32_t fn, const std::uint32_t *args, int n) { ps2::mp::queue_call(fn, args, n); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uint32_t ps2web_mp_call_result(int *done) { return ps2::mp::call_result(*done); }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_stream_take(std::uint8_t *out, int max) {
    const auto v = ps2::mp::stream_take();
    const int n = std::min<int>(max, static_cast<int>(v.size()));
    std::memcpy(out, v.data(), n);
    return static_cast<int>(v.size());
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_probe(std::uint32_t addr, int n) { ps2::mp::request_probe(addr, n); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_stream_feed(const std::uint8_t *in, int n) { ps2::mp::stream_feed(in, n); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_career(int id) { ps2::mp::set_career_car(id); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_friend_car(int slot, const std::uint8_t *p, int n) { ps2::mp::set_friend_car(slot, p, n); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_friend_pose(int slot, const float *in, int present) {
    ps2::mp::Pose p;
    if (present && in) { std::memcpy(p.pos, in, 12); std::memcpy(p.rot, in + 3, 36); std::memcpy(p.vel, in + 12, 12); }
    ps2::mp::set_friend_pose(slot, p, present && in);
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_friend_refresh(int slot) { ps2::mp::refresh_friend(slot); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uint32_t ps2web_mp_friend_built(int slot) { return ps2::mp::friend_built(slot); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_cam_next() { ps2::mp::camera_next(); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uint32_t ps2web_mp_pausemap() { return ps2::mp::pausemap(); }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_pausemap_friends(float *out, int max) { return ps2::mp::pausemap_friends(out, max); }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_my_state(std::uint8_t *out, int max) {
    const auto v = ps2::mp::my_state();
    const int n = static_cast<int>(v.size()) < max ? static_cast<int>(v.size()) : max;
    if (n > 0) std::memcpy(out, v.data(), static_cast<std::size_t>(n));
    return n;
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_friend_state(int slot, const std::uint8_t *p, int n) { ps2::mp::set_friend_state(slot, p, n); }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_my_car(std::uint8_t *out, int max) {
    const auto v = ps2::mp::my_car();
    const int n = static_cast<int>(v.size()) < max ? static_cast<int>(v.size()) : max;
    if (n > 0) std::memcpy(out, v.data(), static_cast<std::size_t>(n));
    return n;
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_friend_unlist(int on) { ps2::mp::set_friend_unlist(on); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_load_slot(int slot, std::uint32_t h) { ps2::mp::set_load_slot(slot, h); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_force_car(int slot, std::uint32_t car) { ps2::mp::force_slot_car(slot, car); }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_live_cars(std::uint32_t *out, int max) { return ps2::mp::live_cars(out, max); }
namespace ps2 { void set_watch(std::uint32_t base, std::uint32_t len, bool unique); }
// research: watch writes to a memory range from the page (len 0 = off); unique = each writer printed once
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_watch(std::uint32_t base, std::uint32_t len, int unique) { ps2::set_watch(base, len, unique != 0); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_poke(std::uint32_t addr, std::uint32_t value) { ps2::st32(addr, value); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_custom_override(std::uint32_t id, std::uint32_t obj) { ps2::mp::set_custom_override(id, obj); }
// research log (spawns etc) since the last call, as a C string the page frees with _free
extern "C" EMSCRIPTEN_KEEPALIVE char *ps2web_mp_log() {
    const std::string s = ps2::mp::take_log();
    char *out = static_cast<char *>(std::malloc(s.size() + 1));
    std::memcpy(out, s.c_str(), s.size() + 1);
    return out;
}
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_iop_peek(std::uint32_t addr, std::uint32_t *out, int words) {
    for (int i = 0; i < words; ++i) out[i] = ps2::iop::read32(addr + static_cast<std::uint32_t>(i) * 4u);
    return words;
}
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_peek(std::uint32_t addr, std::uint32_t *out, int words) {
    for (int i = 0; i < words; ++i) out[i] = ps2::ld32(addr + static_cast<std::uint32_t>(i) * 4u);
    return words;
}
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_camera_shown(float *out, int back) { return ps2::mp::shown_camera(back, out) ? 1 : 0; }
extern "C" EMSCRIPTEN_KEEPALIVE int ps2web_mp_local_shown(float *out, int back) { return ps2::mp::shown_local(back, out) ? 1 : 0; }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_mp_remote(int slot, const float *in, int present) {
    ps2::mp::Pose p;
    if (present && in) { std::memcpy(p.pos, in, 12); std::memcpy(p.rot, in + 3, 36); std::memcpy(p.vel, in + 12, 12); }
    ps2::mp::set_remote(slot, p, present && in);
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_readbacks(double *out) { ps2::readback_stats(out); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_pause(int on) { g_paused.store(on ? 1 : 0); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_ee_speed(int percent) { ps2::set_ee_speed(static_cast<std::uint32_t>(percent)); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_video_options(int flags) { ps2::set_video_options(static_cast<std::uint32_t>(flags)); }

extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_fast_lane(int on) { ps2::set_fast_lane(on); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_gpu_profile(double from, double to) { ps2::gpu_profile(static_cast<std::uint64_t>(from), static_cast<std::uint64_t>(to)); }
extern "C" double g_ps2_cpu_times[16];
extern "C" volatile std::uint32_t g_ps2_phase;
extern "C" EMSCRIPTEN_KEEPALIVE std::uintptr_t ps2web_phase_addr() { return reinterpret_cast<std::uintptr_t>(&g_ps2_phase); }
extern "C" EMSCRIPTEN_KEEPALIVE double *ps2web_cpu_times() { return g_ps2_cpu_times; }   // lab: render-thread CPU per stage (gpu.cpp)
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_gpu_ms() { return ps2::gpu_busy_ms(); }
namespace ps2::kernel { void dump(); }
namespace ps2::iop { void dump(); }
namespace ps2::dmac { void dump(); }
namespace ps2::vif { void dump(); }
// debugging a hang: print every EE and IOP thread (where each one is and what it waits on)
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_debug_dump() {
    std::fprintf(stderr, "[debug] dump requested at frame %llu\n", static_cast<unsigned long long>(ps2::frames_run()));
    ps2::kernel::dump();
    ps2::dmac::dump();
    ps2::vif::dump();
    ps2::iop::dump();
}
// bytes posted to the graphics queues per message type since start (16 doubles)
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_posted(double *out) { for (int i = 0; i < 16; ++i) out[i] = static_cast<double>(ps2::g_posted_bytes[i].load());
    for (int i = 0; i < 5; ++i) out[16 + i] = static_cast<double>(ps2::g_post_wait[i].load());
    out[21] = static_cast<double>(ps2::g_post_msgs.load()); out[22] = static_cast<double>(ps2::g_post_wakes.load());
    out[23] = static_cast<double>(ps2::g_post_us.load()); out[24] = static_cast<double>(ps2::g_copy_us.load()); out[25] = static_cast<double>(ps2::g_post_big.load());
    for (int i = 0; i < 8; ++i) out[26 + i] = static_cast<double>(ps2::g_vu_stats[i].load());
    out[34] = static_cast<double>(ps2::vuops::g_vu_instructions.load());
    for (int i = 0; i < 4; ++i) out[35 + i] = static_cast<double>(ps2::g_unpack_stats[i].load());
    out[39] = static_cast<double>(ps2::g_vu_gif_bytes.load()); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_queue_batch(int on) { ps2::g_queue_batch.store(on); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_vu_snap(std::uint32_t lo, std::uint32_t hi) { ps2::vu1_snap((static_cast<std::uint64_t>(hi) << 32) | lo); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uint8_t *ps2web_vu_snap_data(std::uint32_t *info) { int pending = 0; std::uint8_t *p = ps2::vu1_snap_data(&info[0], &info[1], &pending); info[2] = static_cast<std::uint32_t>(pending); return p; }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_uncap(int on) { g_uncap.store(on); }
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_pace_present(int on) { g_pace_present.store(on); }
extern "C" EMSCRIPTEN_KEEPALIVE std::uintptr_t ps2web_ee_fn_addr() { return reinterpret_cast<std::uintptr_t>(&ps2::g_ee_fn); }   // lab: PS2_FN marker (PS2_EE_PROF builds)
extern "C" EMSCRIPTEN_KEEPALIVE std::uintptr_t ps2web_ee_cpu() { return reinterpret_cast<std::uintptr_t>(&ps2::g_cpu); }   // profiling: the page samples the EE return address (r31) to see which game code is busy
extern "C" EMSCRIPTEN_KEEPALIVE std::uint32_t ps2web_frame_log(double *out) { std::memcpy(out, g_frame_log, sizeof g_frame_log); return g_frame_log_n.load(); }   // profiling: last 1024 frames, 5 doubles each (see on_vblank)
extern "C" EMSCRIPTEN_KEEPALIVE char *ps2web_hot_vu() {
    const std::string s = ps2::vu1_hot_programs();
    char *out = static_cast<char *>(std::malloc(s.size() + 1));
    std::memcpy(out, s.c_str(), s.size() + 1);
    return out;
}
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_full_rate(int on) { ps2::set_full_rate(on != 0); }
// hang hunting: where the emulation thread is (runtime breadcrumb + last guest pc it dispatched to)
extern "C" EMSCRIPTEN_KEEPALIVE void ps2web_vu_record(int frames) { ps2::vu_record(frames); }
extern "C" EMSCRIPTEN_KEEPALIVE const std::uint8_t *ps2web_vu_record_data(std::uint32_t *bytes) { return ps2::vu_record_data(bytes); }
extern "C" EMSCRIPTEN_KEEPALIVE void *ps2web_where_vu_addr() { return &ps2::g_where_vu; }   // lab: a worker samples where the VU thread is
extern "C" EMSCRIPTEN_KEEPALIVE char *ps2web_where() {
    char buf[160];
    std::snprintf(buf, sizeof buf, "%s pc 0x%08X | vu: %s", ps2::g_where.load(), ps2::g_where_pc.load(), ps2::g_where_vu.load());
    char *out = static_cast<char *>(std::malloc(std::strlen(buf) + 1));
    std::strcpy(out, buf);
    return out;
}
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_frames() { return static_cast<double>(ps2::frames_run()); }
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_primitives() { return static_cast<double>(ps2::primitives_drawn()); }
extern "C" EMSCRIPTEN_KEEPALIVE void *ps2web_audio_ring() { return &g_audio; }
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_audio_queued_ms() { return audio_queued_ms(); }
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_vu_interpreted() { return static_cast<double>(ps2::vu1_interpreted_calls()); }
namespace ps2 { extern double g_lab_t[8]; }
extern "C" EMSCRIPTEN_KEEPALIVE double ps2web_idle_ms(int which) {
    if (which == 2) return ps2::vu_thread_idle_ms();
    if (which == 3) return g_render_busy.load();
    if (which == 4) return g_render_yield.load();
    if (which == 5) return g_render_show.load();
    if (which == 6) return g_render_yields.load();
    if (which == 7) return g_render_tick.load();
    if (which >= 10 && which < 18) return ps2::g_lab_t[which - 10];   // lab: 14 vif1 bytes posted by the EE, 15 vif1 transfers
    return which ? g_render_idle.load() : g_emulation_idle.load();
}

// a shown frame: the page's own counters (fps line, input timing) run on the page's thread
void frame_done() {
    ps2web_frame_done();
    if (g_gfx.worker) MAIN_THREAD_ASYNC_EM_ASM({ if (Module.onFrame) Module.onFrame(); });
}

void gfx_setup() {
    // ---- graphics: everything that touches WebGPU runs on the drawing thread (a worker when it owns the canvas)
    ps2::init_graphics();
    const bool no_surface = g_gfx.no_surface;
    bool copy = g_gfx.copy;
    bool surface = false;
    if (!copy && !no_surface) {
        ps2::WindowTarget target;
        target.kind = ps2::WindowTarget::Canvas;
        target.selector = "#canvas";
        target.width = g_gfx.width;
        target.height = g_gfx.height;
        surface = ps2::attach_window(target);
    }
    copy = copy || (!surface && !no_surface);
    MAIN_THREAD_ASYNC_EM_ASM({
        Module.videoEffectsAvailable = !!$0;
        if (Module.refreshVideoControls) Module.refreshVideoControls();
    }, surface);
    std::fprintf(stderr, "[web] %s%s\n", surface ? "presenting through WebGPU" : copy ? "presenting through a 2D canvas copy" : "not presenting",
                 g_gfx.worker ? " (drawing thread: worker)" : " (drawing thread: page)");

    ps2::start_render_thread();
    g_gfx.surface = surface;
    g_gfx.copy = copy;
    g_gfx.ready.store(1);
}

void gfx_loop() {
    const bool surface = g_gfx.surface, copy = g_gfx.copy;
    const std::function<void(const std::uint32_t *, std::uint32_t, std::uint32_t)> blit = [](const std::uint32_t *rgba, std::uint32_t width, std::uint32_t height) {
        ps2web_blit(rgba, static_cast<int>(width), static_cast<int>(height), static_cast<int>(ps2::g_options.aspect * 10000.0f));
    };
    const std::function<void(const std::uint32_t *, std::uint32_t, std::uint32_t)> streamed = [copy, &blit](const std::uint32_t *rgba, std::uint32_t width, std::uint32_t height) {
        if (copy) blit(rgba, width, height);
        if (g_streaming.load()) ps2web_stream_frame(rgba, static_cast<int>(width), static_cast<int>(height));
    };
    const std::function<void(const std::uint32_t *, std::uint32_t, std::uint32_t)> none;
    const std::function<void()> wait_shown = [] {
        const std::uint32_t phase_before = g_ps2_phase;
        g_ps2_phase = 12;   // lab sampler: waiting for the browser to show a frame
        struct Back { std::uint32_t v; ~Back() { g_ps2_phase = v; } } back{phase_before};
        static int since_skip = 0;
        static double window_start = 0.0, window_gpu = 0.0, gpu_load = 1.0;
        const double start = emscripten_get_now();
        if (start - window_start > 500.0) {
            const double gpu = ps2::gpu_busy_ms();
            gpu_load = window_start > 0.0 ? (gpu - window_gpu) / (start - window_start) : 1.0;
            window_start = start;
            window_gpu = gpu;
        }
        // boot fast-forward: only wait for the screen every 8th picture, so the boot screens fly by
        static unsigned turbo_frames = 0;
        if ((ps2::intro_turbo() || g_uncap.load(std::memory_order_relaxed)) && (++turbo_frames & 7u)) return;
        if (++since_skip > 8 && gpu_load < 0.8 && g_audio.active.load() && audio_queued_ms() < 40.0) {
            since_skip = 0;
            return;
        }
        if (!g_pace_present.load(std::memory_order_relaxed)) ps2web_wait_shown();
        g_render_idle.store(g_render_idle.load() + emscripten_get_now() - start);
    };
    for (;;) {
        if (!g_gfx.worker) service_disc();
        // canvas size from the page (a worker owns its canvas, so the size is applied here)
        if (g_gfx.worker) {
            const std::uint32_t want = g_resize.load();
            static std::uint32_t have = 0;
            if (want && want != have) {
                have = want;
                const std::uint32_t w = want & 0xFFFFu, h = want >> 16;
                EM_ASM({ const c = findCanvasEventTarget('#canvas'); if (c) { c.width = $0; c.height = $1; } }, w, h);
                ps2::resize_window(w, h);
            }
        }
        const bool pace = surface && g_pace_present.load(std::memory_order_relaxed);
        static bool paced = false;
        if (pace != paced) { ps2::set_defer_show(pace); paced = pace; if (!pace) ps2::show_waiting_frame(); }
        // Even frame spacing: a built frame waits for its turn on a steady 59.94 Hz beat, while the next one keeps
        // rendering. The beat moves later by half of any lateness (so frames end up a little early, not late) and
        // creeps earlier by a quarter ms per early frame (so the wait stays short). More than a frame late = restart.
        // A frame shown early because the next one was already built (the GPU side does that) still counts as a beat.
        static double slot = 0.0, since = 0.0;
        static std::uint32_t shown_seen = 0;
        constexpr double period = 1000.0 / 59.94;
        double budget = 6.0;
        if (paced && ps2::frame_waiting_to_show() && since > 0.0) budget = std::clamp(slot - 4.0 - emscripten_get_now(), 0.5, 6.0);
        const double busy_start = emscripten_get_now();
        const ps2::Rendered rendered = ps2::render_pending(surface, g_streaming.load() ? streamed : copy ? blit : none, wait_shown, budget);
        g_render_busy.store(g_render_busy.load() + emscripten_get_now() - busy_start);
        if (rendered == ps2::Rendered::presented && !paced) frame_done();
        double wait_ms = -1.0;
        if (paced) {
            for (const std::uint32_t shown = ps2::frames_shown(); shown_seen != shown; ++shown_seen) {   // forced shows
                frame_done();
                slot += period;
                since = 0.0;
            }
            if (ps2::frame_waiting_to_show()) {
                const double now = emscripten_get_now();
                if (since == 0.0) {
                    since = now;
                    if (slot == 0.0 || now > slot + period || slot - now > 2.0 * period) slot = now;
                    else if (now > slot) slot += (now - slot) * 0.5;
                    else slot -= std::min(0.25, slot - now);
                }
                if (now >= slot - 4.0 || g_uncap.load(std::memory_order_relaxed) || ps2::intro_turbo()) {
                    // show right after a display refresh starts (the browser expects canvas updates there; showing at
                    // random moments made it stall ~50 ms every few frames)
                    // ?PS2_TICK=0: don't wait for the browser's next refresh before showing (lab A/B)
                    static const bool tick = [] { const char *e = std::getenv("PS2_TICK"); return !e || std::atoi(e) != 0; }();
                    // v3.15.3: don't sit waiting for the refresh (that was a third of this thread at 8x): if the next refresh
                    // is still more than ~1.5 ms away, go back to drawing and come back just before it
                    const bool synced = tick && !g_uncap.load(std::memory_order_relaxed) && !ps2::intro_turbo();
                    const double until = synced ? ps2web_until_vsync() : -1.0;
                    if (until > 1.5) {
                        wait_ms = std::max(0.5, until - 1.0);
                        goto keep_working;
                    }
                    {
                    const double tick_start = emscripten_get_now();
                    if (synced) ps2web_wait_tick();
                    const double show_start = emscripten_get_now();
                    g_render_tick.store(g_render_tick.load() + show_start - tick_start);
                    ps2::show_waiting_frame();
                    g_render_show.store(g_render_show.load() + emscripten_get_now() - show_start);
                    ++shown_seen;
                    frame_done();
                    slot += period;
                    since = 0.0;
                    }
                } else {
                    wait_ms = std::min(period, slot - 4.0 - now);
                }
            keep_working:;
            }
        }
        if (rendered != ps2::Rendered::idle) {
            // hand the thread to the browser now and then (it delivers WebGPU replies there). ?PS2_YIELD_MS=n: at most
            // once every n ms instead of after every piece of work (lab A/B)
            static const double yield_every = [] { const char *e = std::getenv("PS2_YIELD_MS"); return e ? std::atof(e) : 0.0; }();
            static double last_yield = 0.0;
            const double y0 = emscripten_get_now();
            if (yield_every <= 0.0 || y0 - last_yield >= yield_every) {
                ps2::browser_yield();
                last_yield = emscripten_get_now();
                g_render_yield.store(g_render_yield.load() + last_yield - y0);
                g_render_yields.store(g_render_yields.load() + 1.0);
            }
        } else {
            const double start = emscripten_get_now();
            const int idle_ms = ps2::g_queue_batch.load() ? 2 : 50;
            ps2::wait_render_work(wait_ms >= 0.0 ? std::max(1, std::min(idle_ms, static_cast<int>(wait_ms))) : idle_ms);
            g_render_idle.store(g_render_idle.load() + emscripten_get_now() - start);
        }
    }
}

void *gfx_main(void *) {
    ps2::set_event_loop_thread();
    gfx_setup();
    gfx_loop();
    return nullptr;
}

int main(int argc, char **argv) {
    static Launch launch;
    for (int i = 2; i < argc; ++i) {
        const std::string a = argv[i];
        if (a == "--arg" && i + 1 < argc) launch.args.push_back(argv[++i]);
        else if (a == "--frames" && i + 1 < argc) ps2::g_options.max_frames = std::strtoull(argv[++i], nullptr, 10);
        else if (a == "--widescreen") ps2::g_options.widescreen = true, ps2::g_options.aspect = 16.0f / 9.0f;
        else if (a == "--aspect" && i + 1 < argc) {
            // --aspect W:H, e.g. 32:9 for a super ultrawide; anything wider than 4:3 also tells the game's OSD config "widescreen"
            float w = 4.0f, h = 3.0f;
            if (std::sscanf(argv[++i], "%f:%f", &w, &h) == 2 && w > 0.0f && h > 0.0f) {
                ps2::g_options.aspect = w / h;
                ps2::g_options.widescreen = w / h > 1.34f;
            }
        } else if (a == "--real-clutch") {
            ps2::g_options.real_clutch = true;
        } else if (a == "--skip-intro") {
            ps2::g_options.skip_intro = true;
        } else if (a == "--patch" && i + 1 < argc) {
            // --patch place:address:bytes:value (hex address/value), same fields as patches.txt
            unsigned place = 0, bytes = 0;
            unsigned long address = 0;
            unsigned long long value = 0;
            if (std::sscanf(argv[++i], "%u:%lx:%u:%llx", &place, &address, &bytes, &value) == 4)
                ps2::g_options.patches.push_back({static_cast<std::uint8_t>(place), static_cast<std::uint8_t>(bytes), static_cast<std::uint32_t>(address), value});
        }
        else if (a == "--press" && i + 1 < argc) {
            ps2::Press press;
            if (ps2::parse_press(argv[++i], press)) ps2::g_options.presses.push_back(press);
        }
    }
    if (launch.args.empty()) {
        std::string boot = "/game/core.elf";
        if (std::FILE *f = std::fopen("/game/boot.txt", "rb")) {
            char text[256] = {};
            const std::size_t n = std::fread(text, 1, sizeof text - 1, f);
            std::fclose(f);
            std::string line(text, n);
            line.erase(line.find_last_not_of(" \r\n\t") + 1);
            if (!line.empty()) boot = line;
        }
        launch.args.push_back(boot);
    }
    g_disc_size = static_cast<std::uint64_t>(ps2web_disc_size());
    g_disc_url = ps2web_disc_url();
    g_state_url = ps2web_state_url();
    ps2::g_options.on_vblank = on_vblank;
    ps2::g_options.on_vu_program = [](const std::string &name, const std::uint8_t *code, std::size_t size) {
        static bool unsupported = false;
        if (unsupported) return;
        const int status = ps2web_save_program(name.c_str(), code, static_cast<int>(size));
        if (status == 200 || status == 201) std::fprintf(stderr, "[web] new VU1 program %s kept for the performance report\n", name.c_str());
        else unsupported = true;
    };
    if (!EM_ASM_INT({ return Module.noCard ? 1 : 0; })) {
        char *card = ps2web_card_path();
        ps2::g_options.memcard_path = card;
        std::free(card);
        ps2::g_options.on_memcard_saved = [] { MAIN_THREAD_ASYNC_EM_ASM({ if (Module.ps2CardSaved) Module.ps2CardSaved(); }); };
    }
    ps2::set_audio_sink(push_audio);
    register_generated_code();
    register_generated_vu();

    g_gfx.no_surface = EM_ASM_INT({ return Module.noSurface ? 1 : 0; });
    g_gfx.copy = EM_ASM_INT({ return Module.presentCopy ? 1 : 0; });
    g_gfx.width = static_cast<std::uint32_t>(EM_ASM_INT({ return Module.canvas.width; }));
    g_gfx.height = static_cast<std::uint32_t>(EM_ASM_INT({ return Module.canvas.height; }));
    // Drawing on its own thread: the canvas moves to a worker that does all the GS / WebGPU work, so it no longer
    // shares the page's thread with the browser (?gfxpage=1 keeps the old way, on the page's own thread).
    g_gfx.worker = !g_gfx.copy && !g_gfx.no_surface && EM_ASM_INT({ return (typeof OffscreenCanvas !== 'undefined' && Module.canvas.transferControlToOffscreen && !Module.gfxOnPage) ? 1 : 0; });
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 16u << 20);
    ps2::set_event_loop_thread();   // the page's thread never blocks: its waits go back to the browser
    if (g_gfx.worker) {
        pthread_attr_t gattr;
        pthread_attr_init(&gattr);
        pthread_attr_setstacksize(&gattr, 16u << 20);
        emscripten_pthread_attr_settransferredcanvases(&gattr, "#canvas");
        EM_ASM({ Module.canvasTransferred = true; });
        pthread_t gfx;
        if (pthread_create(&gfx, &gattr, gfx_main, nullptr) != 0) {
            std::fprintf(stderr, "[web] cannot start the drawing thread\n");
            return 1;
        }
        while (!g_gfx.ready.load()) emscripten_sleep(5);
    } else {
        gfx_setup();   // old layout: the page's thread draws
    }
    if (!std::getenv("PS2_NO_VU_THREAD")) {
        ps2::start_vu_thread();
        pthread_t vu_thread;
        if (pthread_create(&vu_thread, &attr, [](void *) -> void * {
                ps2::run_vu_thread();
                return nullptr;
            }, nullptr) != 0) {
            std::fprintf(stderr, "[web] cannot start the VU thread\n");
            return 1;
        }
    }
    pthread_t thread;
    if (pthread_create(&thread, &attr, emulate, &launch) != 0) {
        std::fprintf(stderr, "[web] cannot start the emulation thread\n");
        return 1;
    }
    if (!g_gfx.worker) {
        gfx_loop();
        return 0;
    }
    // the page's thread only fetches disc chunks now (the File / URL reads live here)
    for (;;) {
        service_disc();
        const std::uint32_t seen = g_disc_wake.load();
        ps2::wait_word_async(&g_disc_wake, seen, 4);
    }
}
