// SPDX-FileCopyrightText: 2002-2026 PCSX2 Dev Team
// SPDX-License-Identifier: GPL-3.0+

#include "GS/Renderers/DX12/GSTexture12.h"
#include "GS/Renderers/DX12/D3D12Builders.h"
#include "GS/Renderers/DX12/GSDevice12.h"
#include "GS/GSPerfMon.h"
#include "GS/GSGL.h"

#include "common/Assertions.h"
#include "common/Console.h"
#include "common/BitUtils.h"
#include "common/StringUtil.h"

#include "D3D12MemAlloc.h"

GSTexture12::GSTexture12(Usage usage, Format format, int width, int height, int levels, DXGI_FORMAT dxgi_format,
	wil::com_ptr_nothrow<ID3D12Resource> resource, wil::com_ptr_nothrow<ID3D12Resource> resource_fbl,
	wil::com_ptr_nothrow<D3D12MA::Allocation> allocation, const D3D12DescriptorHandle& srv_descriptor,
	const D3D12DescriptorHandle& write_descriptor, const D3D12DescriptorHandle& ro_dsv_descriptor,
	const D3D12DescriptorHandle& uav_descriptor, const D3D12DescriptorHandle& fbl_descriptor,
	WriteDescriptorType wdtype, bool simultaneous_texture, ResourceState resource_state)
	: m_resource(std::move(resource))
	, m_resource_fbl(std::move(resource_fbl))
	, m_allocation(std::move(allocation))
	, m_srv_descriptor(srv_descriptor)
	, m_write_descriptor(write_descriptor)
	, m_read_dsv_descriptor(ro_dsv_descriptor)
	, m_uav_descriptor(uav_descriptor)
	, m_fbl_descriptor(fbl_descriptor)
	, m_write_descriptor_type(wdtype)
	, m_dxgi_format(dxgi_format)
	, m_resource_state(resource_state)
	, m_simultaneous_tex(simultaneous_texture)
{
	m_usage = usage;
	m_format = format;
	m_size.x = width;
	m_size.y = height;
	m_mipmap_levels = levels;
}

GSTexture12::~GSTexture12()
{
	Destroy(true);
}

void GSTexture12::Destroy(bool defer)
{
	GSDevice12* const dev = GSDevice12::GetInstance();
	dev->UnbindTexture(this);

	if (defer)
	{
		dev->DeferDescriptorDestruction(dev->GetDescriptorHeapManager(), &m_srv_descriptor);

		switch (m_write_descriptor_type)
		{
			case WriteDescriptorType::RTV:
				dev->DeferDescriptorDestruction(dev->GetRTVHeapManager(), &m_write_descriptor);
				break;
			case WriteDescriptorType::DSV:
				dev->DeferDescriptorDestruction(dev->GetDSVHeapManager(), &m_write_descriptor);
				dev->DeferDescriptorDestruction(dev->GetDSVHeapManager(), &m_read_dsv_descriptor);
				break;
			case WriteDescriptorType::None:
			default:
				break;
		}

		if (m_uav_descriptor)
			dev->DeferDescriptorDestruction(dev->GetDescriptorHeapManager(), &m_uav_descriptor);

		if (m_fbl_descriptor)
			dev->DeferDescriptorDestruction(dev->GetDescriptorHeapManager(), &m_fbl_descriptor);

		dev->DeferResourceDestruction(m_allocation.get(), m_resource.get());
		dev->DeferResourceDestruction(m_allocation.get(), m_resource_fbl.get());
		m_resource.reset();
		m_resource_fbl.reset();
		m_allocation.reset();
	}
	else
	{
		dev->GetDescriptorHeapManager().Free(&m_srv_descriptor);

		switch (m_write_descriptor_type)
		{
			case WriteDescriptorType::RTV:
				dev->GetRTVHeapManager().Free(&m_write_descriptor);
				break;
			case WriteDescriptorType::DSV:
				dev->GetDSVHeapManager().Free(&m_write_descriptor);
				dev->GetDSVHeapManager().Free(&m_read_dsv_descriptor);
				break;
			case WriteDescriptorType::None:
			default:
				break;
		}

		if (m_uav_descriptor)
			dev->GetDescriptorHeapManager().Free(&m_uav_descriptor);

		if (m_fbl_descriptor)
			dev->GetDescriptorHeapManager().Free(&m_fbl_descriptor);

		m_resource.reset();
		m_resource_fbl.reset();
		m_allocation.reset();
	}

	m_write_descriptor_type = WriteDescriptorType::None;

#ifdef PCSX2_DEVBUILD
	m_debug_name.clear();
#endif
}

// For use with non-simultaneous textures only.
// Simultaneous testures are always D3D12_BARRIER_LAYOUT_COMMON.
static D3D12_BARRIER_LAYOUT GetD3D12BarrierLayout(GSTexture12::ResourceState state)
{
	switch (state)
	{
		case GSTexture12::ResourceState::Undefined:
			return D3D12_BARRIER_LAYOUT_UNDEFINED;
		case GSTexture12::ResourceState::Present:
			return D3D12_BARRIER_LAYOUT_COMMON;
		case GSTexture12::ResourceState::RenderTarget:
			return D3D12_BARRIER_LAYOUT_RENDER_TARGET;
		case GSTexture12::ResourceState::DepthWriteStencil:
			return D3D12_BARRIER_LAYOUT_DEPTH_STENCIL_WRITE;
		case GSTexture12::ResourceState::PixelShaderResource:
		case GSTexture12::ResourceState::ComputeShaderResource:
			return D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_SHADER_RESOURCE;
		case GSTexture12::ResourceState::CopySrc:
			return D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_SOURCE;
		case GSTexture12::ResourceState::CopyDst:
			return D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_DEST;
		case GSTexture12::ResourceState::ComputeShaderUAV:
		case GSTexture12::ResourceState::PixelShaderUAV:
			return D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_UNORDERED_ACCESS;
		default:
			pxAssert(false);
			return D3D12_BARRIER_LAYOUT_UNDEFINED;
	}
}

static D3D12_RESOURCE_STATES GetD3D12ResourceState(GSTexture12::ResourceState state)
{
	switch (state)
	{
		case GSTexture12::ResourceState::Undefined:
			return D3D12_RESOURCE_STATE_COMMON;
		case GSTexture12::ResourceState::Present:
			return D3D12_RESOURCE_STATE_COMMON;
		case GSTexture12::ResourceState::RenderTarget:
			return D3D12_RESOURCE_STATE_RENDER_TARGET;
		case GSTexture12::ResourceState::DepthWriteStencil:
			return D3D12_RESOURCE_STATE_DEPTH_WRITE;
		case GSTexture12::ResourceState::PixelShaderResource:
			return D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
		case GSTexture12::ResourceState::ComputeShaderResource:
			return D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
		case GSTexture12::ResourceState::CopySrc:
			return D3D12_RESOURCE_STATE_COPY_SOURCE;
		case GSTexture12::ResourceState::CopyDst:
			return D3D12_RESOURCE_STATE_COPY_DEST;
		case GSTexture12::ResourceState::ComputeShaderUAV:
		case GSTexture12::ResourceState::PixelShaderUAV:
			return D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
		default:
			pxAssert(false);
			return D3D12_RESOURCE_STATE_COMMON;
	}
}

std::unique_ptr<GSTexture12> GSTexture12::Create(Usage usage, Format format, int width, int height, int levels,
	DXGI_FORMAT dxgi_format, DXGI_FORMAT srv_format, DXGI_FORMAT rtv_format, DXGI_FORMAT dsv_format,
	DXGI_FORMAT uav_format)
{
	pxAssert(ValidateUsageAndFormat(usage, format));

	GSDevice12* const dev = GSDevice12::GetInstance();

	GSDevice12::D3D12_RESOURCE_DESCU desc = {};
	desc.desc1.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
	desc.desc1.Width = width;
	desc.desc1.Height = height;
	desc.desc1.DepthOrArraySize = 1;
	desc.desc1.MipLevels = levels;
	desc.desc1.Format = dxgi_format;
	desc.desc1.SampleDesc.Count = 1;
	desc.desc1.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN;

	D3D12MA::ALLOCATION_DESC allocationDesc = {};
	allocationDesc.Flags = D3D12MA::ALLOCATION_FLAG_WITHIN_BUDGET;
	allocationDesc.HeapType = D3D12_HEAP_TYPE_DEFAULT;

	D3D12_CLEAR_VALUE optimized_clear_value = {};
	ResourceState state;

	if (IsTexture(usage))
	{
		// This is a little annoying. basically, to do mipmap generation, we need to be a render target.
		// If it's a compressed texture, we won't be generating mips anyway, so this should be fine.
		desc.desc1.Flags |= (levels > 1 && !IsCompressedFormat(format)) ? D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET :
		                                                                  D3D12_RESOURCE_FLAG_NONE;
		state = ResourceState::CopyDst;
	}
	else
	{
		allocationDesc.Flags |= D3D12MA::ALLOCATION_FLAG_COMMITTED;
	}

	if (IsRenderTarget(usage))
	{
		// RT's tend to be larger, so we'll keep them committed for speed.
		pxAssert(levels == 1);
		desc.desc1.Flags |= D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
		optimized_clear_value.Format = rtv_format;
		state = ResourceState::RenderTarget;
	}

	if (IsFeedback(usage))
	{
		allocationDesc.ExtraHeapFlags |= D3D12_HEAP_FLAG_DENY_BUFFERS | D3D12_HEAP_FLAG_DENY_NON_RT_DS_TEXTURES;
		desc.desc1.Flags |= D3D12_RESOURCE_FLAG_ALLOW_SIMULTANEOUS_ACCESS;
		if (!dev->UseEnhancedBarriers())
			desc.desc1.Layout = D3D12_TEXTURE_LAYOUT_64KB_UNDEFINED_SWIZZLE;
	}

	if (IsDepthStencil(usage))
	{
		pxAssert(levels == 1);
		desc.desc1.Flags |= D3D12_RESOURCE_FLAG_ALLOW_DEPTH_STENCIL;
		optimized_clear_value.Format = dsv_format;
		state = ResourceState::DepthWriteStencil;
	}

	if (IsShaderWrite(usage))
	{
		desc.desc1.Flags |= D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
		state = ResourceState::PixelShaderResource;
	}

	wil::com_ptr_nothrow<ID3D12Resource> resource;
	wil::com_ptr_nothrow<ID3D12Resource> resource_fbl;
	wil::com_ptr_nothrow<D3D12MA::Allocation> allocation;

	if (IsFeedback(usage) && !dev->UseEnhancedBarriers())
	{
		// We need to use an aliased resource for feedback with legacy barriers.
		const D3D12_RESOURCE_ALLOCATION_INFO allocInfo = dev->GetDevice()->GetResourceAllocationInfo(0, 1, &desc.desc);

		HRESULT hr = dev->GetAllocator()->AllocateMemory(&allocationDesc, &allocInfo, allocation.put());
		if (FAILED(hr))
		{
			// OOM isn't fatal.
			if (hr != E_OUTOFMEMORY)
				Console.Error("Allocate texture memory failed: 0x%08X", hr);

			return {};
		}

		hr = dev->GetAllocator()->CreateAliasingResource(allocation.get(), 0, &desc.desc, GetD3D12ResourceState(state),
			&optimized_clear_value, IID_PPV_ARGS(resource.put()));
		if (FAILED(hr))
		{
			// OOM isn't fatal.
			if (hr != E_OUTOFMEMORY)
				Console.Error("Create texture resource 1 failed: 0x%08X", hr);

			return {};
		}

		hr = dev->GetAllocator()->CreateAliasingResource(allocation.get(), 0, &desc.desc, D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE,
			&optimized_clear_value, IID_PPV_ARGS(resource_fbl.put()));
		if (FAILED(hr))
		{
			// OOM isn't fatal.
			if (hr != E_OUTOFMEMORY)
				Console.Error("Create texture resource 2 failed: 0x%08X", hr);

			return {};
		}
	}
	else
	{
		HRESULT hr;
		if (dev->UseEnhancedBarriers())
		{
			hr = dev->GetAllocator()->CreateResource3(&allocationDesc, &desc.desc1,
				IsFeedback(usage) ? D3D12_BARRIER_LAYOUT_COMMON : GetD3D12BarrierLayout(state),
				IsRenderTargetOrDepthStencil(usage) ? &optimized_clear_value : nullptr,
				0, nullptr, allocation.put(), IID_PPV_ARGS(resource.put()));
		}
		else
		{
			hr = dev->GetAllocator()->CreateResource(&allocationDesc, &desc.desc, GetD3D12ResourceState(state),
				IsRenderTargetOrDepthStencil(usage) ? &optimized_clear_value : nullptr, allocation.put(),
				IID_PPV_ARGS(resource.put()));
		}
		if (FAILED(hr))
		{
			// OOM isn't fatal.
			if (hr != E_OUTOFMEMORY)
				Console.Error("Create texture failed: 0x%08X", hr);

			return {};
		}
	}

	D3D12DescriptorHandle srv_descriptor, write_descriptor, ro_dsv_descriptor, uav_descriptor, fbl_descriptor;
	WriteDescriptorType write_descriptor_type = WriteDescriptorType::None;
	if (srv_format != DXGI_FORMAT_UNKNOWN)
	{
		if (!CreateSRVDescriptor(resource.get(), levels, srv_format, &srv_descriptor))
			return {};
	}

	if (IsRenderTarget(usage))
	{
		write_descriptor_type = WriteDescriptorType::RTV;
		if (!CreateRTVDescriptor(resource.get(), rtv_format, &write_descriptor))
		{
			dev->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}

	if (IsDepthStencil(usage))
	{
		write_descriptor_type = WriteDescriptorType::DSV;
		if (!CreateDSVDescriptor(resource.get(), dsv_format, &write_descriptor, false))
		{
			dev->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
		if (!CreateDSVDescriptor(resource.get(), dsv_format, &ro_dsv_descriptor, true))
		{
			dev->GetDSVHeapManager().Free(&write_descriptor);
			dev->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}

	pxAssert(IsShaderWrite(usage) == (uav_format != DXGI_FORMAT_UNKNOWN));
	if (IsShaderWrite(usage) && !CreateUAVDescriptor(resource.get(), uav_format, &uav_descriptor))
	{
		if (IsRenderTarget(usage))
			dev->GetRTVHeapManager().Free(&write_descriptor);
		dev->GetDescriptorHeapManager().Free(&srv_descriptor);
		return {};
	}

	// Feedback descriptor used with legacy barriers
	if (resource_fbl)
	{
		pxAssert(!dev->UseEnhancedBarriers());
		if (!CreateSRVDescriptor(resource_fbl.get(), levels, srv_format, &fbl_descriptor))
		{
			dev->GetDescriptorHeapManager().Free(&uav_descriptor);
			switch (write_descriptor_type)
			{
				case WriteDescriptorType::RTV:
					dev->GetRTVHeapManager().Free(&write_descriptor);
					break;
				case WriteDescriptorType::DSV:
					dev->GetDSVHeapManager().Free(&ro_dsv_descriptor);
					dev->GetDSVHeapManager().Free(&write_descriptor);
					break;
				default:
					break;
			}
			dev->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}

	return std::unique_ptr<GSTexture12>(
		new GSTexture12(usage, format, width, height, levels, dxgi_format, std::move(resource), std::move(resource_fbl), std::move(allocation),
			srv_descriptor, write_descriptor, ro_dsv_descriptor, uav_descriptor, fbl_descriptor, write_descriptor_type, IsFeedback(usage), state));
}

std::unique_ptr<GSTexture12> GSTexture12::Adopt(wil::com_ptr_nothrow<ID3D12Resource> resource, Usage usage, Format format,
	int width, int height, int levels, DXGI_FORMAT dxgi_format, DXGI_FORMAT srv_format, DXGI_FORMAT rtv_format,
	DXGI_FORMAT dsv_format, DXGI_FORMAT uav_format, ResourceState resource_state)
{
	const D3D12_RESOURCE_DESC desc = resource->GetDesc();

	D3D12DescriptorHandle srv_descriptor, write_descriptor, ro_dsv_descriptor, uav_descriptor;
	WriteDescriptorType write_descriptor_type = WriteDescriptorType::None;
	if (srv_format != DXGI_FORMAT_UNKNOWN)
	{
		if (!CreateSRVDescriptor(resource.get(), desc.MipLevels, srv_format, &srv_descriptor))
			return {};
	}

	if (IsRenderTarget(usage))
	{
		write_descriptor_type = WriteDescriptorType::RTV;
		if (!CreateRTVDescriptor(resource.get(), rtv_format, &write_descriptor))
		{
			GSDevice12::GetInstance()->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}
	else if (IsDepthStencil(usage))
	{
		write_descriptor_type = WriteDescriptorType::DSV;
		if (!CreateDSVDescriptor(resource.get(), dsv_format, &write_descriptor, false))
		{
			GSDevice12::GetInstance()->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
		if (!CreateDSVDescriptor(resource.get(), dsv_format, &ro_dsv_descriptor, true))
		{
			GSDevice12::GetInstance()->GetDSVHeapManager().Free(&write_descriptor);
			GSDevice12::GetInstance()->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}

	pxAssert(IsShaderWrite(usage) == (uav_format != DXGI_FORMAT_UNKNOWN));
	if (IsShaderWrite(usage))
	{
		if (!CreateUAVDescriptor(resource.get(), uav_format, &uav_descriptor))
		{
			switch (write_descriptor_type)
			{
				case WriteDescriptorType::RTV:
					GSDevice12::GetInstance()->GetRTVHeapManager().Free(&write_descriptor);
					break;
				case WriteDescriptorType::DSV:
					GSDevice12::GetInstance()->GetDSVHeapManager().Free(&ro_dsv_descriptor);
					GSDevice12::GetInstance()->GetDSVHeapManager().Free(&write_descriptor);
					break;
				default:
					break;
			}

			GSDevice12::GetInstance()->GetDescriptorHeapManager().Free(&srv_descriptor);
			return {};
		}
	}

	return std::unique_ptr<GSTexture12>(new GSTexture12(usage, format, static_cast<u32>(desc.Width), desc.Height,
		desc.MipLevels, desc.Format, std::move(resource), {}, {}, srv_descriptor, write_descriptor, {}, uav_descriptor,
		{}, write_descriptor_type, false, resource_state));
}

bool GSTexture12::CreateSRVDescriptor(
	ID3D12Resource* resource, u32 levels, DXGI_FORMAT format, D3D12DescriptorHandle* dh)
{
	if (!GSDevice12::GetInstance()->GetDescriptorHeapManager().Allocate(dh))
	{
		Console.Error("Failed to allocate SRV descriptor");
		return false;
	}

	D3D12_SHADER_RESOURCE_VIEW_DESC desc = {
		format, D3D12_SRV_DIMENSION_TEXTURE2D, D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING};
	desc.Texture2D.MipLevels = levels;

	GSDevice12::GetInstance()->GetDevice()->CreateShaderResourceView(resource, &desc, dh->cpu_handle);
	return true;
}

bool GSTexture12::CreateRTVDescriptor(ID3D12Resource* resource, DXGI_FORMAT format, D3D12DescriptorHandle* dh)
{
	if (!GSDevice12::GetInstance()->GetRTVHeapManager().Allocate(dh))
	{
		Console.Error("Failed to allocate RTV descriptor");
		return false;
	}

	const D3D12_RENDER_TARGET_VIEW_DESC desc = {format, D3D12_RTV_DIMENSION_TEXTURE2D};
	GSDevice12::GetInstance()->GetDevice()->CreateRenderTargetView(resource, &desc, dh->cpu_handle);
	return true;
}

bool GSTexture12::CreateDSVDescriptor(ID3D12Resource* resource, DXGI_FORMAT format, D3D12DescriptorHandle* dh, bool read_only)
{
	if (!GSDevice12::GetInstance()->GetDSVHeapManager().Allocate(dh))
	{
		Console.Error("Failed to allocate DSV descriptor");
		return false;
	}

	const D3D12_DEPTH_STENCIL_VIEW_DESC desc = {format, D3D12_DSV_DIMENSION_TEXTURE2D, read_only ? D3D12_DSV_FLAG_READ_ONLY_DEPTH : D3D12_DSV_FLAG_NONE};
	GSDevice12::GetInstance()->GetDevice()->CreateDepthStencilView(resource, &desc, dh->cpu_handle);
	return true;
}

bool GSTexture12::CreateUAVDescriptor(ID3D12Resource* resource, DXGI_FORMAT format, D3D12DescriptorHandle* dh)
{
	if (!GSDevice12::GetInstance()->GetDescriptorHeapManager().Allocate(dh))
	{
		Console.Error("Failed to allocate UAV descriptor");
		return false;
	}

	const D3D12_UNORDERED_ACCESS_VIEW_DESC desc = {format, D3D12_UAV_DIMENSION_TEXTURE2D};
	GSDevice12::GetInstance()->GetDevice()->CreateUnorderedAccessView(resource, nullptr, &desc, dh->cpu_handle);
	return true;
}

void* GSTexture12::GetNativeHandle() const
{
	return const_cast<GSTexture12*>(this);
}

const D3D12CommandList& GSTexture12::GetCommandBufferForUpdate()
{
	GSDevice12* const dev = GSDevice12::GetInstance();
	if (!IsTexture() || m_use_fence_counter == dev->GetCurrentFenceValue())
	{
		// Console.WriteLn("Texture update within frame, can't use do beforehand");
		GSDevice12::GetInstance()->EndRenderPass();
		return dev->GetCommandList();
	}

	return dev->GetInitCommandList();
}

ID3D12Resource* GSTexture12::AllocateUploadStagingBuffer(
	const void* data, u32 pitch, u32 upload_pitch, u32 height) const
{
	const u32 buffer_size = CalcUploadSize(height, upload_pitch);
	wil::com_ptr_nothrow<ID3D12Resource> resource;
	wil::com_ptr_nothrow<D3D12MA::Allocation> allocation;

	const D3D12MA::ALLOCATION_DESC allocation_desc = {D3D12MA::ALLOCATION_FLAG_NONE, D3D12_HEAP_TYPE_UPLOAD};

	const GSDevice12::D3D12_RESOURCE_DESCU resource_desc = {{D3D12_RESOURCE_DIMENSION_BUFFER, 0, buffer_size, 1, 1, 1,
		DXGI_FORMAT_UNKNOWN, {1, 0}, D3D12_TEXTURE_LAYOUT_ROW_MAJOR, D3D12_RESOURCE_FLAG_NONE}};
	HRESULT hr;
	if (GSDevice12::GetInstance()->UseEnhancedBarriers())
	{
		hr = GSDevice12::GetInstance()->GetAllocator()->CreateResource3(&allocation_desc, &resource_desc.desc1,
			D3D12_BARRIER_LAYOUT_UNDEFINED, nullptr, 0, nullptr, allocation.put(), IID_PPV_ARGS(resource.put()));
	}
	else
	{
		hr = GSDevice12::GetInstance()->GetAllocator()->CreateResource(&allocation_desc, &resource_desc.desc,
			D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, allocation.put(), IID_PPV_ARGS(resource.put()));
	}
	if (FAILED(hr))
	{
		Console.WriteLn("(AllocateUploadStagingBuffer) CreateCommittedResource() failed with %08X", hr);
		return nullptr;
	}

	void* map_ptr;
	hr = resource->Map(0, nullptr, &map_ptr);
	if (FAILED(hr))
	{
		Console.WriteLn("(AllocateUploadStagingBuffer) Map() failed with %08X", hr);
		return nullptr;
	}

	CopyTextureDataForUpload(map_ptr, data, pitch, upload_pitch, height);

	const D3D12_RANGE write_range = {0, buffer_size};
	resource->Unmap(0, &write_range);

	// Immediately queue it for freeing after the command buffer finishes, since it's only needed for the copy.
	// This adds the reference needed to keep the buffer alive.
	GSDevice12::GetInstance()->DeferResourceDestruction(allocation.get(), resource.get());
	return resource.get();
}

void GSTexture12::CopyTextureDataForUpload(void* dst, const void* src, u32 pitch, u32 upload_pitch, u32 height) const
{
	const u32 block_size = GetCompressedBlockSize();
	const u32 count = (height + (block_size - 1)) / block_size;
	StringUtil::StrideMemCpy(dst, upload_pitch, src, pitch, std::min(upload_pitch, pitch), count);
}

bool GSTexture12::Update(const GSVector4i& r, const void* data, int pitch, int layer)
{
	if (layer >= m_mipmap_levels)
		return false;

	g_perfmon.Put(GSPerfMon::TextureUploads, 1);

	// Footprint and box must be block aligned for compressed textures.
	const u32 block_size = GetCompressedBlockSize();
	const u32 width = Common::AlignUpPow2(r.width(), block_size);
	const u32 height = Common::AlignUpPow2(r.height(), block_size);
	const u32 upload_pitch = Common::AlignUpPow2<u32>(pitch, D3D12_TEXTURE_DATA_PITCH_ALIGNMENT);
	const u32 required_size = CalcUploadSize(r.height(), upload_pitch);

	D3D12_TEXTURE_COPY_LOCATION srcloc;
	srcloc.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
	srcloc.PlacedFootprint.Footprint.Width = width;
	srcloc.PlacedFootprint.Footprint.Height = height;
	srcloc.PlacedFootprint.Footprint.Depth = 1;
	srcloc.PlacedFootprint.Footprint.Format = m_dxgi_format;
	srcloc.PlacedFootprint.Footprint.RowPitch = upload_pitch;

	// If the texture is larger than half our streaming buffer size, use a separate buffer.
	// Otherwise allocation will either fail, or require lots of cmdbuffer submissions.
	if (required_size > (GSDevice12::GetInstance()->GetTextureStreamBuffer().GetSize() / 2))
	{
		srcloc.pResource = AllocateUploadStagingBuffer(data, pitch, upload_pitch, height);
		if (!srcloc.pResource)
			return false;

		srcloc.PlacedFootprint.Offset = 0;
	}
	else
	{
		D3D12StreamBuffer& sbuffer = GSDevice12::GetInstance()->GetTextureStreamBuffer();
		if (!sbuffer.ReserveMemory(required_size, D3D12_TEXTURE_DATA_PLACEMENT_ALIGNMENT))
		{
			GSDevice12::GetInstance()->ExecuteCommandList(
				false, "While waiting for %u bytes in texture upload buffer", required_size);
			if (!sbuffer.ReserveMemory(required_size, D3D12_TEXTURE_DATA_PLACEMENT_ALIGNMENT))
			{
				Console.Error("Failed to reserve texture upload memory (%u bytes).", required_size);
				return false;
			}
		}

		srcloc.pResource = sbuffer.GetBuffer();
		srcloc.PlacedFootprint.Offset = sbuffer.GetCurrentOffset();
		CopyTextureDataForUpload(sbuffer.GetCurrentHostPointer(), data, pitch, upload_pitch, height);
		sbuffer.CommitMemory(required_size);
	}

	const D3D12CommandList& cmdlist = GetCommandBufferForUpdate();
	GL_PUSH("GSTexture12::Update({%d,%d} %dx%d Lvl:%u", r.x, r.y, r.width(), r.height(), layer);

	// first time the texture is used? don't leave it undefined
	if (m_resource_state == GSTexture12::ResourceState::Undefined)
		TransitionToState(cmdlist, GSTexture12::ResourceState::CopyDst);
	else if (m_resource_state != GSTexture12::ResourceState::CopyDst)
		TransitionSubresourceToState(cmdlist, layer, m_resource_state, GSTexture12::ResourceState::CopyDst);

	// if we're an rt and have been cleared, and the full rect isn't being uploaded, do the clear
	if (IsRenderTarget())
	{
		if (!r.eq(GSVector4i(0, 0, m_size.x, m_size.y)))
			CommitClear(cmdlist);
		else
			m_state = State::Dirty;
	}

	D3D12_TEXTURE_COPY_LOCATION dstloc;
	dstloc.pResource = m_resource.get();
	dstloc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
	dstloc.SubresourceIndex = layer;

	const D3D12_BOX srcbox{0u, 0u, 0u, width, height, 1u};
	cmdlist.list4->CopyTextureRegion(&dstloc, Common::AlignDownPow2((u32)r.x, block_size),
		Common::AlignDownPow2((u32)r.y, block_size), 0, &srcloc, &srcbox);

	if (m_resource_state != GSTexture12::ResourceState::CopyDst)
		TransitionSubresourceToState(cmdlist, layer, GSTexture12::ResourceState::CopyDst, m_resource_state);

	if (IsTexture())
		m_needs_mipmaps_generated |= (layer == 0);

	return true;
}

bool GSTexture12::Map(GSMap& m, const GSVector4i* r, int layer)
{
	if (layer >= m_mipmap_levels || IsCompressedFormat())
		return false;

	// map for writing
	m_map_area = r ? *r : GetRect();
	m_map_level = layer;
	m.pitch = Common::AlignUpPow2(CalcUploadPitch(m_map_area.width()), D3D12_TEXTURE_DATA_PITCH_ALIGNMENT);

	// see note in Update() for the reason why.
	const u32 required_size = CalcUploadSize(m_map_area.height(), m.pitch);
	D3D12StreamBuffer& buffer = GSDevice12::GetInstance()->GetTextureStreamBuffer();
	if (required_size >= (buffer.GetSize() / 2))
		return false;

	if (!buffer.ReserveMemory(required_size, D3D12_TEXTURE_DATA_PLACEMENT_ALIGNMENT))
	{
		GSDevice12::GetInstance()->ExecuteCommandList(
			false, "While waiting for %u bytes in texture upload buffer", required_size);
		if (!buffer.ReserveMemory(required_size, D3D12_TEXTURE_DATA_PLACEMENT_ALIGNMENT))
			pxFailRel("Failed to reserve texture upload memory");
	}

	m.bits = static_cast<u8*>(buffer.GetCurrentHostPointer());
	return true;
}

void GSTexture12::Unmap()
{
	// this can't handle blocks/compressed formats at the moment.
	pxAssert(m_map_level < m_mipmap_levels && !IsCompressedFormat());
	g_perfmon.Put(GSPerfMon::TextureUploads, 1);

	const u32 width = m_map_area.width();
	const u32 height = m_map_area.height();
	const u32 pitch = Common::AlignUpPow2(CalcUploadPitch(width), D3D12_TEXTURE_DATA_PITCH_ALIGNMENT);
	const u32 required_size = CalcUploadSize(height, pitch);
	D3D12StreamBuffer& buffer = GSDevice12::GetInstance()->GetTextureStreamBuffer();
	const u32 buffer_offset = buffer.GetCurrentOffset();
	buffer.CommitMemory(required_size);

	const D3D12CommandList& cmdlist = GetCommandBufferForUpdate();
	GL_PUSH("GSTexture12::Update({%d,%d} %dx%d Lvl:%u", m_map_area.x, m_map_area.y, m_map_area.width(),
		m_map_area.height(), m_map_level);

	// first time the texture is used? don't leave it undefined
	if (m_resource_state == ResourceState::Undefined)
		TransitionToState(cmdlist, ResourceState::CopyDst);
	else if (m_resource_state != ResourceState::CopyDst)
		TransitionSubresourceToState(cmdlist, m_map_level, m_resource_state, ResourceState::CopyDst);

	// if we're an rt and have been cleared, and the full rect isn't being uploaded, do the clear
	if (IsRenderTarget())
	{
		if (!m_map_area.eq(GSVector4i(0, 0, m_size.x, m_size.y)))
			CommitClear(cmdlist);
		else
			m_state = State::Dirty;
	}

	D3D12_TEXTURE_COPY_LOCATION srcloc;
	srcloc.pResource = buffer.GetBuffer();
	srcloc.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
	srcloc.PlacedFootprint.Offset = buffer_offset;
	srcloc.PlacedFootprint.Footprint.Width = width;
	srcloc.PlacedFootprint.Footprint.Height = height;
	srcloc.PlacedFootprint.Footprint.Depth = 1;
	srcloc.PlacedFootprint.Footprint.Format = m_dxgi_format;
	srcloc.PlacedFootprint.Footprint.RowPitch = pitch;

	D3D12_TEXTURE_COPY_LOCATION dstloc;
	dstloc.pResource = m_resource.get();
	dstloc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
	dstloc.SubresourceIndex = m_map_level;

	const D3D12_BOX srcbox{0u, 0u, 0u, width, height, 1};
	cmdlist.list4->CopyTextureRegion(&dstloc, m_map_area.x, m_map_area.y, 0, &srcloc, &srcbox);

	if (m_resource_state != ResourceState::CopyDst)
		TransitionSubresourceToState(cmdlist, m_map_level, ResourceState::CopyDst, m_resource_state);

	if (IsTexture())
		m_needs_mipmaps_generated |= (m_map_level == 0);
}

void GSTexture12::GenerateMipmap()
{
	pxAssert(!IsCompressedFormat(m_format));

	for (int dst_level = 1; dst_level < m_mipmap_levels; dst_level++)
	{
		const int src_level = dst_level - 1;
		const int src_width = std::max<int>(m_size.x >> src_level, 1);
		const int src_height = std::max<int>(m_size.y >> src_level, 1);
		const int dst_width = std::max<int>(m_size.x >> dst_level, 1);
		const int dst_height = std::max<int>(m_size.y >> dst_level, 1);

		GSDevice12::GetInstance()->RenderTextureMipmap(
			this, dst_level, dst_width, dst_height, src_level, src_width, src_height);
	}

	SetUseFenceCounter(GSDevice12::GetInstance()->GetCurrentFenceValue());
}

#ifdef PCSX2_DEVBUILD

void GSTexture12::SetDebugName(std::string_view name)
{
	if (name.empty())
		return;

	D3D12::SetObjectName(m_resource.get(), name);

	m_debug_name = name;
}

#endif

void GSTexture12::TransitionToState(ResourceState state)
{
	TransitionToState(GSDevice12::GetInstance()->GetCommandList(), state);
}

void GSTexture12::TransitionToState(const D3D12CommandList& cmdlist, ResourceState state)
{
	if (m_resource_state == state)
		return;

	TransitionSubresourceToState(cmdlist, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, m_resource_state, state);

	m_resource_state = state;
}

void GSTexture12::TransitionSubresourceToState(const D3D12CommandList& cmdlist, u32 level,
	ResourceState before_state, ResourceState after_state) const
{
	if (GSDevice12::GetInstance()->UseEnhancedBarriers())
	{
		// Read only depth requires special handling as we might want to write stencil.
		// We need to transition subresources separately, requiring 2 barriers
		// Handling it here allows us to batch those barriers.
		// Other transitions only need the one barrier.
		D3D12_TEXTURE_BARRIER barriers[2] = {{D3D12_BARRIER_SYNC_NONE, D3D12_BARRIER_SYNC_NONE,
			D3D12_BARRIER_ACCESS_COMMON, D3D12_BARRIER_ACCESS_COMMON,
			D3D12_BARRIER_LAYOUT_COMMON, D3D12_BARRIER_LAYOUT_COMMON,
			m_resource.get(), {level, 0, 0, 0, 0, 0}, D3D12_TEXTURE_BARRIER_FLAG_NONE}};

		uint num_barriers = 1;
		D3D12_TEXTURE_BARRIER& barrier = barriers[0];
		switch (before_state)
		{
			case ResourceState::Undefined:
			case ResourceState::Present:
				barrier.LayoutBefore = D3D12_BARRIER_LAYOUT_COMMON;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_NO_ACCESS;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_NONE;
				break;
			case ResourceState::RenderTarget:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_RENDER_TARGET;
				barrier.AccessBefore = m_simultaneous_tex ?
				                           D3D12_BARRIER_ACCESS_RENDER_TARGET | D3D12_BARRIER_ACCESS_SHADER_RESOURCE :
				                           D3D12_BARRIER_ACCESS_RENDER_TARGET;
				barrier.SyncBefore = m_simultaneous_tex ?
				                         D3D12_BARRIER_SYNC_RENDER_TARGET | D3D12_BARRIER_SYNC_PIXEL_SHADING :
				                         D3D12_BARRIER_SYNC_RENDER_TARGET;
				break;
			case ResourceState::DepthWriteStencil:
				pxAssert(!m_simultaneous_tex);
				barrier.LayoutBefore = D3D12_BARRIER_LAYOUT_DEPTH_STENCIL_WRITE;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_DEPTH_STENCIL_WRITE;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_DEPTH_STENCIL;
				break;
			case ResourceState::DepthReadStencil:
				pxAssert(!m_simultaneous_tex);
				pxAssert(level == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES);

				barriers[0].Subresources = {0, static_cast<uint>(m_mipmap_levels), 0, 1, 0, 1};
				barriers[0].LayoutBefore = D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_GENERIC_READ;
				barriers[0].AccessBefore = D3D12_BARRIER_ACCESS_SHADER_RESOURCE | D3D12_BARRIER_ACCESS_DEPTH_STENCIL_READ;
				barriers[0].SyncBefore = D3D12_BARRIER_SYNC_DEPTH_STENCIL | D3D12_BARRIER_SYNC_PIXEL_SHADING;
				if (after_state != ResourceState::DepthWriteStencil)
				{
					num_barriers = 2;
					barriers[1].Subresources = {0, static_cast<uint>(m_mipmap_levels), 0, 1, 1, 1};
					barriers[1].LayoutBefore = D3D12_BARRIER_LAYOUT_DEPTH_STENCIL_WRITE;
					barriers[1].AccessBefore = D3D12_BARRIER_ACCESS_DEPTH_STENCIL_READ;
					barriers[1].SyncBefore = D3D12_BARRIER_SYNC_DEPTH_STENCIL;
				}
				break;
			case ResourceState::PixelShaderResource:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_SHADER_RESOURCE;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_SHADER_RESOURCE;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_PIXEL_SHADING;
				break;
			case ResourceState::ComputeShaderResource:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_SHADER_RESOURCE;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_SHADER_RESOURCE;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_COMPUTE_SHADING;
				break;
			case ResourceState::CopySrc:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_SOURCE;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_COPY_SOURCE;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_COPY;
				break;
			case ResourceState::CopyDst:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_DEST;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_COPY_DEST;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_COPY;
				break;
			case ResourceState::ComputeShaderUAV:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_UNORDERED_ACCESS;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_UNORDERED_ACCESS;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_COMPUTE_SHADING;
				break;
			case ResourceState::PixelShaderUAV:
				barrier.LayoutBefore = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_UNORDERED_ACCESS;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_UNORDERED_ACCESS;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_PIXEL_SHADING | D3D12_BARRIER_SYNC_CLEAR_UNORDERED_ACCESS_VIEW;
				break;
			default:
				pxAssert(false);
				barrier.LayoutBefore = D3D12_BARRIER_LAYOUT_UNDEFINED;
				barrier.AccessBefore = D3D12_BARRIER_ACCESS_NO_ACCESS;
				barrier.SyncBefore = D3D12_BARRIER_SYNC_NONE;
				break;
		}

		switch (after_state)
		{
			case ResourceState::Undefined:
			case ResourceState::Present:
				barrier.LayoutAfter = D3D12_BARRIER_LAYOUT_COMMON;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_NO_ACCESS;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_NONE;
				break;
			case ResourceState::RenderTarget:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_RENDER_TARGET;
				barrier.AccessAfter = m_simultaneous_tex ?
				                          D3D12_BARRIER_ACCESS_RENDER_TARGET | D3D12_BARRIER_ACCESS_SHADER_RESOURCE :
				                          D3D12_BARRIER_ACCESS_RENDER_TARGET;
				barrier.SyncAfter = m_simultaneous_tex ?
				                        D3D12_BARRIER_SYNC_RENDER_TARGET | D3D12_BARRIER_SYNC_PIXEL_SHADING :
				                        D3D12_BARRIER_SYNC_RENDER_TARGET;
				break;
			case ResourceState::DepthWriteStencil:
				pxAssert(!m_simultaneous_tex);
				barrier.LayoutAfter = D3D12_BARRIER_LAYOUT_DEPTH_STENCIL_WRITE;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_DEPTH_STENCIL_WRITE;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_DEPTH_STENCIL;
				break;
			case ResourceState::DepthReadStencil:
				pxAssert(!m_simultaneous_tex);
				pxAssert(level == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES);

				barriers[0].Subresources = {0, static_cast<uint>(m_mipmap_levels), 0, 1, 0, 1};
				barriers[0].LayoutAfter = D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_GENERIC_READ;
				barriers[0].AccessAfter = D3D12_BARRIER_ACCESS_SHADER_RESOURCE | D3D12_BARRIER_ACCESS_DEPTH_STENCIL_READ;
				barriers[0].SyncAfter = D3D12_BARRIER_SYNC_DEPTH_STENCIL | D3D12_BARRIER_SYNC_PIXEL_SHADING;
				if (before_state != ResourceState::DepthWriteStencil)
				{
					num_barriers = 2;
					barriers[1].Subresources = {0, static_cast<uint>(m_mipmap_levels), 0, 1, 1, 1};
					barriers[1].LayoutAfter = D3D12_BARRIER_LAYOUT_DEPTH_STENCIL_WRITE;
					barriers[1].AccessAfter = D3D12_BARRIER_ACCESS_DEPTH_STENCIL_READ;
					barriers[1].SyncAfter = D3D12_BARRIER_SYNC_DEPTH_STENCIL;
				}
				break;
			case ResourceState::PixelShaderResource:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_SHADER_RESOURCE;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_SHADER_RESOURCE;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_PIXEL_SHADING;
				break;
			case ResourceState::ComputeShaderResource:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_SHADER_RESOURCE;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_SHADER_RESOURCE;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_COMPUTE_SHADING;
				break;
			case ResourceState::CopySrc:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_SOURCE;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_COPY_SOURCE;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_COPY;
				break;
			case ResourceState::CopyDst:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_COPY_DEST;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_COPY_DEST;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_COPY;
				break;
			case ResourceState::ComputeShaderUAV:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_UNORDERED_ACCESS;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_UNORDERED_ACCESS;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_COMPUTE_SHADING;
				break;
			case ResourceState::PixelShaderUAV:
				barrier.LayoutAfter = m_simultaneous_tex ? D3D12_BARRIER_LAYOUT_COMMON : D3D12_BARRIER_LAYOUT_DIRECT_QUEUE_UNORDERED_ACCESS;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_UNORDERED_ACCESS;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_PIXEL_SHADING | D3D12_BARRIER_SYNC_CLEAR_UNORDERED_ACCESS_VIEW;
				break;
			default:
				pxAssert(false);
				barrier.LayoutAfter = D3D12_BARRIER_LAYOUT_UNDEFINED;
				barrier.AccessAfter = D3D12_BARRIER_ACCESS_NO_ACCESS;
				barrier.SyncAfter = D3D12_BARRIER_SYNC_NONE;
				break;
		}

		if (num_barriers == 2)
		{
			barriers[1].pResource = m_resource.get();
			barriers[1].Flags = barriers[0].Flags;
			if (before_state == ResourceState::DepthReadStencil)
			{
				barriers[1].LayoutAfter = barriers[0].LayoutAfter;
				barriers[1].AccessAfter = barriers[0].AccessAfter;
				barriers[1].SyncAfter = barriers[0].SyncAfter;
			}
			else // after_state == ResourceState::DepthReadStencil
			{
				barriers[1].LayoutBefore = barriers[0].LayoutBefore;
				barriers[1].AccessBefore = barriers[0].AccessBefore;
				barriers[1].SyncBefore = barriers[0].SyncBefore;
			}
		}

		const D3D12_BARRIER_GROUP group = {.Type = D3D12_BARRIER_TYPE_TEXTURE, .NumBarriers = num_barriers, .pTextureBarriers = barriers};
		cmdlist.list7->Barrier(1, &group);
	}
	else
	{
		// Read only depth requires special handling as we might want to write stencil.
		// We need to transition subresources separately, requiring 2 barriers.
		// Handling it here allows us to batch those barriers.
		// Other transitions only need the one barrier.
		D3D12_RESOURCE_BARRIER barriers[2] = {{D3D12_RESOURCE_BARRIER_TYPE_TRANSITION, D3D12_RESOURCE_BARRIER_FLAG_NONE,
			{{m_resource.get(), static_cast<u32>(level), D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COMMON}}}};

		int num_barriers = 1;
		D3D12_RESOURCE_BARRIER& barrier = barriers[0];
		switch (before_state)
		{
			case ResourceState::Undefined:
			case ResourceState::Present:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON;
				break;
			case ResourceState::RenderTarget:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_RENDER_TARGET;
				break;
			case ResourceState::DepthWriteStencil:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_DEPTH_WRITE;
				break;
			case ResourceState::DepthReadStencil:
				pxAssert(!m_simultaneous_tex);
				pxAssert(m_mipmap_levels == 1);
				pxAssert(level == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES);

				barriers[0].Transition.Subresource = 0;
				barriers[0].Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_DEPTH_READ;
				if (after_state != ResourceState::DepthWriteStencil)
				{
					num_barriers = 2;
					barriers[1].Transition.Subresource = 1;
					barriers[1].Transition.StateBefore = D3D12_RESOURCE_STATE_DEPTH_WRITE;
				}
				break;
			case ResourceState::PixelShaderResource:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
				break;
			case ResourceState::ComputeShaderResource:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
				break;
			case ResourceState::CopySrc:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
				break;
			case ResourceState::CopyDst:
				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
				break;
			case ResourceState::ComputeShaderUAV:
			case ResourceState::PixelShaderUAV:
				// Handled in after_state cases.
				if (after_state == ResourceState::ComputeShaderUAV || after_state == ResourceState::PixelShaderUAV)
					break;

				barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
				break;
			default:
				pxAssert(false);
				break;
		}

		switch (after_state)
		{
			case ResourceState::Undefined:
			case ResourceState::Present:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COMMON;
				break;
			case ResourceState::RenderTarget:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_RENDER_TARGET;
				break;
			case ResourceState::DepthWriteStencil:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_DEPTH_WRITE;
				break;
			case ResourceState::DepthReadStencil:
				pxAssert(!m_simultaneous_tex);
				pxAssert(m_mipmap_levels == 1);
				pxAssert(level == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES);

				barriers[0].Transition.Subresource = 0;
				barriers[0].Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_DEPTH_READ;
				if (before_state != ResourceState::DepthWriteStencil)
				{
					num_barriers = 2;
					barriers[1].Transition.Subresource = 1;
					barriers[1].Transition.StateAfter = D3D12_RESOURCE_STATE_DEPTH_WRITE;
				}
				break;
			case ResourceState::PixelShaderResource:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
				break;
			case ResourceState::ComputeShaderResource:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
				break;
			case ResourceState::CopySrc:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
				break;
			case ResourceState::CopyDst:
				barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
				break;
			case ResourceState::ComputeShaderUAV:
			case ResourceState::PixelShaderUAV:
				if (before_state == ResourceState::ComputeShaderUAV || before_state == ResourceState::PixelShaderUAV)
				{
					// No state transition, but probably want a barrier instead.
					barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_UAV;
					// pResource is a common initial member, so no need to set again.
				}
				else
					barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
				break;
			default:
				pxAssert(false);
				break;
		}

		if (num_barriers == 2)
		{
			barriers[1].Transition.pResource = m_resource.get();
			barriers[1].Type = barriers[0].Type;
			barriers[1].Flags = barriers[0].Flags;
			if (before_state == ResourceState::DepthReadStencil)
				barriers[1].Transition.StateAfter = barriers[0].Transition.StateAfter;
			else // after_state == ResourceState::DepthReadStencil
				barriers[1].Transition.StateBefore = barriers[0].Transition.StateBefore;
		}

		cmdlist.list4->ResourceBarrier(num_barriers, barriers);
	}

	// Count as a UAV barrier if we transition to/from UAV.
	if (IsRenderTargetOrDepthStencil() &&
		(before_state == ResourceState::PixelShaderUAV || after_state == ResourceState::PixelShaderUAV))
	{
		g_perfmon.Put(GSPerfMon::Barriers, 1);
		g_perfmon.Put(GSPerfMon::BarriersROV, 1);
	}
}

void GSTexture12::CommitClear()
{
	if (m_state != GSTexture::State::Cleared)
		return;

	GSDevice12::GetInstance()->EndRenderPass();
	CommitClear(GSDevice12::GetInstance()->GetCommandList());
}

void GSTexture12::CommitClear(const D3D12CommandList& cmdlist)
{
	if (IsDepthStencil())
	{
		TransitionToState(cmdlist, ResourceState::DepthWriteStencil);
		cmdlist.list4->ClearDepthStencilView(
			GetWriteDescriptor(), D3D12_CLEAR_FLAG_DEPTH, m_clear_value.depth, 0, 0, nullptr);
	}
	else
	{
		TransitionToState(cmdlist, ResourceState::RenderTarget);
		cmdlist.list4->ClearRenderTargetView(GetWriteDescriptor(), GetClearForFormat().v, 0, nullptr);
	}

	SetState(GSTexture::State::Dirty);
}

GSDownloadTexture12::GSDownloadTexture12(u32 width, u32 height, GSTexture::Format format)
	: GSDownloadTexture(width, height, format)
{
}

GSDownloadTexture12::~GSDownloadTexture12()
{
	if (IsMapped())
		GSDownloadTexture12::Unmap();

	if (m_buffer)
		GSDevice12::GetInstance()->DeferResourceDestruction(m_allocation.get(), m_buffer.get());
}

std::unique_ptr<GSDownloadTexture12> GSDownloadTexture12::Create(u32 width, u32 height, GSTexture::Format format)
{
	const u32 buffer_size = GetBufferSize(width, height, format, D3D12_TEXTURE_DATA_PITCH_ALIGNMENT);

	D3D12MA::ALLOCATION_DESC allocation_desc = {};
	allocation_desc.HeapType = D3D12_HEAP_TYPE_READBACK;

	const GSDevice12::D3D12_RESOURCE_DESCU resource_desc = {{D3D12_RESOURCE_DIMENSION_BUFFER, 0, buffer_size, 1, 1, 1,
		DXGI_FORMAT_UNKNOWN, {1, 0}, D3D12_TEXTURE_LAYOUT_ROW_MAJOR, D3D12_RESOURCE_FLAG_NONE}};

	wil::com_ptr_nothrow<D3D12MA::Allocation> allocation;
	wil::com_ptr_nothrow<ID3D12Resource> buffer;

	HRESULT hr;
	if (GSDevice12::GetInstance()->UseEnhancedBarriers())
	{
		hr = GSDevice12::GetInstance()->GetAllocator()->CreateResource3(&allocation_desc, &resource_desc.desc1,
			D3D12_BARRIER_LAYOUT_UNDEFINED, nullptr, 0, nullptr, allocation.put(), IID_PPV_ARGS(buffer.put()));
	}
	else
	{
		hr = GSDevice12::GetInstance()->GetAllocator()->CreateResource(&allocation_desc, &resource_desc.desc,
			D3D12_RESOURCE_STATE_COPY_DEST, nullptr, allocation.put(), IID_PPV_ARGS(buffer.put()));
	}
	if (FAILED(hr))
	{
		Console.Error("(GSDownloadTexture12::Create) CreateResource() failed with HRESULT %08X", hr);
		return {};
	}

	std::unique_ptr<GSDownloadTexture12> tex(new GSDownloadTexture12(width, height, format));
	tex->m_allocation = std::move(allocation);
	tex->m_buffer = std::move(buffer);
	tex->m_buffer_size = buffer_size;
	return tex;
}

void GSDownloadTexture12::CopyFromTexture(
	const GSVector4i& drc, GSTexture* stex, const GSVector4i& src, u32 src_level, bool use_transfer_pitch)
{
	GSTexture12* const tex12 = static_cast<GSTexture12*>(stex);

	pxAssert(tex12->GetFormat() == m_format);
	pxAssert(drc.width() == src.width() && drc.height() == src.height());
	pxAssert(src.z <= tex12->GetWidth() && src.w <= tex12->GetHeight());
	pxAssert(static_cast<u32>(drc.z) <= m_width && static_cast<u32>(drc.w) <= m_height);
	pxAssert(src_level < static_cast<u32>(tex12->GetMipmapLevels()));
	pxAssert((drc.left == 0 && drc.top == 0) || !use_transfer_pitch);

	u32 copy_offset, copy_size, copy_rows;
	m_current_pitch = GetTransferPitch(
		use_transfer_pitch ? static_cast<u32>(drc.width()) : m_width, D3D12_TEXTURE_DATA_PITCH_ALIGNMENT);
	GetTransferSize(drc, &copy_offset, &copy_size, &copy_rows);

	g_perfmon.Put(GSPerfMon::Readbacks, 1);
	GSDevice12::GetInstance()->EndRenderPass();
	tex12->CommitClear();

	if (IsMapped())
		Unmap();

	const D3D12CommandList& cmdlist = GSDevice12::GetInstance()->GetCommandList();
	GL_INS("ReadbackTexture: {%d,%d} %ux%u", src.left, src.top, src.width(), src.height());

	D3D12_TEXTURE_COPY_LOCATION srcloc;
	srcloc.pResource = tex12->GetResource();
	srcloc.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
	srcloc.SubresourceIndex = src_level;

	D3D12_TEXTURE_COPY_LOCATION dstloc;
	dstloc.pResource = m_buffer.get();
	dstloc.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
	dstloc.PlacedFootprint.Offset = copy_offset;
	dstloc.PlacedFootprint.Footprint.Format = tex12->GetDXGIFormat();
	dstloc.PlacedFootprint.Footprint.Width = drc.width();
	dstloc.PlacedFootprint.Footprint.Height = drc.height();
	dstloc.PlacedFootprint.Footprint.Depth = 1;
	dstloc.PlacedFootprint.Footprint.RowPitch = m_current_pitch;

	const GSTexture12::ResourceState old_layout = tex12->GetResourceState();
	if (old_layout != GSTexture12::ResourceState::CopySrc)
		tex12->TransitionSubresourceToState(cmdlist, src_level, old_layout, GSTexture12::ResourceState::CopySrc);

	// TODO: Rules for depth buffers here?
	const D3D12_BOX srcbox{static_cast<UINT>(src.left), static_cast<UINT>(src.top), 0u, static_cast<UINT>(src.right),
		static_cast<UINT>(src.bottom), 1u};
	cmdlist.list4->CopyTextureRegion(&dstloc, 0, 0, 0, &srcloc, &srcbox);

	if (old_layout != GSTexture12::ResourceState::CopySrc)
		tex12->TransitionSubresourceToState(cmdlist, src_level, GSTexture12::ResourceState::CopySrc, old_layout);

	m_copy_fence_value = GSDevice12::GetInstance()->GetCurrentFenceValue();
	m_needs_flush = true;
}

bool GSDownloadTexture12::Map(const GSVector4i& read_rc)
{
	if (IsMapped())
		return true;

	// Never populated?
	if (!m_current_pitch)
		return false;

	u32 copy_offset, copy_size, copy_rows;
	GetTransferSize(read_rc, &copy_offset, &copy_size, &copy_rows);

	const D3D12_RANGE read_range{copy_offset, copy_offset + copy_size};
	const HRESULT hr = m_buffer->Map(0, &read_range, reinterpret_cast<void**>(const_cast<u8**>(&m_map_pointer)));
	if (FAILED(hr))
	{
		Console.Error("(GSDownloadTexture12::Map) Map() failed with HRESULT %08X", hr);
		return false;
	}

	return true;
}

void GSDownloadTexture12::Unmap()
{
	if (!IsMapped())
		return;

	const D3D12_RANGE write_range = {};
	m_buffer->Unmap(0, &write_range);
	m_map_pointer = nullptr;
}

void GSDownloadTexture12::Flush()
{
	if (!m_needs_flush)
		return;

	m_needs_flush = false;

	GSDevice12* dev = GSDevice12::GetInstance();
	if (dev->GetCompletedFenceValue() >= m_copy_fence_value)
		return;

	// Need to execute command buffer.
	if (dev->GetCurrentFenceValue() == m_copy_fence_value)
		dev->ExecuteCommandListForReadback();
	else
		dev->WaitForFence(m_copy_fence_value, GSConfig.HWSpinGPUForReadbacks);
}

#ifdef PCSX2_DEVBUILD

void GSDownloadTexture12::SetDebugName(std::string_view name)
{
	if (name.empty())
		return;

	D3D12::SetObjectName(m_buffer.get(), name);
}

#endif
