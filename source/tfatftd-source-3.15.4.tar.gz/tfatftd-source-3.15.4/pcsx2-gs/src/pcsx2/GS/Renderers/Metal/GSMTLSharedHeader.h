// SPDX-FileCopyrightText: 2002-2026 PCSX2 Dev Team
// SPDX-License-Identifier: GPL-3.0+

#pragma once
#include <simd/simd.h>
#include "../Common/GSShaderEnums.h"

enum GSMTLBufferIndices
{
	GSMTLBufferIndexVertices,
	GSMTLBufferIndexUniforms,
	GSMTLBufferIndexHWVertices,
	GSMTLBufferIndexHWUniforms,
	GSMTLBufferIndexHWIndices,
};

enum GSMTLTextureIndex
{
	GSMTLTextureIndexNonHW,
	GSMTLTextureIndexTex,
	GSMTLTextureIndexPalette,
	GSMTLTextureIndexRenderTarget,
	GSMTLTextureIndexPrimIDs,
	GSMTLTextureIndexDepthTarget,
	GSMTLTextureIndexCount,
};

struct GSMTLConvertPSUniform
{
	int emoda;
	int emodc;
};

struct GSMTLPresentPSUniform
{
	vector_float4 source_rect;
	vector_float4 target_rect;
	vector_float2 source_size;
	vector_float2 target_size;
	vector_float2 target_resolution;
	vector_float2 rcp_target_resolution; ///< 1 / target_resolution
	vector_float2 source_resolution;
	vector_float2 rcp_source_resolution; ///< 1 / source_resolution
	float time;
};

struct GSMTLInterlacePSUniform
{
	vector_float4 ZrH;
};

struct GSMTLCASPSUniform
{
	vector_uint4 const0;
	vector_uint4 const1;
	vector_int2 srcOffset;
};

struct GSMTLCLUTConvertPSUniform
{
	float scale;
	vector_uint2 offset;
	uint doffset;
};

struct GSMTLIndexedConvertPSUniform
{
	float scale;
	uint sbw;
	uint dbw;
	uint psm;
};

struct GSMTLDownsamplePSUniform
{
	vector_uint2 clamp_min;
	uint downsample_factor;
	float weight;
	float step_multiplier;
};

struct GSMTLMainVertex
{
	vector_float2 st;
	vector_uchar4 rgba;
	float q;
	vector_ushort2 xy;
	uint z;
	vector_ushort2 uv;
	unsigned char fog;
};

struct GSMTLMainVSUniform
{
	vector_float2 vertex_scale;
	vector_float2 vertex_offset;
	vector_float2 texture_scale;
	vector_float2 texture_offset;
	vector_float2 point_size;
	uint max_depth;
	float line_aa1_width;
};

struct GSMTLMainPSUniform
{
	union
	{
		vector_float4 fog_color_aref;
		vector_float3 fog_color;
		struct
		{
			float pad0[3];
			float aref;
		};
	};
	vector_float4 wh; ///< xy => PS2, zw => actual (upscaled)
	vector_float2 ta;
	float max_depth;
	float alpha_fix;
	vector_uint4 fbmask;

	vector_float4 half_texel;
	union
	{
		vector_float4 uv_min_max;
		vector_uint4 uv_msk_fix;
	};
	vector_float4 lod_params;
	vector_float4 st_range;
	struct
	{
		unsigned int blue_mask;
		unsigned int blue_shift;
		unsigned int green_mask;
		unsigned int green_shift;
	} channel_shuffle;
	vector_float2 channel_shuffle_offset;
	vector_float2 tc_offset;
	vector_float2 st_scale;
	matrix_float4x4 dither_matrix;

	vector_float4 scale_factor;

	float line_cov_scale;
	float _pad0;
	float _pad1;
	float _pad2;
};

enum GSMTLAttributes
{
	GSMTLAttributeIndexST,
	GSMTLAttributeIndexC,
	GSMTLAttributeIndexQ,
	GSMTLAttributeIndexXY,
	GSMTLAttributeIndexZ,
	GSMTLAttributeIndexUV,
	GSMTLAttributeIndexF,
};

enum GSMTLFnConstants
{
	GSMTLConstantIndex_BILN,
	GSMTLConstantIndex_DEPTH_OUT,
	GSMTLConstantIndex_CAS_SHARPEN_ONLY,
	GSMTLConstantIndex_FRAMEBUFFER_FETCH,
	GSMTLConstantIndex_DEPTH_FEEDBACK,
	GSMTLConstantIndex_ROV_NEEDS_R32,
	GSMTLConstantIndex_BROKEN_SHADER_DEPTH,
	GSMTLConstantIndex_FST,
	GSMTLConstantIndex_IIP,
	GSMTLConstantIndex_VS_POINT_SIZE,
	GSMTLConstantIndex_VS_EXPAND_TYPE,
	GSMTLConstantIndex_PS_AEM_FMT,
	GSMTLConstantIndex_PS_PAL_FMT,
	GSMTLConstantIndex_PS_DST_FMT,
	GSMTLConstantIndex_PS_DEPTH_FMT,
	GSMTLConstantIndex_PS_AEM,
	GSMTLConstantIndex_PS_FBA,
	GSMTLConstantIndex_PS_FOG,
	GSMTLConstantIndex_PS_DATE,
	GSMTLConstantIndex_PS_ATST,
	GSMTLConstantIndex_PS_AFAIL,
	GSMTLConstantIndex_PS_ZTST,
	GSMTLConstantIndex_PS_TFX,
	GSMTLConstantIndex_PS_TCC,
	GSMTLConstantIndex_PS_WMS,
	GSMTLConstantIndex_PS_WMT,
	GSMTLConstantIndex_PS_ADJS,
	GSMTLConstantIndex_PS_ADJT,
	GSMTLConstantIndex_PS_LTF,
	GSMTLConstantIndex_PS_SHUFFLE,
	GSMTLConstantIndex_PS_SHUFFLE_SAME,
	GSMTLConstantIndex_PS_PROCESS_BA,
	GSMTLConstantIndex_PS_PROCESS_RG,
	GSMTLConstantIndex_PS_SHUFFLE_ACROSS,
	GSMTLConstantIndex_PS_READ16_SRC,
	GSMTLConstantIndex_PS_WRITE_RG,
	GSMTLConstantIndex_PS_FBMASK,
	GSMTLConstantIndex_PS_BLEND_A,
	GSMTLConstantIndex_PS_BLEND_B,
	GSMTLConstantIndex_PS_BLEND_C,
	GSMTLConstantIndex_PS_BLEND_D,
	GSMTLConstantIndex_PS_BLEND_HW,
	GSMTLConstantIndex_PS_A_MASKED,
	GSMTLConstantIndex_PS_COLCLIP_HW,
	GSMTLConstantIndex_PS_RTA_CORRECTION,
	GSMTLConstantIndex_PS_RTA_SRC_CORRECTION,
	GSMTLConstantIndex_PS_COLCLIP,
	GSMTLConstantIndex_PS_BLEND_MIX,
	GSMTLConstantIndex_PS_ROUND_INV,
	GSMTLConstantIndex_PS_FIXED_ONE_A,
	GSMTLConstantIndex_PS_PABE,
	GSMTLConstantIndex_PS_NO_COLOR,
	GSMTLConstantIndex_PS_NO_COLOR1,
	GSMTLConstantIndex_PS_CHANNEL,
	GSMTLConstantIndex_PS_DITHER,
	GSMTLConstantIndex_PS_DITHER_ADJUST,
	GSMTLConstantIndex_PS_ZCLAMP,
	GSMTLConstantIndex_PS_ZFLOOR,
	GSMTLConstantIndex_PS_TCOFFSETHACK,
	GSMTLConstantIndex_PS_URBAN_CHAOS_HLE,
	GSMTLConstantIndex_PS_TALES_OF_ABYSS_HLE,
	GSMTLConstantIndex_PS_TEX_IS_FB,
	GSMTLConstantIndex_PS_AUTOMATIC_LOD,
	GSMTLConstantIndex_PS_MANUAL_LOD,
	GSMTLConstantIndex_PS_REGION_RECT,
	GSMTLConstantIndex_PS_SCANMSK,
	GSMTLConstantIndex_PS_AA1,
	GSMTLConstantIndex_PS_ABE,
	GSMTLConstantIndex_PS_SW_ANISO,
	GSMTLConstantIndex_PS_ROV_COLOR,
	GSMTLConstantIndex_PS_ROV_DEPTH,
};
