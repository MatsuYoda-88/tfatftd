#pragma once
// lab profiling: where the render thread's time goes inside PCSX2's renderer (printed with ?PS2_PGS_PROF)
#include <chrono>
extern double g_pgs_t[24];   // 0-7 ms timers, 8 = stencil DATE draws, 9 = draws with depth, 10-14 more ms timers
inline double pgs_now_ms() { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
extern bool g_pgs_prof;   // timers only tick with ?PS2_PGS_PROF (each one is two clock reads)
struct PgsTimed { int i; double t0; explicit PgsTimed(int n) : i(n), t0(g_pgs_prof ? pgs_now_ms() : 0.0) {} ~PgsTimed() { if (g_pgs_prof) g_pgs_t[i] += pgs_now_ms() - t0; } };
#define PGS_TIME(n) PgsTimed pgs_timed_scope(n)
inline double g_pgs_split = 0.0;   // phase splits inside one function (render thread only)
#define PGS_SPLIT_START() do { if (g_pgs_prof) g_pgs_split = pgs_now_ms(); } while (0)
#define PGS_SPLIT(n) do { if (g_pgs_prof) { const double t_ = pgs_now_ms(); g_pgs_t[n] += t_ - g_pgs_split; g_pgs_split = t_; } } while (0)
