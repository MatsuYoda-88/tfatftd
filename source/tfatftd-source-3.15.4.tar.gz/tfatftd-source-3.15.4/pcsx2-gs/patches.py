import sys, re, pathlib
root = pathlib.Path(sys.argv[1])
def patch(rel, old, new, count=1):
    p = root / rel; s = p.read_text()
    if s.count(old) < 1: raise SystemExit(f'patch miss: {rel}: {old[:60]!r}')
    s = s.replace(old, new) if count == 0 else s.replace(old, new, count)
    p.write_text(s)
# 1. clang asm barrier: emscripten has no xmm register constraint
patch('pcsx2/GS/GSVector4.h', '#ifdef __clang__\n\t\t__asm__("":"+x"(m)::);', '#if defined(__clang__) && !defined(__EMSCRIPTEN__)\n\t\t__asm__("":"+x"(m)::);')
# 2. no AVX-512 arithmetic 64-bit shift on SSE4 / wasm: do it per lane
patch('pcsx2/GS/GSVector4i.h', '''		return GSVector4i(_mm_sra_epi64(m, _mm_cvtsi32_si128(i)));''', '''#ifdef __EMSCRIPTEN__
		const s64 lo = static_cast<s64>(_mm_cvtsi128_si64(m)) >> i, hi = static_cast<s64>(_mm_extract_epi64(m, 1)) >> i;
		return GSVector4i(_mm_set_epi64x(hi, lo));
#else
		return GSVector4i(_mm_sra_epi64(m, _mm_cvtsi32_si128(i)));
#endif''')
# 3. no MXCSR in wasm (floats are always round-to-nearest, denormals kept)
patch('common/FPControl.h', '''		return FPControlRegister{_mm_getcsr()};''', '''#ifdef __EMSCRIPTEN__
		return GetDefault();
#else
		return FPControlRegister{_mm_getcsr()};
#endif''')
patch('common/FPControl.h', '''		_mm_setcsr(value.bitmask);''', '''#ifndef __EMSCRIPTEN__
		_mm_setcsr(value.bitmask);
#else
		(void)value;
#endif''')
# 4. xxhash: on wasm it includes arm_neon.h (SIMDe) - inside GSXXH's namespace that breaks; use its SSE2 path
patch('3rdparty/include/xxhash.h', " \\\n   || (defined(__wasm_simd128__) && XXH_HAS_INCLUDE(<arm_neon.h>)) /* WASM SIMD128 via SIMDe */", "", 1)
patch('3rdparty/include/xxhash.h', " \\\n     || (defined(__wasm_simd128__) && XXH_HAS_INCLUDE(<arm_neon.h>)) /* wasm simd128 via SIMDe */ \\", " \\", 1)
print('patched')
