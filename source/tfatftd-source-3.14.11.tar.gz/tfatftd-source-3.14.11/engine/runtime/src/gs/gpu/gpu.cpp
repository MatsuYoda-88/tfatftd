#include <atomic>
#include <chrono>
#include "gpu.hpp"
#include "ps2/system.hpp"
#include "ps2/video.hpp"

#include <webgpu/webgpu.h>
#ifndef __EMSCRIPTEN__
#include <webgpu/wgpu.h>
#endif

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <memory>
#include <string>
#include <unordered_map>

#ifdef PS2_PGS
#include "pgs_bridge.hpp"
#endif

extern const char kGsShader[];
extern const char kBlitShader[];
extern const char kFastShader[];

namespace ps2::gs {
void swizzle_tables(std::vector<std::uint32_t> &out);
}

namespace ps2::gs::gpu {

namespace {

// kFastLoad / kFastStore / kFastDraw are fast-lane commands (fast.wgsl), not entries of g_pipelines
}  // namespace (temporarily leave for the C symbol)
}
// profiling (lab): render-thread CPU time per stage, ms since start, plus call counts. Read by ps2web_cpu_times.
// 0 flush_batch (tile binning)  1 flush_fast  2 submit (encode + queue)  3 plan_decodes  4 uploads  5 palette loads
// 6 emit_pre  7 draw() calls (count)  8 prims (count)  9 batches (count)
extern "C" double g_ps2_cpu_times[16] = {};
extern "C" volatile std::uint32_t g_ps2_phase;
struct Ps2Phase {
    std::uint32_t old;
    explicit Ps2Phase(std::uint32_t p) : old(g_ps2_phase) { g_ps2_phase = p; }
    ~Ps2Phase() { g_ps2_phase = old; }
};
namespace ps2::gs::gpu {
namespace {
// (off: each clock read is a call out to JS, ~1000 uploads a frame made it cost more than it measured)
struct CpuTimer {
    explicit CpuTimer(int) {}
};
}
namespace {
enum Pipeline { kUpload, kCopyRead, kCopyWrite, kLoadClut, kDisplay, kRaster, kResolve, kSnapshot, kDecode, kDecodeMany, kPipelines, kFastLoad = kPipelines, kFastStore, kFastDraw, kFastZStore, kNoPipeline };
const char *const kEntryPoints[kPipelines] = {"upload", "copy_read", "copy_write", "load_clut", "display", "raster", "resolve", "snapshot", "decode", "decode_many"};

constexpr std::uint32_t kParamStride = 256;
constexpr std::uint32_t kClutSlots = 2048;
constexpr std::uint32_t kClutEntries = 512;
constexpr std::uint32_t kPrimWords = 28;
constexpr std::uint32_t kSetupWords = 27;  // 25: HD texture offset (words, ~0 = none), 26: HD scale shift
constexpr std::uint32_t kDecodedWords = 8u << 20;
constexpr std::uint32_t kDecodePrims = 64;

Mode g_mode = Mode::off;
std::uint64_t g_dispatches[kPipelines] = {}, g_submits = 0;

WGPUInstance g_instance = nullptr;
WGPUAdapter g_adapter = nullptr;
WGPUSurface g_surface = nullptr;
WGPUTextureFormat g_surface_format = WGPUTextureFormat_Undefined;
#ifdef PS2_PGS
bool g_pgs = false;           // PCSX2's GS renderer draws the frames
bool g_pgs_pending = false;   // a PCSX2 picture waits for show_pending()
#endif
WGPUPresentMode g_present_mode = WGPUPresentMode_Fifo;
std::uint32_t g_surface_width = 0, g_surface_height = 0;
WGPURenderPipeline g_blit = nullptr;
float g_present_aspect = 0.0f;
WGPUBindGroup g_blit_group = nullptr;
WGPUBuffer g_blit_params = nullptr;
std::uint32_t g_field = 0, g_last_width = 0, g_last_height = 0;
bool g_have_previous = false;
std::uint32_t g_scale = 1, g_sx = 1, g_sy = 1, g_tile_rows = 128, g_copy_words = 1u << 20, g_field_words = 1u << 19;

std::uint32_t field_base(std::uint32_t field) { return g_copy_words + (field & 1u) * g_field_words; }

bool g_timestamps = false;
WGPUQuerySet g_queries = nullptr;
WGPUBuffer g_query_resolve = nullptr, g_query_read = nullptr;
bool g_query_pending = false, g_query_ready = false;
std::uint64_t g_measured_ns = 0, g_measured = 0, g_total_passes = 0;
WGPUDevice g_device = nullptr;
WGPUQueue g_queue = nullptr;
WGPUBuffer g_vram = nullptr, g_tables = nullptr, g_params = nullptr, g_data = nullptr, g_clut = nullptr, g_scratch = nullptr, g_readback = nullptr, g_decoded = nullptr, g_hd = nullptr;
std::uint32_t g_hd_words = 0;
std::uint32_t g_decoded_used = 0;
bool g_rendered[512] = {};
bool g_decode = true;
std::uint64_t g_params_size = 0, g_data_size = 0;
WGPUBindGroupLayout g_layout = nullptr;
WGPUPipelineLayout g_pipeline_layout = nullptr;
WGPUBindGroup g_group = nullptr;
WGPUComputePipeline g_pipelines[kPipelines] = {};

// ===== fast lane (see fast.wgsl): plain layer batches go through the GPU's rasterizer + blend unit =====
bool g_fast = false;
std::atomic<bool> g_fast_on{true};   // runtime switch (lab A/B tests)
std::atomic<bool> g_decode_many_on{true};
std::atomic<bool> g_hot_draw{true};   // lab A/B: fast_lane(4) = old per-triangle path
std::uint32_t g_batch_serial = 0;   // one dispatch for all of a batch's texture decodes (lab A/B: fast_lane(2) turns it off)
std::uint64_t g_fast_min_work = 1u << 17;   // pixel samples a batch must cover (all primitives together) to be worth it
WGPUShaderModule g_fast_module = nullptr;
WGPUBindGroupLayout g_fast_vlayout = nullptr, g_fast_wlayout = nullptr, g_fast_rlayout = nullptr, g_fast_dlayout = nullptr;
WGPUPipelineLayout g_fast_render_layout = nullptr;
WGPUComputePipeline g_fast_load = nullptr, g_fast_store = nullptr, g_fast_zstore = nullptr;
std::unordered_map<std::uint32_t, WGPURenderPipeline> g_fast_pipes;   // blend variant | Z test << 5 | Z write << 7 | kept channels << 8
WGPURenderPipeline g_fast_zload = nullptr;
WGPUTexture g_fast_rt = nullptr, g_fast_depth = nullptr;
WGPUTextureView g_fast_view = nullptr, g_fast_dview = nullptr;
WGPUBindGroup g_fast_vgroup = nullptr, g_fast_wgroup = nullptr, g_fast_rgroup = nullptr, g_fast_zgroup = nullptr;
std::uint32_t g_fast_w = 0, g_fast_h = 0;
struct FastDraw {
    std::uint32_t variant, first, count;
    float fix;
};
struct FastBatch {
    std::uint32_t param;
    bool zload = false;
    std::vector<FastDraw> draws;
    std::vector<std::uint32_t> zloads;   // params of the Z strips to copy in first (resident target: only what isn't in yet)
};
// The fast lane's colour / Z textures cover the target at its real position (sample x,y = frame x,y * scale) and stay
// "resident" across fast batches drawing to the same frame: only the part a batch adds is copied in, and the drawn
// part goes back to VRAM once, when anything else needs VRAM (a tile-rasterizer batch, an upload or palette load over
// those pages, a texture read from them, the end of the submit). Before this every batch copied its box in and out.
struct Rect {
    int x0 = 1 << 30, y0 = 1 << 30, x1 = -1, y1 = -1;
    bool empty() const { return x1 < x0 || y1 < y0; }
    bool inside(const Rect &o) const { return !empty() && x0 >= o.x0 && y0 >= o.y0 && x1 <= o.x1 && y1 <= o.y1; }
    void add(const Rect &o) { if (o.empty()) return; x0 = std::min(x0, o.x0); y0 = std::min(y0, o.y0); x1 = std::max(x1, o.x1); y1 = std::max(y1, o.y1); }
};
struct Resident {
    bool on = false, z = false;
    std::uint32_t fbp = 0, fbw = 0, fpsm = 0, zbp = 0, zpsm = 0;
    Rect loaded, zloaded, dirty, zdirty;
} g_res;
bool g_res_hold = false;      // set while the fast lane itself emits work that is known not to touch the resident pages
std::atomic<bool> g_res_on{true};   // lab A/B: fast_lane(3) = old per-batch copy in / out
void res_flush();
std::vector<FastBatch> g_fast_batches;
std::uint64_t g_fast_count[3] = {};   // batches, primitives, batches that stayed in the tile rasterizer
// why batches stayed in the tile rasterizer: 0 frame format, 1 too big, 2 too little work, 3 DATE/PABE, 4 frame mask,
// 5 alpha test splitting colour/Z, 6 blend without clamp, 7 blend formula, 8 Z format
std::uint64_t g_fast_reject[9] = {};

struct Command {
    Pipeline pipeline;
    std::uint32_t x, y;
    std::uint32_t param;
};

struct CommandInfo {
    std::size_t index;
    std::uint32_t values[10];
};
std::vector<CommandInfo> g_command_info;
std::FILE *g_profile_out = nullptr;
std::uint64_t g_profile_from = 0, g_profile_to = 0;
WGPUQuerySet g_profile_queries = nullptr;
WGPUBuffer g_profile_resolve = nullptr, g_profile_read = nullptr;

std::vector<Command> g_commands;
std::vector<std::array<std::uint32_t, kParamStride / 4>> g_param_records;
struct Arena {
    std::unique_ptr<std::uint32_t[]> words;
    std::size_t used = 0, capacity = 0;

    std::uint32_t *grow(std::size_t count) {
        if (used + count > capacity) {
            std::size_t next = std::max<std::size_t>(capacity * 2, 1u << 20);
            while (next < used + count) next *= 2;
            auto bigger = std::make_unique_for_overwrite<std::uint32_t[]>(next);
            if (used) std::memcpy(bigger.get(), words.get(), used * 4);
            words = std::move(bigger);
            capacity = next;
        }
        std::uint32_t *at = words.get() + used;
        used += count;
        return at;
    }
    std::size_t size() const { return used; }
    bool empty() const { return !used; }
    void clear() { used = 0; }
    std::uint32_t *data() { return words.get(); }
    std::uint32_t &operator[](std::size_t i) { return words[i]; }
} g_arena;
std::uint32_t g_clut_slot = 0, g_clut_loads = 0, g_texflushes = 0;

struct Image {
    bool active = false;
    std::uint32_t dbp = 0, dbw = 0, dpsm = 0, dsax = 0, dsay = 0, rrw = 0, total = 0, done = 0, bpp = 32, lead_bits = 0, id = 0;
    std::vector<std::uint8_t> pending;
} g_image;
std::uint32_t g_image_ids = 0;

struct Range {
    std::uint64_t lo = ~0ull, hi = 0;
    bool overlaps(std::uint64_t a, std::uint64_t b) const { return lo < b && a < hi; }
    void add(std::uint64_t a, std::uint64_t b) {
        lo = std::min(lo, a);
        hi = std::max(hi, b);
    }
};

// a plain growable array for the per-triangle lists: appending a 28-word record is one inlined copy
// (std::vector::insert stayed an out-of-line call and was ~2% of the render thread)
struct PodVec {
    std::uint32_t *d = nullptr;
    std::size_t n = 0, cap = 0;
    PodVec() = default;
    PodVec(const PodVec &) = delete;
    PodVec &operator=(const PodVec &) = delete;
    ~PodVec() { std::free(d); }
    std::size_t size() const { return n; }
    bool empty() const { return n == 0; }
    void clear() { n = 0; }
    std::uint32_t *data() { return d; }
    const std::uint32_t *data() const { return d; }
    std::uint32_t &operator[](std::size_t i) { return d[i]; }
    const std::uint32_t &operator[](std::size_t i) const { return d[i]; }
    std::uint32_t *end() { return d + n; }
    [[gnu::noinline]] void grow(std::size_t need) {
        std::size_t c = cap ? cap : 4096;
        while (c < need) c *= 2;
        d = static_cast<std::uint32_t *>(std::realloc(d, c * 4));
        cap = c;
    }
    void insert(std::uint32_t *, const std::uint32_t *first, const std::uint32_t *last) {
        const std::size_t k = static_cast<std::size_t>(last - first);
        if (n + k > cap) [[unlikely]] grow(n + k);
        std::memcpy(d + n, first, k * 4);
        n += k;
    }
    void push_back(std::uint32_t v) {
        if (n + 1 > cap) [[unlikely]] grow(n + 1);
        d[n++] = v;
    }
};

struct Batch {
    PodVec prims;
    std::vector<std::uint32_t> setups;
    PodVec boxes;
    std::uint64_t key = ~0ull;
    int minx = 1 << 30, miny = 1 << 30, maxx = -1, maxy = -1;
    std::uint32_t fbp = 0, fbw = 0, fpsm = 0, zbp = 0, zpsm = 0;
    bool zte = false, zwrite = false;
    std::uint32_t texflushes = 0;
    int rx0 = 0, ry0 = 0, rx1 = -2, ry1 = -2;
    Range fb_range, z_range;
} g_batch;

struct SetupCache {
    std::uint32_t version = 0;   // bumped whenever the setup words are rebuilt
    std::uint32_t generation = ~0u, clut = ~0u;
    std::uint64_t attr = ~0ull;
    std::uint32_t setup[kSetupWords] = {};
    std::uint32_t flags = 0;
    std::uint64_t key = 0;
    Range tex;
} g_setup_cache;

struct PreOp {
    bool clut = false;
    std::uint32_t rec[12] = {};
    Range range;
    std::uint32_t x0 = 0, y0 = 0, x1 = 0, y1 = 0, image = 0;
};

bool uploads_overlap(const PreOp &a, const PreOp &b) {
    if (a.image && a.image == b.image) return false;
    if (!a.range.overlaps(b.range.lo, b.range.hi)) return false;
    if (a.rec[0] != b.rec[0] || a.rec[1] != b.rec[1] || a.rec[2] != b.rec[2]) return true;
    return a.x0 <= b.x1 && b.x0 <= a.x1 && a.y0 <= b.y1 && b.y0 <= a.y1;
}

// Uploads and CLUT loads run before the pending primitive batch unless they touch memory it reads or writes.
std::vector<PreOp> g_pre;
std::vector<Range> g_batch_reads;

int g_tiles_per_row = 128;
std::vector<std::uint32_t> g_tile_count(128 * 128), g_tile_fill(128 * 128);
std::vector<std::uint32_t> g_touched;

WGPUStringView view(const char *s) { return WGPUStringView{s, WGPU_STRLEN}; }

std::uint32_t bits_per_pixel(std::uint32_t psm) {
    switch (psm) {
    case PSMCT24: case PSMZ24: return 24;
    case PSMCT16: case PSMCT16S: case PSMZ16: case PSMZ16S: return 16;
    case PSMT8: case PSMT8H: return 8;
    case PSMT4: case PSMT4HL: case PSMT4HH: return 4;
    default: return 32;
    }
}

void page_size(std::uint32_t psm, std::uint32_t &pw, std::uint32_t &ph) {
    switch (psm) {
    case PSMCT16: case PSMCT16S: case PSMZ16: case PSMZ16S: pw = 64; ph = 64; break;
    case PSMT8: pw = 128; ph = 64; break;
    case PSMT4: pw = 128; ph = 128; break;
    default: pw = 64; ph = 32; break;
    }
}

Range region(std::uint32_t bp, std::uint32_t bw, std::uint32_t psm, int x0, int y0, int x1, int y1) {
    std::uint32_t pw, ph;
    page_size(psm, pw, ph);
    const std::uint64_t per_row = std::max<std::uint32_t>(1, bw * 64 / pw);
    const auto page = [&](int x, int y) {
        return static_cast<std::uint64_t>(bp) * 256 + (static_cast<std::uint64_t>(std::max(x, 0)) / pw + static_cast<std::uint64_t>(std::max(y, 0)) / ph * per_row) * 8192;
    };
    Range r;
    r.add(std::min(page(x0, y0), static_cast<std::uint64_t>(bp) * 256), page(x1, y1) + 8192);
    return r;
}

std::uint32_t z_max(std::uint32_t psm) {
    switch (psm) {
    case PSMZ24: return 0xFFFFFFu;
    case PSMZ16: case PSMZ16S: return 0xFFFFu;
    default: return 0xFFFFFFFFu;
    }
}

std::uint32_t f2u(float f) {
    std::uint32_t v;
    std::memcpy(&v, &f, 4);
    return v;
}

std::uint32_t push_params(const std::initializer_list<std::uint32_t> values) {
    std::array<std::uint32_t, kParamStride / 4> record{};
    std::size_t i = 0;
    for (std::uint32_t v : values) record[i++] = v;
    g_param_records.push_back(record);
    return static_cast<std::uint32_t>(g_param_records.size() - 1);
}

void dispatch_linear(Pipeline p, std::uint32_t items, std::uint32_t param) {
    if (!g_res_hold) res_flush();
    const std::uint32_t groups = (items + 63) / 64;
    if (!groups) return;
    g_commands.push_back({p, std::min(groups, 1024u), (groups + 1023) / 1024, param});
}

constexpr std::uint32_t kCacheWords = 4u << 20;
constexpr std::size_t kCacheMinBytes = 256;

struct CacheEntry {
    std::uint64_t key;
    std::uint32_t offset, words;
    std::size_t bytes;
    std::uint64_t used;
};

WGPUBuffer g_cache = nullptr;
std::vector<std::uint32_t> g_cache_copy;
std::deque<CacheEntry> g_cache_ring;
std::unordered_multimap<std::uint64_t, CacheEntry *> g_cache_index;
std::unordered_map<std::uint64_t, std::uint32_t> g_cache_seen;
std::uint32_t g_cache_head = 0;
std::uint64_t g_serial = 1;

std::uint64_t content_key(const std::uint8_t *p, std::size_t n) {
    std::uint64_t h = static_cast<std::uint64_t>(n) * 0x9E3779B97F4A7C15ull;
    const auto mix = [&h](std::uint64_t v) {
        h ^= v + 0x9E3779B97F4A7C15ull + (h << 6) + (h >> 2);
        h *= 0xBF58476D1CE4E5B9ull;
    };
    const std::size_t step = std::max<std::size_t>(8, (n / 64) & ~static_cast<std::size_t>(7));
    std::uint64_t v;
    for (std::size_t i = 0; i + 8 <= n; i += step) {
        std::memcpy(&v, p + i, 8);
        mix(v);
    }
    v = 0;
    std::memcpy(&v, p + n - std::min<std::size_t>(n, 8), std::min<std::size_t>(n, 8));
    mix(v);
    return h;
}

bool cache_find(std::uint64_t key, const std::uint8_t *bytes, std::size_t n, std::uint32_t &offset) {
    const auto [first, last] = g_cache_index.equal_range(key);
    for (auto it = first; it != last; ++it) {
        CacheEntry &e = *it->second;
        if (e.bytes != n || std::memcmp(g_cache_copy.data() + e.offset, bytes, n) != 0) continue;
        e.used = g_serial;
        offset = e.offset;
        return true;
    }
    return false;
}

bool cache_insert(std::uint64_t key, const std::uint8_t *bytes, std::size_t n, std::uint32_t &offset) {
    const auto words = static_cast<std::uint32_t>((n + 3) / 4 + 1);
    if (words > kCacheWords / 4) return false;
    const auto evict_front = [] {
        CacheEntry &front = g_cache_ring.front();
        if (front.used == g_serial) return false;
        const auto [first, last] = g_cache_index.equal_range(front.key);
        for (auto it = first; it != last; ++it)
            if (it->second == &front) {
                g_cache_index.erase(it);
                break;
            }
        g_cache_ring.pop_front();
        return true;
    };
    if (g_cache_head + words > kCacheWords) {
        while (!g_cache_ring.empty() && g_cache_ring.front().offset >= g_cache_head)
            if (!evict_front()) return false;
        g_cache_head = 0;
    }
    while (!g_cache_ring.empty() && g_cache_ring.front().offset < g_cache_head + words)
        if (!evict_front()) return false;
    offset = g_cache_head;
    std::uint32_t *to = g_cache_copy.data() + offset;
    to[words - 1] = 0;
    to[words - 2] = 0;
    std::memcpy(to, bytes, n);
    wgpuQueueWriteBuffer(g_queue, g_cache, static_cast<std::uint64_t>(offset) * 4, to, static_cast<std::uint64_t>(words) * 4);
    g_cache_ring.push_back({key, offset, words, n, g_serial});
    g_cache_index.emplace(key, &g_cache_ring.back());
    g_cache_head += words;
    return true;
}

std::uint32_t arena_append(const void *bytes, std::size_t size) {
    const std::uint32_t offset = static_cast<std::uint32_t>(g_arena.size());
    const std::size_t words = (size + 3) / 4 + 1;
    std::uint32_t *to = g_arena.grow(words);
    to[words - 2] = 0;
    to[words - 1] = 0;
    std::memcpy(to, bytes, size);
    return offset;
}

float u2f(std::uint32_t u) {
    float f;
    std::memcpy(&f, &u, 4);
    return f;
}

struct Span {
    std::int16_t ty, tx0, tx1;
};
std::vector<Span> g_spans;
std::vector<std::uint32_t> g_span_start;

void add_spans(const std::uint32_t *rec, std::uint32_t lo, std::uint32_t hi) {
    const int scx = static_cast<int>(g_sx), scy = static_cast<int>(g_sy);
    const int tx0 = static_cast<int>(lo & 0xFFFFu) * scx / 16, ty0 = static_cast<int>(lo >> 16) * scy / 16;
    const int tx1 = (static_cast<int>(hi & 0xFFFFu) * scx + scx - 1) / 16, ty1 = (static_cast<int>(hi >> 16) * scy + scy - 1) / 16;
    const auto whole = [&] {
        for (int ty = ty0; ty <= ty1; ++ty) g_spans.push_back({static_cast<std::int16_t>(ty), static_cast<std::int16_t>(tx0), static_cast<std::int16_t>(tx1)});
    };
    if (rec[1] != 0 || tx1 - tx0 < 2) {
        whole();
        return;
    }
    const double x[3] = {u2f(rec[4]), u2f(rec[6]), u2f(rec[8])}, y[3] = {u2f(rec[5]), u2f(rec[7]), u2f(rec[9])};
    const double inv = u2f(rec[10]);
    static const int kEdges[3][2] = {{1, 2}, {2, 0}, {0, 1}};
    double m[3], q[3];
    int kind[3];
    for (int e = 0; e < 3; ++e) {
        const int a = kEdges[e][0], b = kEdges[e][1];
        const double ca = (y[a] - y[b]) * inv, cb = (x[b] - x[a]) * inv, cc = (x[a] * y[b] - x[b] * y[a]) * inv;
        if (!std::isfinite(ca) || !std::isfinite(cb) || !std::isfinite(cc)) {
            whole();
            return;
        }
        kind[e] = ca > 0.0 ? 1 : ca < 0.0 ? -1 : 0;
        m[e] = kind[e] ? -cb / ca : cb;
        q[e] = kind[e] ? -cc / ca : cc;
    }
    const double span = 16.0 / static_cast<double>(scy), xspan = 16.0 / static_cast<double>(scx);
    for (int ty = ty0; ty <= ty1; ++ty) {
        const double y0 = ty * span - 1.0, y1 = (ty + 1) * span + 1.0;
        double left = -1e30, right = 1e30;
        bool empty = false;
        for (int e = 0; e < 3; ++e) {
            const double a0 = m[e] * y0, a1 = m[e] * y1;
            if (kind[e] == 0) empty = empty || std::max(a0, a1) + q[e] < 0.0;
            else if (kind[e] > 0) left = std::max(left, std::min(a0, a1) + q[e]);
            else right = std::min(right, std::max(a0, a1) + q[e]);
        }
        left -= 1.0;
        right += 1.0;
        if (empty || left > right) continue;
        const int rx0 = std::max(tx0, static_cast<int>(std::floor(std::max(left, -1.0) / xspan)));
        const int rx1 = std::min(tx1, static_cast<int>(std::floor(std::min(right, 4096.0) / xspan)));
        if (rx0 <= rx1) g_spans.push_back({static_cast<std::int16_t>(ty), static_cast<std::int16_t>(rx0), static_cast<std::int16_t>(rx1)});
    }
}

bool reads_own_word(const std::uint32_t *rec, const std::uint32_t *setup) {
    const std::uint32_t fpsm = setup[3], tpsm = setup[14];
    if (rec[1] != 1 || (setup[0] & (16u | 16384u)) != 16u || setup[12] != setup[1] || setup[13] != setup[2]) return false;
    float f[6], uv[6];
    std::memcpy(f, rec + 4, sizeof f);
    std::memcpy(uv, rec + 15, sizeof uv);
    const float du = (uv[3] - uv[0]) / 16.0f, dv = (uv[4] - uv[1]) / 16.0f;
    if (f[2] == 0.0f || f[3] == 0.0f || std::fabs(du - f[2]) > 0.0005f * std::fabs(f[2]) || std::fabs(dv - f[3]) > 0.0005f * std::fabs(f[3])) return false;
    const int x0 = static_cast<int>(rec[2] & 0xFFFFu), y0 = static_cast<int>(rec[2] >> 16), x1 = static_cast<int>(rec[3] & 0xFFFFu), y1 = static_cast<int>(rec[3] >> 16);
    const auto texel = [](float a, float b, float origin, float span, int p) {
        return static_cast<int>(std::floor((a + (b - a) * ((static_cast<float>(p) - origin) / span)) / 16.0f));
    };
    for (const int y : {y0, y1})
        if (texel(uv[1], uv[4], f[1], f[3], y) != y) return false;
    const int ox = texel(uv[0], uv[3], f[0], f[2], x0) - x0;
    if (texel(uv[0], uv[3], f[0], f[2], x1) - x1 != ox) return false;
    const auto wide = [](std::uint32_t psm) { return psm == PSMCT32 || psm == PSMCT24 || psm == PSMT8H || psm == PSMT4HL || psm == PSMT4HH; };
    if (ox == 0) return tpsm == fpsm || (wide(fpsm) && wide(tpsm));
    const bool half = fpsm == PSMCT16 || fpsm == PSMCT16S;
    return half && tpsm == fpsm && (ox == 8 || ox == -8) && x1 - x0 < 8 && (x0 & 8) == (x1 & 8) && ((x0 ^ 8) == x0 + ox);
}

Range read_range(const std::uint32_t *rec, const std::uint32_t *setup, const Range &whole) {
    if (rec[1] != 1 || !(setup[0] & 16u)) return whole;
    float uv[6];
    std::memcpy(uv, rec + 15, sizeof uv);
    const int u0 = static_cast<int>(std::floor(std::min(uv[0], uv[3]) / 16.0f)) - 1, u1 = static_cast<int>(std::ceil(std::max(uv[0], uv[3]) / 16.0f)) + 1;
    const int v0 = static_cast<int>(std::floor(std::min(uv[1], uv[4]) / 16.0f)) - 1, v1 = static_cast<int>(std::ceil(std::max(uv[1], uv[4]) / 16.0f)) + 1;
    const int tw = std::max(1 << (setup[15] & 0xFFu), static_cast<int>(setup[18] >> 16) + 1), th = std::max(1 << (setup[15] >> 8), static_cast<int>(setup[19] >> 16) + 1);
    if (u0 < 0 || v0 < 0 || u1 >= tw || v1 >= th) return whole;
    return region(setup[12], setup[13], setup[14], u0, v0, u1, v1);
}

Range pages(std::uint32_t bp, std::uint32_t bw, std::uint32_t psm, int x0, int y0, int x1, int y1) {
    std::uint32_t pw, ph;
    page_size(psm, pw, ph);
    const std::uint64_t per_row = std::max<std::uint32_t>(1, bw * 64 / pw);
    const auto page = [&](int x, int y) {
        return static_cast<std::uint64_t>(bp) * 256 + (static_cast<std::uint64_t>(std::max(x, 0)) / pw + static_cast<std::uint64_t>(std::max(y, 0)) / ph * per_row) * 8192;
    };
    Range r;
    r.add(page(x0, y0), page(x1, y1) + 8192);
    return r;
}

// every write to a VRAM page bumps its count, so a texture decoded earlier in this submit can be reused
// by later batches as long as none of its pages changed since (the menus re-read the same textures 100+ times)
std::uint32_t g_page_epoch[512] = {};
void bump_pages(const Range &r) {
    for (std::uint64_t at = r.lo & ~8191ull; at < r.hi; at += 8192) ++g_page_epoch[(at >> 13) & 511u];
}
std::uint64_t pages_epoch(const Range &r) {
    std::uint64_t sum = 0;
    for (std::uint64_t at = r.lo & ~8191ull; at < r.hi; at += 8192) sum += g_page_epoch[(at >> 13) & 511u];
    return sum;
}
struct CachedDecode {
    std::uint32_t key[9];
    std::uint32_t offset, words;
    std::uint64_t lo, hi, epoch;
};
// Decoded textures stay put from frame to frame (the decoded buffer is used as a ring: when a batch could run past
// its end, everything starts over at 0). A cached copy is good while its VRAM pages and palette are unchanged.
std::unordered_multimap<std::uint64_t, CachedDecode> g_decode_cache;
constexpr std::size_t kDecodeCacheMax = 16384;
extern std::atomic<bool> g_decode_many_on;
void decode_reset() { g_decoded_used = 0; g_decode_cache.clear(); }
// what each CLUT slot holds: changes whenever a load puts different colours in it (palette textures key on this,
// not on the slot number, so a decode made last frame is found again when the same palette is loaded again)
// (per 16-entry slice of each slot: a load overwrites only some slices, the rest are carried over from the slot before)
std::array<std::uint32_t, 32> g_slot_ident[2048] = {};
std::uint32_t g_ident_serial = 0;
std::uint32_t mix32(std::uint32_t h, std::uint32_t v) { h ^= v + 0x9E3779B9u + (h << 6) + (h >> 2); return h * 0x85EBCA6Bu ^ (h >> 13); }
bool palette_psm(std::uint32_t psm) { return psm == 0x13u || psm == 0x1Bu || psm == 0x14u || psm == 0x24u || psm == 0x2Cu; }

void mark_rendered(const Range &r) {
    for (std::uint64_t at = r.lo; at < r.hi; at += 8192) g_rendered[(at >> 13) & 511u] = true;
    bump_pages(r);
}

std::uint64_t g_max_binding = 128ull << 20;

bool rendered(const Range &r) {
    for (std::uint64_t at = r.lo; at < r.hi; at += 8192)
        if (g_rendered[(at >> 13) & 511u]) return true;
    return false;
}

struct Decode {
    std::uint32_t setup, offset, words;
};
std::vector<Decode> g_decodes;

void plan_decodes(std::uint32_t prims) {
    CpuTimer cpu_timer(3);
    Batch &b = g_batch;
    g_decodes.clear();
    if (!g_decode) return;
    if (prims <= kDecodePrims) {
        // few prims but big ones: when upscaled, every sample pays the swizzle + palette lookup, so a batch that
        // covers a lot of screen (menu backgrounds stacked 10 deep) is far cheaper with its textures decoded once
        // (also at 1x: on integrated graphics the pause menu's 42 stacked 4-bit backgrounds cost 12 ms undecoded)
        std::uint64_t area = 0;
        for (std::uint32_t i = 0; i < prims; ++i) {
            const std::uint32_t lo = b.boxes[i * 2], hi = b.boxes[i * 2 + 1];
            const int w = static_cast<int>(hi & 0xFFFFu) - static_cast<int>(lo & 0xFFFFu) + 1, h = static_cast<int>(hi >> 16) - static_cast<int>(lo >> 16) + 1;
            if (w > 0 && h > 0) area += static_cast<std::uint64_t>(w) * static_cast<std::uint64_t>(h);
        }
        // (and a full-screen glow quad that samples the swizzled frame four times a pixel cost 3.7 ms on Intel: decoding
        // its texture once is ~0.3 ms, so anything covering a quarter-screen or more is decoded too)
        if (area * g_sx * g_sy < (g_decode_many_on.load(std::memory_order_relaxed) ? (1ull << 16) : (1ull << 20))) return;
    }
    const std::uint32_t setups = static_cast<std::uint32_t>(b.setups.size() / kSetupWords);
    static const int kKey[] = {12, 13, 14, 15, 16, 17, 20, 22};
    {
        // the ring can't wrap in the middle of a batch (a texture this batch reuses could be overwritten): start over first
        std::uint64_t bound = 0;
        for (std::uint32_t i = 0; i < setups; ++i) {
            const std::uint32_t *w = b.setups.data() + i * kSetupWords;
            if ((w[0] & 2u) && w[25] == 0xFFFFFFFFu) bound += 1ull << ((w[15] & 0xFFu) + (w[15] >> 8));
        }
        if (g_decoded_used + std::min<std::uint64_t>(bound, kDecodedWords) > kDecodedWords || g_decode_cache.size() > kDecodeCacheMax) decode_reset();
    }
    for (std::uint32_t i = 0; i < setups; ++i) {
        std::uint32_t *w = b.setups.data() + i * kSetupWords;
        if (!(w[0] & 2u) || w[25] != 0xFFFFFFFFu) continue;
        bool shared = false;
        for (const Decode &d : g_decodes) {
            const std::uint32_t *o = b.setups.data() + d.setup * kSetupWords;
            bool same = (o[0] & 32768u) == (w[0] & 32768u);
            for (int k : kKey) same = same && o[k] == w[k];
            if (same) {
                w[24] = d.offset;
                shared = true;
                break;
            }
        }
        if (shared) continue;
        const std::uint32_t tw = w[15] & 0xFFu, th = w[15] >> 8;
        const std::uint32_t mu = (w[7] >> 24) & 3u, mv = (w[7] >> 26) & 3u;
        const auto inside = [](std::uint32_t mode, std::uint32_t region, std::uint32_t size) { return mode < 2 || ((region & 0x3FFu) < (1u << size) && (region >> 16) < (1u << size)); };
        if (!inside(mu, w[18], tw) || !inside(mv, w[19], th)) continue;
        const std::uint32_t words = 1u << (tw + th);
        const Range tex = pages(w[12], w[13], w[14], 0, 0, (1 << tw) - 1, (1 << th) - 1);
        if (g_sx * g_sy > 1 && rendered(tex)) continue;
        std::uint32_t key[9];
        for (int k = 0; k < 8; ++k) key[k] = w[kKey[k]];
        if (palette_psm(w[14])) {
            const std::array<std::uint32_t, 32> &sl = g_slot_ident[w[22] & 2047u];
            if (w[14] == 0x13u || w[14] == 0x1Bu) {
                key[7] = 0x8u;
                for (int k = 0; k < 16; ++k) key[7] = mix32(key[7], sl[k]);
            } else {
                key[7] = sl[w[17] & 15u];
            }
        } else {
            key[7] = 0u;
        }
        key[8] = w[0] & 32768u;
        const std::uint64_t epoch = pages_epoch(tex);
        std::uint64_t hash = tex.lo * 0x9E3779B97F4A7C15ull ^ tex.hi ^ (static_cast<std::uint64_t>(words) << 40);
        for (std::uint32_t k : key) hash = (hash ^ k) * 0x100000001B3ull;
        bool reused = false;
        for (auto [it, end] = g_decode_cache.equal_range(hash); it != end; ++it) {
            const CachedDecode &c = it->second;
            if (c.lo == tex.lo && c.hi == tex.hi && c.epoch == epoch && c.words == words && std::memcmp(c.key, key, sizeof key) == 0) {
                w[24] = c.offset;
                reused = true;
                break;
            }
        }
        if (reused) continue;
        if (g_decoded_used + words > kDecodedWords) continue;
        w[24] = g_decoded_used;
        g_decodes.push_back({i, g_decoded_used, words});
        CachedDecode c{};
        std::memcpy(c.key, key, sizeof key);
        c.offset = g_decoded_used;
        c.words = words;
        c.lo = tex.lo;
        c.hi = tex.hi;
        c.epoch = epoch;
        g_decode_cache.emplace(hash, c);
        g_decoded_used += words;
    }
}

// every dispatch in a pass is followed by a full barrier on the GPU; a batch often decodes 5-20 small textures, so
// they go out as one dispatch (each thread finds its texture in a little job table) instead of one each
void emit_decodes(std::uint32_t setup_offset) {
    if (g_decodes.empty()) return;
    if (g_decodes.size() == 1 || !g_decode_many_on.load(std::memory_order_relaxed)) {
        for (const Decode &d : g_decodes) dispatch_linear(kDecode, d.words, push_params({setup_offset + d.setup * kSetupWords, d.offset, d.words}));
        return;
    }
    static std::vector<std::uint32_t> jobs;
    jobs.clear();
    std::uint32_t total = 0;
    for (const Decode &d : g_decodes) {
        jobs.insert(jobs.end(), {setup_offset + d.setup * kSetupWords, d.offset, d.words, total});
        total += d.words;
    }
    const std::uint32_t at = arena_append(jobs.data(), jobs.size() * 4);
    dispatch_linear(kDecodeMany, total, push_params({at, static_cast<std::uint32_t>(g_decodes.size()), total}));
}

std::uint32_t snapshot_batch(std::uint32_t prims, std::uint32_t &lo, std::uint32_t &hi) {
    Batch &b = g_batch;
    lo = hi = 0;
    if (g_batch_reads.empty()) return 0;
    const Range fb = pages(b.fbp, b.fbw, b.fpsm, b.minx, b.miny, b.maxx, b.maxy);
    const Range z = pages(b.zbp, b.fbw, b.zpsm, b.minx, b.miny, b.maxx, b.maxy);
    const auto written = [&](const Range &t) { return t.overlaps(fb.lo, fb.hi) || (b.zwrite && t.overlaps(z.lo, z.hi)); };
    bool any = false;
    for (const Range &t : g_batch_reads) any = any || written(t);
    if (!any) return 0;
    Range shared;
    for (std::uint32_t i = 0; i < prims; ++i) {
        const std::uint32_t *rec = b.prims.data() + i * kPrimWords;
        const std::uint32_t *setup = b.setups.data() + rec[0] * kSetupWords;
        if (!(setup[0] & 2u) || reads_own_word(rec, setup)) continue;
        const int tw = std::max(1 << (setup[15] & 0xFFu), static_cast<int>(setup[18] >> 16) + 1), th = std::max(1 << (setup[15] >> 8), static_cast<int>(setup[19] >> 16) + 1);
        const Range t = read_range(rec, setup, region(setup[12], setup[13], setup[14], 0, 0, tw - 1, th - 1));
        for (const Range *w : {&fb, b.zwrite ? &z : nullptr})
            if (w && t.overlaps(w->lo, w->hi)) shared.add(std::max(t.lo, w->lo), std::min(t.hi, w->hi));
    }
    if (shared.lo >= shared.hi) return 0;
    lo = static_cast<std::uint32_t>(std::min<std::uint64_t>(shared.lo, kMemorySize) / 4);
    hi = static_cast<std::uint32_t>(std::min<std::uint64_t>(shared.hi, kMemorySize) / 4);
    if (hi <= lo) return 0;
    const std::uint32_t words = (hi - lo) * g_sx * g_sy;
    dispatch_linear(kSnapshot, words, push_params({lo, words}));
    return words;
}

void note_raster(std::uint32_t prims, std::uint32_t tiles, std::uint32_t entries, std::uint32_t snapshot) {
    if (!g_profile_out) return;
    const Batch &b = g_batch;
    const std::uint32_t *first = b.setups.data();
    std::uint32_t textured = 0;
    for (std::uint32_t i = 0; i < prims; ++i) textured += (b.setups[b.prims[i * kPrimWords] * kSetupWords] & 2u) ? 1u : 0u;
    g_command_info.push_back({g_commands.size(), {prims, tiles, entries, snapshot, b.prims[1], first[3] | (first[14] << 8) | (first[6] << 16), first[0], textured, first[15], first[24]}});
}

// Fast-lane blend variant for one setup's ALPHA register (A - B) * C >> 7 + D, -1 when the blend unit cannot do it.
// A, B, D: 0 = source colour, 1 = frame colour, 2 = zero; C: 0 = source alpha, 1 = frame alpha, 2 = FIX.
// Variants (F = factor, C/128): 0 Cs, 1 Cs*F + Cd*(1-F), 2 Cs*F + Cd, 3 Cs*F, 4 Cd - Cs*F, 5 Cs*(1-F) + Cd*F,
// 6 Cs + Cd*F, 7 Cd*F, 8 Cd (nothing changes), 9 zero; +16 = F is the FIX constant instead of the source alpha.
int fast_variant(const std::uint32_t *w) {
    if (!(w[0] & 8u)) return 0;
    const std::uint32_t alpha = (w[7] >> 12) & 0xFFu;
    const std::uint32_t a = alpha & 3u, bb = (alpha >> 2) & 3u, c = (alpha >> 4) & 3u, d = (alpha >> 6) & 3u;
    if (a == 3u || bb == 3u || d == 3u || c == 3u) return -1;
    if (a == bb) return d == 0u ? 0 : d == 1u ? 8 : 9;
    int v = -1;
    if (a == 0 && bb == 1 && d == 1) v = 1;
    else if (a == 0 && bb == 2 && d == 1) v = 2;
    else if (a == 0 && bb == 2 && d == 2) v = 3;
    else if (a == 2 && bb == 0 && d == 1) v = 4;
    else if (a == 1 && bb == 0 && d == 0) v = 5;
    else if (a == 1 && bb == 2 && d == 0) v = 6;
    else if (a == 1 && bb == 2 && d == 2) v = 7;
    if (v < 0 || c == 1u) return -1;
    return c == 2u ? v + 16 : v;
}

// true when the whole batch can go through the fast lane (and it covers enough pixels to pay for the copy in and out)
bool fast_ok(std::uint32_t prims, std::vector<int> &variants) {
    const Batch &b = g_batch;
    if (b.fpsm != PSMCT32 && b.fpsm != PSMCT24) return ++g_fast_reject[0], false;
    const int w = b.maxx - b.minx + 1, h = b.maxy - b.miny + 1;
    if (w <= 0 || h <= 0 || b.minx < 0 || b.miny < 0 || static_cast<std::uint32_t>(b.maxx + 1) * g_sx > g_fast_w || static_cast<std::uint32_t>(b.maxy + 1) * g_sy > g_fast_h) return ++g_fast_reject[1], false;
    std::uint64_t work = 0;
    for (std::uint32_t i = 0; i < prims; ++i) {
        const std::uint32_t lo = b.boxes[i * 2], hi = b.boxes[i * 2 + 1];
        const int bw = static_cast<int>(hi & 0xFFFFu) - static_cast<int>(lo & 0xFFFFu) + 1, bh = static_cast<int>(hi >> 16) - static_cast<int>(lo >> 16) + 1;
        if (bw > 0 && bh > 0) work += static_cast<std::uint64_t>(bw) * static_cast<std::uint64_t>(bh);
    }
    // small batches only pay off when the frame is already in the fast lane's texture (nothing to copy but their box)
    const bool joins = g_res.on && g_res.fbp == b.fbp && g_res.fbw == b.fbw && g_res.fpsm == b.fpsm;
    if (!joins && work * g_sx * g_sy < g_fast_min_work) return ++g_fast_reject[2], false;
    const std::size_t setups = b.setups.size() / kSetupWords;
    variants.assign(setups, 0);
    for (std::size_t i = 0; i < setups; ++i) {
        const std::uint32_t *s = b.setups.data() + i * kSetupWords;
        const std::uint32_t flags = s[0];
        if (flags & (128u | 1024u)) return ++g_fast_reject[3], false;               // destination alpha test, per-pixel blend enable
        const bool zwrite = (flags & 512u) && !(flags & 32u);
        if (zwrite && (flags & 64u) && ((s[7] >> 4) & 3u) != 0u) return ++g_fast_reject[5], false;   // alpha test splitting colour / Z writes
        // frame write mask: whole bytes only (a colour channel kept as it is), CT24 never writes its top byte
        std::uint32_t mask = s[4] | (b.fpsm == PSMCT24 ? 0xFF000000u : 0u), keep = 0;
        for (int c = 0; c < 4; ++c) {
            const std::uint32_t m = (mask >> (c * 8)) & 0xFFu;
            if (m == 0xFFu) keep |= 1u << c;
            else if (m) return ++g_fast_reject[4], false;
        }
        if ((flags & 64u) && ((s[7] >> 4) & 3u) == 3u) return ++g_fast_reject[5], false;
        if ((flags & 8u) && !(flags & 2048u)) return ++g_fast_reject[6], false;   // blending without colour clamp (wraps)
        const int v = fast_variant(s);
        if (v < 0) return ++g_fast_reject[7], false;
        const std::uint32_t ztst = (flags & 512u) ? (s[7] >> 8) & 3u : 1u;
        if ((ztst >= 2u || zwrite) && b.zpsm != 0x30u && b.zpsm != 0x31u && b.zpsm != 0x32u && b.zpsm != 0x3Au) return ++g_fast_reject[8], false;
        variants[i] = v | static_cast<int>(ztst << 5) | (zwrite ? 128 : 0) | static_cast<int>(keep << 8);
    }
    return true;
}

void fast_report() {
    if (((g_fast_count[0] + g_fast_count[2]) & 8191u) != 0) return;
        std::fprintf(stderr, "[gpu] fast lane: %llu batches (%llu prims), %llu stayed; why: fmt %llu big %llu small %llu date %llu mask %llu atest %llu wrap %llu blend %llu zfmt %llu\n",
                     (unsigned long long)g_fast_count[0], (unsigned long long)g_fast_count[1], (unsigned long long)g_fast_count[2],
                     (unsigned long long)g_fast_reject[0], (unsigned long long)g_fast_reject[1], (unsigned long long)g_fast_reject[2], (unsigned long long)g_fast_reject[3],
                     (unsigned long long)g_fast_reject[4], (unsigned long long)g_fast_reject[5], (unsigned long long)g_fast_reject[6], (unsigned long long)g_fast_reject[7],
                     (unsigned long long)g_fast_reject[8]);
}

void finish_batch() {
    ++g_batch_serial;
    Batch &b = g_batch;
    mark_rendered(pages(b.fbp, b.fbw, b.fpsm, b.minx, b.miny, b.maxx, b.maxy));
    if (b.zwrite) mark_rendered(pages(b.zbp, b.fbw, b.zpsm, b.minx, b.miny, b.maxx, b.maxy));
    ++g_batch_serial;
    b.prims.clear();
    b.setups.clear();
    b.boxes.clear();
    g_batch_reads.clear();
    b.key = ~0ull;
    b.minx = b.miny = 1 << 30;
    b.maxx = b.maxy = -1;
}

// copy the frame rectangle out, draw every primitive with the blend unit, copy it back
std::uint32_t rect_param(const Rect &r, std::uint32_t fbp, std::uint32_t fbw, std::uint32_t fpsm, std::uint32_t zbp, std::uint32_t zpsm) {
    return push_params({0, 0, 0, 0, 0, 0, 0, static_cast<std::uint32_t>(r.x0), static_cast<std::uint32_t>(r.y0), static_cast<std::uint32_t>(r.x1 - r.x0 + 1) * g_sx,
                        static_cast<std::uint32_t>(r.y1 - r.y0 + 1) * g_sy, fbp, fbw, fpsm, g_fast_w, g_fast_h, zbp, zpsm});
}

// the parts of `grown` not in `have` (have is inside grown): up to four strips
void strips(const Rect &have, const Rect &grown, std::vector<Rect> &out) {
    out.clear();
    if (have.empty()) { out.push_back(grown); return; }
    if (grown.y0 < have.y0) out.push_back({grown.x0, grown.y0, grown.x1, have.y0 - 1});
    if (grown.y1 > have.y1) out.push_back({grown.x0, have.y1 + 1, grown.x1, grown.y1});
    if (grown.x0 < have.x0) out.push_back({grown.x0, have.y0, have.x0 - 1, have.y1});
    if (grown.x1 > have.x1) out.push_back({have.x1 + 1, have.y0, grown.x1, have.y1});
}

void res_flush() {
    if (!g_res.on) return;
    Resident r = g_res;
    g_res = Resident{};
    const bool hold = g_res_hold;
    g_res_hold = true;
    if (!r.dirty.empty()) {
        const std::uint32_t pm = rect_param(r.dirty, r.fbp, r.fbw, r.fpsm, r.zbp, r.zpsm);
        g_commands.push_back({kFastStore, ((r.dirty.x1 - r.dirty.x0 + 1) * g_sx + 7) / 8, ((r.dirty.y1 - r.dirty.y0 + 1) * g_sy + 7) / 8, pm});
    }
    if (r.z && !r.zdirty.empty()) {
        const std::uint32_t pm = rect_param(r.zdirty, r.fbp, r.fbw, r.fpsm, r.zbp, r.zpsm);
        g_commands.push_back({kFastZStore, ((r.zdirty.x1 - r.zdirty.x0 + 1) * g_sx + 7) / 8, ((r.zdirty.y1 - r.zdirty.y0 + 1) * g_sy + 7) / 8, pm});
    }
    g_res_hold = hold;
}

bool res_touched(const Range &t) {
    if (!g_res.on) return false;
    const Range f = pages(g_res.fbp, g_res.fbw, g_res.fpsm, g_res.loaded.x0, g_res.loaded.y0, g_res.loaded.x1, g_res.loaded.y1);
    if (!g_res.loaded.empty() && t.overlaps(f.lo, f.hi)) return true;
    if (g_res.z && !g_res.zloaded.empty()) {
        const Range z = pages(g_res.zbp, g_res.fbw, g_res.zpsm, g_res.zloaded.x0, g_res.zloaded.y0, g_res.zloaded.x1, g_res.zloaded.y1);
        if (t.overlaps(z.lo, z.hi)) return true;
    }
    return false;
}

void flush_fast(std::uint32_t prims, const std::vector<int> &variants) {
    CpuTimer cpu_timer(1);
    Batch &b = g_batch;
    FastBatch fb;
    for (const int v : variants) fb.zload = fb.zload || ((v >> 5) & 3) >= 2 || (v & 128);
    // a different target, or a texture read from what is resident: put it back first
    if (g_res.on) {
        bool out = !g_res_on.load(std::memory_order_relaxed) || g_res.fbp != b.fbp || g_res.fbw != b.fbw || g_res.fpsm != b.fpsm;
        if (fb.zload && g_res.z && (g_res.zbp != b.zbp || g_res.zpsm != b.zpsm)) out = true;
        for (const Range &t : g_batch_reads) out = out || res_touched(t);
        if (out) res_flush();
    }
    if (fb.zload && g_res.on && g_res.z && (g_res.zbp != b.zbp || g_res.zpsm != b.zpsm)) res_flush();
    if (!g_res.on) {
        g_res.on = true;
        g_res.fbp = b.fbp; g_res.fbw = b.fbw; g_res.fpsm = b.fpsm;
    }
    if (fb.zload && !g_res.z) {
        g_res.z = true;
        g_res.zbp = b.zbp; g_res.zpsm = b.zpsm;
    }
    g_res_hold = true;
    plan_decodes(prims);
    const std::uint32_t prim_offset = arena_append(b.prims.data(), b.prims.size() * 4);
    const std::uint32_t setup_offset = arena_append(b.setups.data(), b.setups.size() * 4);
    emit_decodes(setup_offset);
    const Rect box{b.minx, b.miny, b.maxx, b.maxy};
    static std::vector<Rect> add;
    if (!box.inside(g_res.loaded)) {
        Rect grown = g_res.loaded;
        grown.add(box);
        strips(g_res.loaded, grown, add);
        for (const Rect &r : add) {
            const std::uint32_t pm = rect_param(r, b.fbp, b.fbw, b.fpsm, b.zbp, b.zpsm);
            g_commands.push_back({kFastLoad, ((r.x1 - r.x0 + 1) * g_sx + 7) / 8, ((r.y1 - r.y0 + 1) * g_sy + 7) / 8, pm});
        }
        g_res.loaded = grown;
    }
    if (fb.zload && g_fast_zload && !box.inside(g_res.zloaded)) {
        Rect grown = g_res.zloaded;
        grown.add(box);
        strips(g_res.zloaded, grown, add);
        for (const Rect &r : add) fb.zloads.push_back(rect_param(r, b.fbp, b.fbw, b.fpsm, b.zbp, b.zpsm));
        g_res.zloaded = grown;
    }
    g_res.dirty.add(box);
    if (b.zwrite) g_res.zdirty.add(box);
    g_res_hold = false;
    const std::uint32_t width = static_cast<std::uint32_t>(b.maxx - b.minx + 1) * g_sx, height = static_cast<std::uint32_t>(b.maxy - b.miny + 1) * g_sy;
    const std::uint32_t param = push_params({0, prim_offset, setup_offset, 0, 0, 0, 0, 0, 0, width, height, b.fbp, b.fbw, b.fpsm, g_fast_w, g_fast_h, b.zbp, b.zpsm});
    fb.param = param;
    for (std::uint32_t i = 0; i < prims; ++i) {
        const std::uint32_t setup = b.prims[i * kPrimWords];
        const std::uint32_t v = static_cast<std::uint32_t>(variants[setup]);
        const float fix = std::min(1.0f, static_cast<float>(b.setups[setup * kSetupWords + 9]) / 128.0f);
        if (!fb.draws.empty() && fb.draws.back().variant == v && (!(v & 16u) || fb.draws.back().fix == fix)) {
            ++fb.draws.back().count;
        } else {
            fb.draws.push_back({v, i, 1, fix});
        }
    }
    if (g_profile_out) g_command_info.push_back({g_commands.size(), {prims, width, height, static_cast<std::uint32_t>(fb.draws.size()), b.fpsm, b.fbp, static_cast<std::uint32_t>(fb.zload), static_cast<std::uint32_t>(g_decodes.size()), 0, 0}});
    g_commands.push_back({kFastDraw, 0, 0, static_cast<std::uint32_t>(g_fast_batches.size())});
    g_fast_batches.push_back(std::move(fb));
    if (!g_res_on.load(std::memory_order_relaxed)) res_flush();
    ++g_fast_count[0];
    g_fast_count[1] += prims;
    fast_report();

    finish_batch();
}

void flush_batch() {
    CpuTimer cpu_timer(0); g_ps2_cpu_times[9] += 1;
    Batch &b = g_batch;
    if (b.prims.empty()) {
        b.key = ~0ull;
        return;
    }
    const std::uint32_t prims = static_cast<std::uint32_t>(b.prims.size() / kPrimWords);
    if (g_fast && g_fast_on.load(std::memory_order_relaxed)) {
        static std::vector<int> variants;
        if (fast_ok(prims, variants)) {
            flush_fast(prims, variants);
            return;
        }
        ++g_fast_count[2];
        fast_report();
    }
    g_touched.clear();
    g_spans.clear();
    g_span_start.resize(prims + 1);
    for (std::uint32_t i = 0; i < prims; ++i) {
        g_span_start[i] = static_cast<std::uint32_t>(g_spans.size());
        add_spans(b.prims.data() + i * kPrimWords, b.boxes[i * 2], b.boxes[i * 2 + 1]);
        for (std::size_t k = g_span_start[i]; k < g_spans.size(); ++k) {
            const Span &sp = g_spans[k];
            std::uint32_t t = static_cast<std::uint32_t>(sp.ty * g_tiles_per_row + sp.tx0);
            for (int tx = sp.tx0; tx <= sp.tx1; ++tx, ++t)
                if (!g_tile_count[t]++) g_touched.push_back(t);
        }
    }
    g_span_start[prims] = static_cast<std::uint32_t>(g_spans.size());
    plan_decodes(prims);
    const std::uint32_t prim_offset = arena_append(b.prims.data(), b.prims.size() * 4);
    const std::uint32_t setup_offset = arena_append(b.setups.data(), b.setups.size() * 4);
    emit_decodes(setup_offset);
    std::uint32_t total = 0;
    for (std::uint32_t t : g_touched) total += g_tile_count[t];
    const std::uint32_t tiles = static_cast<std::uint32_t>(g_touched.size());
    const std::uint32_t tile_offset = static_cast<std::uint32_t>(g_arena.size());
    const std::uint32_t list_offset = tile_offset + tiles * 2 + 2;
    const std::uint32_t list_words = (total + 1) / 2;
    std::uint32_t *grown = g_arena.grow(tiles * 2 + 2 + list_words);
    if (list_words) grown[tiles * 2 + 2 + list_words - 1] = 0;
    std::uint32_t cursor = 0;
    for (std::uint32_t i = 0; i < tiles; ++i) {
        const std::uint32_t t = g_touched[i];
        grown[i * 2] = (t % static_cast<std::uint32_t>(g_tiles_per_row)) | ((t / static_cast<std::uint32_t>(g_tiles_per_row)) << 16);
        grown[i * 2 + 1] = cursor;
        g_tile_fill[t] = cursor;
        cursor += g_tile_count[t];
    }
    grown[tiles * 2] = 0;
    grown[tiles * 2 + 1] = cursor;
    auto *halves = reinterpret_cast<unsigned char *>(grown + tiles * 2 + 2);
    for (std::uint32_t i = 0; i < prims; ++i) {
        const auto index = static_cast<std::uint16_t>(i);
        for (std::uint32_t k = g_span_start[i]; k < g_span_start[i + 1]; ++k) {
            const Span &sp = g_spans[k];
            std::uint32_t t = static_cast<std::uint32_t>(sp.ty * g_tiles_per_row + sp.tx0);
            for (int tx = sp.tx0; tx <= sp.tx1; ++tx, ++t) std::memcpy(halves + 2u * g_tile_fill[t]++, &index, 2);
        }
    }
    for (std::uint32_t t : g_touched) g_tile_count[t] = 0;
    std::uint32_t snapshot_lo, snapshot_hi;
    const std::uint32_t snapshot = snapshot_batch(prims, snapshot_lo, snapshot_hi);
    const std::uint32_t param = push_params({tile_offset, prim_offset, setup_offset, tiles, list_offset, snapshot_lo, snapshot_hi});
    note_raster(prims, tiles, total, snapshot);
    res_flush();
    g_commands.push_back({kRaster, std::min(tiles, 1024u), (tiles + 1023) / 1024, param});
    mark_rendered(pages(b.fbp, b.fbw, b.fpsm, b.minx, b.miny, b.maxx, b.maxy));
    if (b.zwrite) mark_rendered(pages(b.zbp, b.fbw, b.zpsm, b.minx, b.miny, b.maxx, b.maxy));
    ++g_batch_serial;
    b.prims.clear();
    b.setups.clear();
    b.boxes.clear();
    g_batch_reads.clear();
    b.key = ~0ull;
    b.minx = b.miny = 1 << 30;
    b.maxx = b.maxy = -1;
}

void batch_ranges() {
    Batch &b = g_batch;
    if (b.rx0 == b.minx && b.ry0 == b.miny && b.rx1 == b.maxx && b.ry1 == b.maxy) return;
    b.rx0 = b.minx;
    b.ry0 = b.miny;
    b.rx1 = b.maxx;
    b.ry1 = b.maxy;
    b.fb_range = region(b.fbp, b.fbw, b.fpsm, b.minx, b.miny, b.maxx, b.maxy);
    b.z_range = region(b.zbp, b.fbw, b.zpsm, b.minx, b.miny, b.maxx, b.maxy);
}

bool batch_conflict(const Range &r, bool clut) {
    Batch &b = g_batch;
    if (b.prims.empty()) return false;
    batch_ranges();
    if (b.fb_range.overlaps(r.lo, r.hi)) return true;
    if (b.zte && b.z_range.overlaps(r.lo, r.hi)) return true;
    if (!clut)
        for (const Range &t : g_batch_reads)
            if (t.overlaps(r.lo, r.hi)) return true;
    return false;
}

void emit_pre() {
    CpuTimer cpu_timer(6);
    bool touch = false;
    for (const PreOp &op : g_pre) touch = touch || res_touched(op.range);
    if (touch) res_flush();
    const bool hold = g_res_hold;
    g_res_hold = true;
    struct Restore { bool v; ~Restore() { g_res_hold = v; } } restore{hold};
    std::size_t i = 0;
    while (i < g_pre.size()) {
        const bool clut = g_pre[i].clut;
        std::size_t j = i + 1;
        while (j < g_pre.size() && g_pre[j].clut == clut) {
            bool overlap = false;
            if (!clut)
                for (std::size_t k = i; k < j && !overlap; ++k) overlap = uploads_overlap(g_pre[k], g_pre[j]);
            if (overlap) break;
            ++j;
        }
        const std::uint32_t count = static_cast<std::uint32_t>(j - i);
        std::uint32_t *records = g_arena.grow(count * 12u);
        const std::uint32_t offset = static_cast<std::uint32_t>(records - g_arena.data());
        std::uint32_t total = 0;
        for (std::size_t k = i; k < j; ++k) {
            std::memcpy(records + (k - i) * 12, g_pre[k].rec, sizeof g_pre[k].rec);
            if (!clut) {
                records[(k - i) * 12 + 11] = total;
                total += g_pre[k].rec[7];
            }
        }
        if (clut) g_commands.push_back({kLoadClut, kClutEntries / 64, 1, push_params({offset, count})});   // one thread per entry (gs.wgsl)
        else dispatch_linear(kUpload, total, push_params({offset, count, total}));
        i = j;
    }
    g_pre.clear();
}

void emit_all() {
    emit_pre();
    flush_batch();
}

// An upload that writes the very same bytes to the same place as last time, with nothing drawn there since, leaves
// VRAM as it was: it doesn't count as a change (the game re-sends its palettes and HUD textures every frame, and
// that made every palette texture look new, so the decoded-texture cache never hit).
struct UploadSeen {
    std::uint64_t content, epoch;
};
std::unordered_map<std::uint64_t, UploadSeen> g_upload_seen;
// every byte counts here (content_key only samples): a changed texture must never look unchanged
std::uint64_t full_hash(const std::uint8_t *p, std::size_t n) {
    std::uint64_t a = 0x9E3779B97F4A7C15ull ^ n, b = 0xC2B2AE3D27D4EB4Full;
    std::size_t i = 0;
    for (; i + 16 <= n; i += 16) {
        std::uint64_t x, y;
        std::memcpy(&x, p + i, 8);
        std::memcpy(&y, p + i + 8, 8);
        a = (a ^ x) * 0xFF51AFD7ED558CCDull; a ^= a >> 29;
        b = (b ^ y) * 0xC4CEB9FE1A85EC53ull; b ^= b >> 31;
    }
    for (; i < n; ++i) a = (a ^ p[i]) * 0x100000001B3ull;
    return a ^ (b * 0x9E3779B97F4A7C15ull);
}
bool g_same_upload = false;

void queue_pre(const PreOp &op) {
    if (batch_conflict(op.range, op.clut)) emit_all();
    if (!op.clut && !g_same_upload) bump_pages(op.range);
    g_pre.push_back(op);
}

void submit(WGPUTextureView present_view);

std::uint64_t queue_upload(const std::uint8_t *bytes, std::size_t size, std::uint32_t lead_bits) {
    Image &im = g_image;
    const std::uint64_t bits = static_cast<std::uint64_t>(size) * 8;
    if (bits <= lead_bits) return 0;
    const std::uint32_t pixels = static_cast<std::uint32_t>(std::min<std::uint64_t>((bits - lead_bits) / im.bpp, im.total - im.done));
    if (!pixels) return 0;
    const std::uint64_t used = lead_bits + static_cast<std::uint64_t>(pixels) * im.bpp;
    PreOp op;
    const auto n = static_cast<std::size_t>((used + 7) / 8);
    std::uint32_t offset = 0, source = 0;
    if (n >= kCacheMinBytes) {
        const std::uint64_t key = content_key(bytes, n);
        bool cached = cache_find(key, bytes, n, offset);
        if (!cached && ++g_cache_seen[key] >= 2) {
            cached = cache_insert(key, bytes, n, offset);
            // The ring cannot evict its oldest entry while the pending submit reads it. A texture drawn every frame
            // is read again before the next insert, so without a submit here the cache would take nothing new
            // once it wraps, and every upload from then on goes through the per-submit buffer.
            if (!cached && !g_cache_ring.empty() && g_cache_ring.front().used == g_serial) {
                emit_all();
                submit(nullptr);
                cached = cache_insert(key, bytes, n, offset);
            }
        }
        if (cached) source = 0x80000000u;
        if (g_cache_seen.size() > 65536) g_cache_seen.clear();
    }
    if (!source) offset = arena_append(bytes, n);
    const std::uint32_t rec[11] = {im.dbp, im.dbw, im.dpsm, im.dsax, im.dsay, im.rrw, im.done, pixels, offset, lead_bits, im.bpp | source};
    std::memcpy(op.rec, rec, sizeof rec);
    const std::uint32_t first = im.done / im.rrw, last = (im.done + pixels - 1) / im.rrw;
    op.range = region(im.dbp, im.dbw, im.dpsm, static_cast<int>(im.dsax), static_cast<int>(im.dsay + first), static_cast<int>(im.dsax + im.rrw - 1),
                      static_cast<int>(im.dsay + last));
    op.x0 = im.dsax;
    op.x1 = im.dsax + im.rrw - 1;
    op.y0 = im.dsay + first;
    op.y1 = im.dsay + last;
    op.image = im.id;
    {
        std::uint64_t where = 0xCBF29CE484222325ull;
        for (std::uint32_t v : {im.dbp, im.dbw, im.dpsm, im.dsax, im.dsay + first, im.rrw, last - first, lead_bits, im.bpp}) where = (where ^ v) * 0x100000001B3ull;
        const std::uint64_t content = full_hash(bytes, n) ^ (static_cast<std::uint64_t>(n) << 48);
        auto it = g_upload_seen.find(where);
        g_same_upload = g_decode_many_on.load(std::memory_order_relaxed) && it != g_upload_seen.end() && it->second.content == content && it->second.epoch == pages_epoch(op.range);
        queue_pre(op);
        g_same_upload = false;
        if (g_upload_seen.size() > 8192) g_upload_seen.clear();
        g_upload_seen[where] = {content, pages_epoch(op.range)};
    }
    im.done += pixels;
    return used;
}

void finish_image_if_done() {
    Image &im = g_image;
    if (im.done < im.total) return;
    im.active = false;
    im.pending.clear();
    const std::uint32_t psm = im.dpsm;
    if (psm != PSMCT32 && psm != PSMCT16 && psm != PSMCT16S && psm != PSMT8 && psm != PSMT4 && psm != PSMZ32 && psm != PSMZ16 && psm != PSMZ16S) return;
    std::uint32_t pw, ph;
    page_size(psm, pw, ph);
    const std::uint32_t per_row = std::max<std::uint32_t>(1, im.dbw * 64 / pw), rows = im.rrw ? im.total / im.rrw : 0;
    for (std::uint32_t py = (im.dsay + ph - 1) / ph; py < (im.dsay + rows) / ph; ++py)
        for (std::uint32_t px = (im.dsax + pw - 1) / pw; px < (im.dsax + im.rrw) / pw; ++px)
            g_rendered[((im.dbp * 256 + (px + py * per_row) * 8192) >> 13) & 511u] = false;
}

void flush_image() {
    Image &im = g_image;
    if (!im.active || im.pending.empty()) return;
    const std::uint64_t used = queue_upload(im.pending.data(), im.pending.size(), im.lead_bits);
    if (!used) return;
    im.pending.erase(im.pending.begin(), im.pending.begin() + static_cast<std::ptrdiff_t>(used / 8));
    im.lead_bits = static_cast<std::uint32_t>(used % 8);
    finish_image_if_done();
}

void flush_all() {
    flush_image();
    emit_all();
}

void on_error(WGPUDevice const *, WGPUErrorType type, WGPUStringView message, void *, void *) {
    std::fprintf(stderr, "[gpu] error %d: %.*s\n", static_cast<int>(type), static_cast<int>(message.length == WGPU_STRLEN ? std::strlen(message.data) : message.length), message.data);
}

void pump() {
#ifdef __EMSCRIPTEN__
    browser_yield();
    wgpuInstanceProcessEvents(g_instance);
#else
    if (g_device) wgpuDevicePoll(g_device, true, nullptr);
    else wgpuInstanceProcessEvents(g_instance);
#endif
}

void wait_until(const bool &flag) {
    while (!flag) pump();
}

WGPUBuffer make_buffer(std::uint64_t size, WGPUBufferUsage usage) {
    WGPUBufferDescriptor d = WGPU_BUFFER_DESCRIPTOR_INIT;
    d.size = size;
    d.usage = usage;
    return wgpuDeviceCreateBuffer(g_device, &d);
}

void rebuild_group() {
    if (g_group) wgpuBindGroupRelease(g_group);
    WGPUBindGroupEntry e[9] = {};
    WGPUBuffer buffers[9] = {g_vram, g_tables, g_params, g_data, g_clut, g_scratch, g_cache, g_decoded, g_hd};
    for (int i = 0; i < 9; ++i) {
        e[i] = WGPU_BIND_GROUP_ENTRY_INIT;
        e[i].binding = static_cast<std::uint32_t>(i);
        e[i].buffer = buffers[i];
        e[i].size = i == 2 ? kParamStride : WGPU_WHOLE_SIZE;
    }
    WGPUBindGroupDescriptor d = WGPU_BIND_GROUP_DESCRIPTOR_INIT;
    d.layout = g_layout;
    d.entryCount = 9;
    d.entries = e;
    g_group = wgpuDeviceCreateBindGroup(g_device, &d);
    if (g_fast) {
        if (g_fast_vgroup) wgpuBindGroupRelease(g_fast_vgroup);
        WGPUBindGroupEntry v[2] = {WGPU_BIND_GROUP_ENTRY_INIT, WGPU_BIND_GROUP_ENTRY_INIT};
        v[0].binding = 0;
        v[0].buffer = g_data;
        v[0].size = WGPU_WHOLE_SIZE;
        v[1].binding = 1;
        v[1].buffer = g_params;
        v[1].size = kParamStride;
        WGPUBindGroupDescriptor vd = WGPU_BIND_GROUP_DESCRIPTOR_INIT;
        vd.layout = g_fast_vlayout;
        vd.entryCount = 2;
        vd.entries = v;
        g_fast_vgroup = wgpuDeviceCreateBindGroup(g_device, &vd);
    }
}

void ensure_capacity() {
    bool changed = false;
    const std::uint64_t data_bytes = std::max<std::uint64_t>(g_arena.size() * 4, 16);
    if (data_bytes > g_data_size) {
        if (g_data) wgpuBufferRelease(g_data);
        g_data_size = std::max<std::uint64_t>(g_data_size * 2, (data_bytes + (4u << 20) - 1) & ~((4ull << 20) - 1));
        g_data = make_buffer(g_data_size, WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst);
        changed = true;
    }
    const std::uint64_t param_bytes = std::max<std::uint64_t>(g_param_records.size(), 1) * kParamStride;
    if (param_bytes > g_params_size) {
        if (g_params) wgpuBufferRelease(g_params);
        g_params_size = std::max<std::uint64_t>(g_params_size * 2, std::max<std::uint64_t>(param_bytes, 64 * 1024));
        g_params = make_buffer(g_params_size, WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst);
        changed = true;
    }
    if (changed || !g_group) rebuild_group();
}

WGPURenderPipeline fast_pipeline(std::uint32_t key) {
    const auto found = g_fast_pipes.find(key);
    if (found != g_fast_pipes.end()) return found->second;
    const std::uint32_t variant = key & 31u, ztst = (key >> 5) & 3u;
    const bool fix = variant >= 16;
    const WGPUBlendFactor f = fix ? WGPUBlendFactor_Constant : WGPUBlendFactor_Src1Alpha;
    const WGPUBlendFactor nf = fix ? WGPUBlendFactor_OneMinusConstant : WGPUBlendFactor_OneMinusSrc1Alpha;
    WGPUBlendState blend = WGPU_BLEND_STATE_INIT;
    blend.alpha.operation = WGPUBlendOperation_Add;
    blend.alpha.srcFactor = WGPUBlendFactor_One;
    blend.alpha.dstFactor = WGPUBlendFactor_Zero;
    WGPUBlendComponent &c = blend.color;
    c.operation = WGPUBlendOperation_Add;
    switch (variant & 15u) {
    case 1: c.srcFactor = f; c.dstFactor = nf; break;
    case 2: c.srcFactor = f; c.dstFactor = WGPUBlendFactor_One; break;
    case 3: c.srcFactor = f; c.dstFactor = WGPUBlendFactor_Zero; break;
    case 4: c.operation = WGPUBlendOperation_ReverseSubtract; c.srcFactor = f; c.dstFactor = WGPUBlendFactor_One; break;
    case 5: c.srcFactor = nf; c.dstFactor = f; break;
    case 6: c.srcFactor = WGPUBlendFactor_One; c.dstFactor = f; break;
    case 7: c.srcFactor = WGPUBlendFactor_Zero; c.dstFactor = f; break;
    case 8: c.srcFactor = WGPUBlendFactor_Zero; c.dstFactor = WGPUBlendFactor_One;
            blend.alpha.srcFactor = WGPUBlendFactor_Zero; blend.alpha.dstFactor = WGPUBlendFactor_One; break;
    case 9: c.srcFactor = WGPUBlendFactor_Zero; c.dstFactor = WGPUBlendFactor_Zero; break;
    default: c.srcFactor = WGPUBlendFactor_One; c.dstFactor = WGPUBlendFactor_Zero; break;
    }
    WGPUColorTargetState target = WGPU_COLOR_TARGET_STATE_INIT;
    target.format = WGPUTextureFormat_RGBA8Unorm;
    target.blend = &blend;
    const std::uint32_t keep = (key >> 8) & 15u;
    target.writeMask = (keep & 1u ? 0 : WGPUColorWriteMask_Red) | (keep & 2u ? 0 : WGPUColorWriteMask_Green) | (keep & 4u ? 0 : WGPUColorWriteMask_Blue) |
                       (keep & 8u ? 0 : WGPUColorWriteMask_Alpha);
    WGPUConstantEntry constants[4] = {WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT};
    constants[0].key = view("SX");
    constants[0].value = static_cast<double>(g_sx);
    constants[1].key = view("SY");
    constants[1].value = static_cast<double>(g_sy);
    constants[2].key = view("PIXEL_CACHE");
    constants[2].value = 0.0;
    constants[3].key = view("EXP");
    constants[3].value = 0.0;
    WGPUFragmentState fs = WGPU_FRAGMENT_STATE_INIT;
    fs.module = g_fast_module;
    fs.entryPoint = view("fast_fs");
    fs.constantCount = 4;
    fs.constants = constants;
    fs.targetCount = 1;
    fs.targets = &target;
    WGPURenderPipelineDescriptor rd = WGPU_RENDER_PIPELINE_DESCRIPTOR_INIT;
    rd.layout = g_fast_render_layout;
    rd.vertex.module = g_fast_module;
    rd.vertex.entryPoint = view("fast_vs");
    rd.vertex.constantCount = 2;
    rd.vertex.constants = constants;
    rd.primitive.topology = WGPUPrimitiveTopology_TriangleList;
    rd.primitive.cullMode = WGPUCullMode_None;
    rd.fragment = &fs;
    WGPUDepthStencilState ds = WGPU_DEPTH_STENCIL_STATE_INIT;
    ds.format = WGPUTextureFormat_Depth32Float;
    ds.depthWriteEnabled = (key & 128u) ? WGPUOptionalBool_True : WGPUOptionalBool_False;
    const WGPUCompareFunction tests[4] = {WGPUCompareFunction_Never, WGPUCompareFunction_Always, WGPUCompareFunction_GreaterEqual, WGPUCompareFunction_Greater};
    ds.depthCompare = tests[ztst];
    rd.depthStencil = &ds;
    WGPURenderPipeline pipe = wgpuDeviceCreateRenderPipeline(g_device, &rd);
    g_fast_pipes[key] = pipe;
    return pipe;
}

void encode_fast_draw(WGPUCommandEncoder enc, std::uint32_t index, const WGPUPassTimestampWrites *ts) {
    const FastBatch &fb = g_fast_batches[index];
    WGPURenderPassColorAttachment color = WGPU_RENDER_PASS_COLOR_ATTACHMENT_INIT;
    color.view = g_fast_view;
    color.loadOp = WGPULoadOp_Load;
    color.storeOp = WGPUStoreOp_Store;
    WGPURenderPassDepthStencilAttachment depth = WGPU_RENDER_PASS_DEPTH_STENCIL_ATTACHMENT_INIT;
    depth.view = g_fast_dview;
    depth.depthLoadOp = WGPULoadOp_Load;
    depth.depthStoreOp = WGPUStoreOp_Store;
    depth.depthClearValue = 0.0f;
    WGPURenderPassDescriptor rd = WGPU_RENDER_PASS_DESCRIPTOR_INIT;
    rd.colorAttachmentCount = 1;
    rd.colorAttachments = &color;
    rd.depthStencilAttachment = &depth;
    if (ts) rd.timestampWrites = ts;
    WGPURenderPassEncoder rp = wgpuCommandEncoderBeginRenderPass(enc, &rd);
    const std::uint32_t offset = fb.param * kParamStride;
    wgpuRenderPassEncoderSetBindGroup(rp, 0, g_group, 1, &offset);
    wgpuRenderPassEncoderSetBindGroup(rp, 1, g_fast_vgroup, 1, &offset);
    if (!fb.zloads.empty() && g_fast_zload) {
        wgpuRenderPassEncoderSetPipeline(rp, g_fast_zload);
        for (const std::uint32_t z : fb.zloads) {
            const std::uint32_t zo = z * kParamStride;
            wgpuRenderPassEncoderSetBindGroup(rp, 0, g_group, 1, &zo);
            wgpuRenderPassEncoderSetBindGroup(rp, 1, g_fast_vgroup, 1, &zo);
            wgpuRenderPassEncoderDraw(rp, 6, 1, 0, 0);
        }
        wgpuRenderPassEncoderSetBindGroup(rp, 0, g_group, 1, &offset);
        wgpuRenderPassEncoderSetBindGroup(rp, 1, g_fast_vgroup, 1, &offset);
    }
    for (const FastDraw &d : fb.draws) {
        WGPURenderPipeline pipe = fast_pipeline(d.variant);
        if (!pipe) continue;
        wgpuRenderPassEncoderSetPipeline(rp, pipe);
        if (d.variant & 16u) {
            const WGPUColor k{d.fix, d.fix, d.fix, d.fix};
            wgpuRenderPassEncoderSetBlendConstant(rp, &k);
        }
        wgpuRenderPassEncoderDraw(rp, d.count * 6, 1, d.first * 6, 0);
    }
    wgpuRenderPassEncoderEnd(rp);
    wgpuRenderPassEncoderRelease(rp);
}

WGPUComputePipeline compute_pipeline(Pipeline p) {
    return p == kFastLoad ? g_fast_load : p == kFastStore ? g_fast_store : p == kFastZStore ? g_fast_zstore : g_pipelines[p];
}

void bind_fast_texture(WGPUComputePassEncoder pass, Pipeline p) {
    if (p == kFastLoad) wgpuComputePassEncoderSetBindGroup(pass, 1, g_fast_wgroup, 0, nullptr);
    else if (p == kFastStore) wgpuComputePassEncoderSetBindGroup(pass, 1, g_fast_rgroup, 0, nullptr);
    else if (p == kFastZStore) wgpuComputePassEncoderSetBindGroup(pass, 1, g_fast_zgroup, 0, nullptr);
}

void profile_submit() {
    constexpr std::uint32_t kMax = 2048;
    if (!g_profile_queries) {
        WGPUQuerySetDescriptor qd = WGPU_QUERY_SET_DESCRIPTOR_INIT;
        qd.type = WGPUQueryType_Timestamp;
        qd.count = kMax * 2;
        g_profile_queries = wgpuDeviceCreateQuerySet(g_device, &qd);
        g_profile_resolve = make_buffer(kMax * 16, WGPUBufferUsage_QueryResolve | WGPUBufferUsage_CopySrc);
        g_profile_read = make_buffer(kMax * 16, WGPUBufferUsage_MapRead | WGPUBufferUsage_CopyDst);
    }
    ensure_capacity();
    wgpuQueueWriteBuffer(g_queue, g_data, 0, g_arena.data(), g_arena.size() * 4);
    wgpuQueueWriteBuffer(g_queue, g_params, 0, g_param_records.data(), g_param_records.size() * kParamStride);
    WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(g_device, nullptr);
    const std::uint32_t n = static_cast<std::uint32_t>(std::min<std::size_t>(g_commands.size(), kMax));
    for (std::uint32_t i = 0; i < g_commands.size(); ++i) {
        const Command &c = g_commands[i];
        WGPUPassTimestampWrites writes = WGPU_PASS_TIMESTAMP_WRITES_INIT;
        writes.querySet = g_profile_queries;
        writes.beginningOfPassWriteIndex = i * 2;
        writes.endOfPassWriteIndex = i * 2 + 1;
        if (c.pipeline == kFastDraw) {
            encode_fast_draw(enc, c.param, i < n ? &writes : nullptr);
            continue;
        }
        WGPUComputePassDescriptor cd = WGPU_COMPUTE_PASS_DESCRIPTOR_INIT;
        if (i < n) cd.timestampWrites = &writes;
        WGPUComputePassEncoder pass = wgpuCommandEncoderBeginComputePass(enc, &cd);
        wgpuComputePassEncoderSetPipeline(pass, compute_pipeline(c.pipeline));
        const std::uint32_t offset = c.param * kParamStride;
        wgpuComputePassEncoderSetBindGroup(pass, 0, g_group, 1, &offset);
        bind_fast_texture(pass, c.pipeline);
        wgpuComputePassEncoderDispatchWorkgroups(pass, c.x, c.y, 1);
        wgpuComputePassEncoderEnd(pass);
        wgpuComputePassEncoderRelease(pass);
    }
    if (n) {
        wgpuCommandEncoderResolveQuerySet(enc, g_profile_queries, 0, n * 2, g_profile_resolve, 0);
        wgpuCommandEncoderCopyBufferToBuffer(enc, g_profile_resolve, 0, g_profile_read, 0, n * 16);
    }
    WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
    wgpuQueueSubmit(g_queue, 1, &cmd);
    wgpuCommandBufferRelease(cmd);
    wgpuCommandEncoderRelease(enc);
    if (n) {
        bool done = false;
        WGPUBufferMapCallbackInfo cb = WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
        cb.mode = WGPUCallbackMode_AllowProcessEvents;
        cb.callback = [](WGPUMapAsyncStatus, WGPUStringView, void *flag, void *) { *static_cast<bool *>(flag) = true; };
        cb.userdata1 = &done;
        wgpuBufferMapAsync(g_profile_read, WGPUMapMode_Read, 0, n * 16, cb);
        wait_until(done);
        const auto *t = static_cast<const std::uint64_t *>(wgpuBufferGetConstMappedRange(g_profile_read, 0, n * 16));
        std::size_t info = 0;
        for (std::uint32_t i = 0; t && i < n; ++i) {
            while (info < g_command_info.size() && g_command_info[info].index < i) ++info;
            std::fprintf(g_profile_out, "%llu %u %s %llu %u %u", static_cast<unsigned long long>(frame_count()), i, g_commands[i].pipeline < kPipelines ? kEntryPoints[g_commands[i].pipeline] : g_commands[i].pipeline == kFastLoad ? "fast_load" : g_commands[i].pipeline == kFastStore ? "fast_store" : g_commands[i].pipeline == kFastZStore ? "fast_zstore" : "fast_draw",
                         static_cast<unsigned long long>(t[i * 2 + 1] > t[i * 2] ? t[i * 2 + 1] - t[i * 2] : 0), g_commands[i].x, g_commands[i].y);
            if (info < g_command_info.size() && g_command_info[info].index == i)
                for (std::uint32_t v : g_command_info[info].values) std::fprintf(g_profile_out, " %u", v);
            std::fprintf(g_profile_out, "\n");
        }
        wgpuBufferUnmap(g_profile_read);
        std::fflush(g_profile_out);
    }
    g_commands.clear();
    g_command_info.clear();
    g_fast_batches.clear();
    ++g_serial;
    g_param_records.clear();
    g_arena.clear();
    if (!g_decode_many_on.load(std::memory_order_relaxed)) decode_reset();   // A/B: the old per-submit decode
    g_clut_loads = 0;
}

// Browsers copy writes above about 1 MiB through a slower path, so large uploads go in pieces.
void submit(WGPUTextureView present_view = nullptr) {
    CpuTimer cpu_timer(2);
    res_flush();
    if (g_commands.empty() && !present_view) return;
    if (g_profile_out && !present_view && g_timestamps && frame_count() >= g_profile_from && frame_count() < g_profile_to) {
        profile_submit();
        return;
    }
    ensure_capacity();
    wgpuQueueWriteBuffer(g_queue, g_data, 0, g_arena.data(), g_arena.size() * 4);
    wgpuQueueWriteBuffer(g_queue, g_params, 0, g_param_records.data(), g_param_records.size() * kParamStride);
    if (g_query_ready) {
        const void *mapped = wgpuBufferGetConstMappedRange(g_query_read, 0, 16);
        if (mapped) {
            std::uint64_t t[2];
            std::memcpy(t, mapped, sizeof t);
            if (t[1] > t[0]) {
                g_measured_ns += t[1] - t[0];
                ++g_measured;
            }
        }
        wgpuBufferUnmap(g_query_read);
        g_query_ready = g_query_pending = false;
    }
    const bool measure = g_timestamps && !g_query_pending;
    WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(g_device, nullptr);
    WGPUPassTimestampWrites writes = WGPU_PASS_TIMESTAMP_WRITES_INIT;
    writes.querySet = g_queries;
    writes.beginningOfPassWriteIndex = 0;
    writes.endOfPassWriteIndex = 1;   // first compute pass only (fast-lane render passes split it); used for the load estimate
    WGPUComputePassDescriptor cd = WGPU_COMPUTE_PASS_DESCRIPTOR_INIT;
    if (measure) cd.timestampWrites = &writes;
    WGPUComputePassEncoder pass = wgpuCommandEncoderBeginComputePass(enc, &cd);
    Pipeline current = kNoPipeline;
    ++g_submits;
    ++g_total_passes;
    for (const Command &c : g_commands) {
        if (c.pipeline == kFastDraw) {
            // the fast lane's draws are a render pass: close the compute pass around it
            wgpuComputePassEncoderEnd(pass);
            wgpuComputePassEncoderRelease(pass);
            encode_fast_draw(enc, c.param, nullptr);
            WGPUComputePassDescriptor next = WGPU_COMPUTE_PASS_DESCRIPTOR_INIT;
            pass = wgpuCommandEncoderBeginComputePass(enc, &next);
            current = kNoPipeline;
            continue;
        }
        if (c.pipeline < kPipelines) ++g_dispatches[c.pipeline];
        if (c.pipeline != current) {
            wgpuComputePassEncoderSetPipeline(pass, compute_pipeline(c.pipeline));
            current = c.pipeline;
        }
        const std::uint32_t offset = c.param * kParamStride;
        wgpuComputePassEncoderSetBindGroup(pass, 0, g_group, 1, &offset);
        bind_fast_texture(pass, c.pipeline);
        wgpuComputePassEncoderDispatchWorkgroups(pass, c.x, c.y, 1);
    }
    wgpuComputePassEncoderEnd(pass);
    wgpuComputePassEncoderRelease(pass);
    if (measure) {
        wgpuCommandEncoderResolveQuerySet(enc, g_queries, 0, 2, g_query_resolve, 0);
        wgpuCommandEncoderCopyBufferToBuffer(enc, g_query_resolve, 0, g_query_read, 0, 16);
    }
    if (present_view) {
        WGPURenderPassColorAttachment color = WGPU_RENDER_PASS_COLOR_ATTACHMENT_INIT;
        color.view = present_view;
        color.loadOp = WGPULoadOp_Clear;
        color.storeOp = WGPUStoreOp_Store;
        color.clearValue = WGPUColor{0.0, 0.0, 0.0, 1.0};
        WGPURenderPassDescriptor rd = WGPU_RENDER_PASS_DESCRIPTOR_INIT;
        rd.colorAttachmentCount = 1;
        rd.colorAttachments = &color;
        WGPURenderPassEncoder rp = wgpuCommandEncoderBeginRenderPass(enc, &rd);
        const float w = static_cast<float>(g_surface_width), h = static_cast<float>(g_surface_height);
        const float aspect = g_present_aspect > 0.0f ? g_present_aspect : g_options.aspect;
        const float vw = std::min(w, h * aspect), vh = vw / aspect;
        wgpuRenderPassEncoderSetViewport(rp, (w - vw) * 0.5f, (h - vh) * 0.5f, vw, vh, 0.0f, 1.0f);
        wgpuRenderPassEncoderSetPipeline(rp, g_blit);
        wgpuRenderPassEncoderSetBindGroup(rp, 0, g_blit_group, 0, nullptr);
        wgpuRenderPassEncoderDraw(rp, 3, 1, 0, 0);
        wgpuRenderPassEncoderEnd(rp);
        wgpuRenderPassEncoderRelease(rp);
    }
    WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
    wgpuQueueSubmit(g_queue, 1, &cmd);
    wgpuCommandBufferRelease(cmd);
    wgpuCommandEncoderRelease(enc);
    if (measure) {
        g_query_pending = true;
        WGPUBufferMapCallbackInfo cb = WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
        cb.mode = WGPUCallbackMode_AllowProcessEvents;
        cb.callback = [](WGPUMapAsyncStatus status, WGPUStringView, void *, void *) {
            if (status == WGPUMapAsyncStatus_Success) g_query_ready = true;
            else g_query_pending = false;
        };
        wgpuBufferMapAsync(g_query_read, WGPUMapMode_Read, 0, 16, cb);
    }
#ifdef __EMSCRIPTEN__
    wgpuInstanceProcessEvents(g_instance);
#else
    wgpuDevicePoll(g_device, false, nullptr);
#endif
    g_commands.clear();
    g_command_info.clear();
    g_fast_batches.clear();
    ++g_serial;
    g_param_records.clear();
    g_arena.clear();
    if (!g_decode_many_on.load(std::memory_order_relaxed)) decode_reset();   // A/B: the old per-submit decode
    g_clut_loads = 0;
}

void read_back(WGPUBuffer source, std::uint64_t bytes, void *out, std::uint64_t offset = 0) {
    WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(g_device, nullptr);
    wgpuCommandEncoderCopyBufferToBuffer(enc, source, offset, g_readback, 0, bytes);
    WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
    wgpuQueueSubmit(g_queue, 1, &cmd);
    wgpuCommandBufferRelease(cmd);
    wgpuCommandEncoderRelease(enc);
    bool done = false;
    WGPUBufferMapCallbackInfo cb = WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
    cb.mode = WGPUCallbackMode_AllowProcessEvents;
    cb.callback = [](WGPUMapAsyncStatus status, WGPUStringView, void *flag, void *) {
        if (status != WGPUMapAsyncStatus_Success) std::fprintf(stderr, "[gpu] map failed %d\n", static_cast<int>(status));
        *static_cast<bool *>(flag) = true;
    };
    cb.userdata1 = &done;
    wgpuBufferMapAsync(g_readback, WGPUMapMode_Read, 0, bytes, cb);
    wait_until(done);
    const void *mapped = wgpuBufferGetConstMappedRange(g_readback, 0, bytes);
    if (mapped) std::memcpy(out, mapped, bytes);
    wgpuBufferUnmap(g_readback);
}

std::uint32_t make_setup(const State &st, std::uint64_t attr, std::uint32_t *w) {
    const Context &c = st.ctx[(attr >> 9) & 1u];
    std::uint32_t flags = 0;
    if (attr & 0x8u) flags |= 1u;
    if (attr & 0x10u) flags |= 2u;
    if (attr & 0x20u) flags |= 4u;
    if (attr & 0x40u) flags |= 8u;
    if (attr & 0x100u) flags |= 16u;
    if ((c.zbuf >> 32) & 1u) flags |= 32u;
    if (c.test & 1u) flags |= 64u;
    if ((c.test >> 14) & 1u) flags |= 128u;
    if ((c.test >> 15) & 1u) flags |= 256u;
    if ((c.test >> 16) & 1u) flags |= 512u;
    if (st.pabe & 1u) flags |= 1024u;
    if (st.colclamp & 1u) flags |= 2048u;
    if (c.fba & 1u) flags |= 4096u;
    if ((c.tex0 >> 34) & 1u) flags |= 8192u;
    if ((c.tex1 >> 5) & 1u) flags |= 16384u;
    if ((st.texa >> 15) & 1u) flags |= 32768u;
    const std::uint32_t zpsm = 0x30u | (static_cast<std::uint32_t>(c.zbuf >> 24) & 0xFu);
    w[0] = flags;
    w[1] = (static_cast<std::uint32_t>(c.frame) & 0x1FFu) * 32u;
    w[2] = static_cast<std::uint32_t>(c.frame >> 16) & 0x3Fu;
    w[3] = static_cast<std::uint32_t>(c.frame >> 24) & 0x3Fu;
    w[4] = static_cast<std::uint32_t>(c.frame >> 32);
    w[5] = (static_cast<std::uint32_t>(c.zbuf) & 0x1FFu) * 32u;
    w[6] = zpsm;
    w[7] = (static_cast<std::uint32_t>(c.test >> 1) & 7u) | ((static_cast<std::uint32_t>(c.test >> 12) & 3u) << 4) |
           ((static_cast<std::uint32_t>(c.test >> 17) & 3u) << 8) | ((static_cast<std::uint32_t>(c.alpha) & 0xFFu) << 12) |
           ((static_cast<std::uint32_t>(c.tex0 >> 35) & 3u) << 20) | ((static_cast<std::uint32_t>(c.clamp) & 0xFu) << 24) |
           ((static_cast<std::uint32_t>(st.scanmsk) & 3u) << 28);
    w[8] = static_cast<std::uint32_t>(c.test >> 4) & 0xFFu;
    w[9] = static_cast<std::uint32_t>(c.alpha >> 32) & 0xFFu;
    w[10] = (static_cast<std::uint32_t>(c.scissor) & 0x7FFu) | ((static_cast<std::uint32_t>(c.scissor >> 16) & 0x7FFu) << 16);
    w[11] = (static_cast<std::uint32_t>(c.scissor >> 32) & 0x7FFu) | ((static_cast<std::uint32_t>(c.scissor >> 48) & 0x7FFu) << 16);
    w[12] = static_cast<std::uint32_t>(c.tex0) & 0x3FFFu;
    w[13] = static_cast<std::uint32_t>(c.tex0 >> 14) & 0x3Fu;
    w[14] = static_cast<std::uint32_t>(c.tex0 >> 20) & 0x3Fu;
    w[15] = std::min<std::uint32_t>(static_cast<std::uint32_t>(c.tex0 >> 26) & 0xFu, 10u) | (std::min<std::uint32_t>(static_cast<std::uint32_t>(c.tex0 >> 30) & 0xFu, 10u) << 8);
    w[16] = static_cast<std::uint32_t>(c.tex0 >> 51) & 0xFu;
    w[17] = static_cast<std::uint32_t>(c.tex0 >> 56) & 0x1Fu;
    w[18] = (static_cast<std::uint32_t>(c.clamp >> 4) & 0x3FFu) | ((static_cast<std::uint32_t>(c.clamp >> 14) & 0x3FFu) << 16);
    w[19] = (static_cast<std::uint32_t>(c.clamp >> 24) & 0x3FFu) | ((static_cast<std::uint32_t>(c.clamp >> 34) & 0x3FFu) << 16);
    w[20] = (static_cast<std::uint32_t>(st.texa) & 0xFFu) | ((static_cast<std::uint32_t>(st.texa >> 32) & 0xFFu) << 8);
    w[21] = static_cast<std::uint32_t>(st.fogcol) & 0xFFFFFFu;
    w[22] = g_clut_slot;
    w[23] = z_max(zpsm);
    w[24] = 0xFFFFFFFFu;
    w[25] = 0xFFFFFFFFu;
    w[26] = 0;
    if ((flags & 2u) && g_hd_words) {
        std::uint32_t offset = 0, shift = 0;
        if (hd_lookup(st, c, offset, shift)) {
            w[25] = offset;
            w[26] = shift;
        }
    }
    return flags;
}

bool texel_rect(const std::uint32_t *setup, const Vertex *v, int count, std::uint32_t prim, bool fst, int rect[4]) {
    const int tw = 1 << (setup[15] & 0xFFu), th = 1 << (setup[15] >> 8);
    float u0 = 1e30f, v0 = 1e30f, u1 = -1e30f, v1 = -1e30f;
    for (int i = 0; i < count; ++i) {
        float u, t;
        if (fst) {
            u = static_cast<float>(v[i].u) / 16.0f;
            t = static_cast<float>(v[i].v) / 16.0f;
        } else {
            const float q = prim == 6 ? v[count - 1].q : v[i].q;
            if (!(q > 0.0f) || !(v[0].q > 0.0f) || !(v[count - 1].q > 0.0f)) return false;
            u = v[i].s / q * static_cast<float>(tw);
            t = v[i].t / q * static_cast<float>(th);
        }
        if (!std::isfinite(u) || !std::isfinite(t)) return false;
        u0 = std::min(u0, u);
        u1 = std::max(u1, u);
        v0 = std::min(v0, t);
        v1 = std::max(v1, t);
    }
    const auto axis = [](std::uint32_t mode, float lo, float hi, int size, std::uint32_t clamp, int &a, int &b) {
        a = static_cast<int>(std::floor(lo)) - 1;
        b = static_cast<int>(std::ceil(hi)) + 1;
        switch (mode) {
        case 0:
            if (a < 0 || b >= size) {
                a = 0;
                b = size - 1;
            }
            return true;
        case 1:
            a = std::clamp(a, 0, size - 1);
            b = std::clamp(b, 0, size - 1);
            return true;
        case 2: {
            const int minv = static_cast<int>(clamp & 0x3FFu), maxv = static_cast<int>(clamp >> 16);
            a = std::clamp(a, minv, std::max(minv, maxv));
            b = std::clamp(b, minv, std::max(minv, maxv));
            return true;
        }
        default: return false;
        }
    };
    int ua, ub, va, vb;
    if (!axis((setup[7] >> 24) & 3u, u0, u1, tw, setup[18], ua, ub) || !axis((setup[7] >> 26) & 3u, v0, v1, th, setup[19], va, vb)) return false;
    rect[0] = std::max(ua, 0);
    rect[1] = std::max(va, 0);
    rect[2] = std::max(ub, 0);
    rect[3] = std::max(vb, 0);
    return true;
}

bool shares_frame(const std::uint32_t *setup, const Batch &b) {
    const auto wide = [](std::uint32_t psm) { return psm == PSMCT32 || psm == PSMCT24 || psm == PSMT8H || psm == PSMT4HL || psm == PSMT4HH; };
    return setup[12] == b.fbp && setup[13] == b.fbw && (setup[14] == b.fpsm || (wide(setup[14]) && wide(b.fpsm)));
}

bool drawn_under(const Batch &b, const int rect[4]) {
    const auto hits = [&](int x0, int y0, int x1, int y1) { return rect[0] <= x1 && x0 <= rect[2] && rect[1] <= y1 && y0 <= rect[3]; };
    const std::size_t prims = b.boxes.size() / 2;
    if (prims > 64) return hits(b.minx, b.miny, b.maxx, b.maxy);
    for (std::size_t i = 0; i < prims; ++i) {
        const std::uint32_t lo = b.boxes[i * 2], hi = b.boxes[i * 2 + 1];
        if (hits(static_cast<int>(lo & 0xFFFFu), static_cast<int>(lo >> 16), static_cast<int>(hi & 0xFFFFu), static_cast<int>(hi >> 16))) return true;
    }
    return false;
}

void attrs(std::uint32_t *rec, int n, const Vertex &v, bool fst, const Vertex *color) {
    const Vertex &c = color ? *color : v;
    rec[12 + n] = c.r | (static_cast<std::uint32_t>(c.g) << 8) | (static_cast<std::uint32_t>(c.b) << 16) | (static_cast<std::uint32_t>(c.a) << 24);
    rec[15 + n * 3] = f2u(fst ? static_cast<float>(v.u) : v.s);
    rec[16 + n * 3] = f2u(fst ? static_cast<float>(v.v) : v.t);
    rec[17 + n * 3] = f2u(fst ? 1.0f : v.q);
    rec[11] |= static_cast<std::uint32_t>(v.f) << (8 * n);
}

}

Mode mode() { return g_mode; }

// fast lane setup (render target, layouts, the module with fast.wgsl appended); false leaves it off
bool init_fast() {
    WGPULimits limits = WGPU_LIMITS_INIT;
    wgpuDeviceGetLimits(g_device, &limits);
    const std::uint32_t max_dim = std::max<std::uint32_t>(limits.maxTextureDimension2D, 2048);
    g_fast_w = std::min<std::uint32_t>(1024 * g_sx, max_dim);
    g_fast_h = std::min<std::uint32_t>(1024 * g_sy, max_dim);
    if (static_cast<std::uint64_t>(g_fast_w) * g_fast_h * 4 > (512ull << 20)) return false;
    WGPUTextureDescriptor td = WGPU_TEXTURE_DESCRIPTOR_INIT;
    td.size = {g_fast_w, g_fast_h, 1};
    td.format = WGPUTextureFormat_RGBA8Unorm;
    td.usage = WGPUTextureUsage_StorageBinding | WGPUTextureUsage_TextureBinding | WGPUTextureUsage_RenderAttachment;
    g_fast_rt = wgpuDeviceCreateTexture(g_device, &td);
    if (!g_fast_rt) return false;
    g_fast_view = wgpuTextureCreateView(g_fast_rt, nullptr);
    td.format = WGPUTextureFormat_Depth32Float;
    td.usage = WGPUTextureUsage_TextureBinding | WGPUTextureUsage_RenderAttachment;
    g_fast_depth = wgpuDeviceCreateTexture(g_device, &td);
    if (!g_fast_depth) return false;
    g_fast_dview = wgpuTextureCreateView(g_fast_depth, nullptr);

    WGPUBindGroupLayoutEntry ve[2] = {WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT, WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT};
    ve[0].binding = 0;
    ve[0].visibility = WGPUShaderStage_Vertex;
    ve[0].buffer.type = WGPUBufferBindingType_ReadOnlyStorage;
    ve[1].binding = 1;
    ve[1].visibility = WGPUShaderStage_Vertex;
    ve[1].buffer.type = WGPUBufferBindingType_Uniform;
    ve[1].buffer.hasDynamicOffset = true;
    ve[1].buffer.minBindingSize = kParamStride;
    WGPUBindGroupLayoutDescriptor ld = WGPU_BIND_GROUP_LAYOUT_DESCRIPTOR_INIT;
    ld.entryCount = 2;
    ld.entries = ve;
    g_fast_vlayout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    WGPUBindGroupLayoutEntry we = WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT;
    we.binding = 0;
    we.visibility = WGPUShaderStage_Compute;
    we.storageTexture.access = WGPUStorageTextureAccess_WriteOnly;
    we.storageTexture.format = WGPUTextureFormat_RGBA8Unorm;
    we.storageTexture.viewDimension = WGPUTextureViewDimension_2D;
    ld.entryCount = 1;
    ld.entries = &we;
    g_fast_wlayout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    WGPUBindGroupLayoutEntry re = WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT;
    re.binding = 0;
    re.visibility = WGPUShaderStage_Compute;
    re.texture.sampleType = WGPUTextureSampleType_UnfilterableFloat;
    re.texture.viewDimension = WGPUTextureViewDimension_2D;
    ld.entries = &re;
    g_fast_rlayout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    WGPUBindGroupLayoutEntry de = WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT;
    de.binding = 0;
    de.visibility = WGPUShaderStage_Compute;
    de.texture.sampleType = WGPUTextureSampleType_Depth;
    de.texture.viewDimension = WGPUTextureViewDimension_2D;
    ld.entries = &de;
    g_fast_dlayout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    if (!g_fast_vlayout || !g_fast_wlayout || !g_fast_rlayout || !g_fast_dlayout) return false;

    WGPUBindGroupEntry ge = WGPU_BIND_GROUP_ENTRY_INIT;
    ge.binding = 0;
    ge.textureView = g_fast_view;
    WGPUBindGroupDescriptor gd = WGPU_BIND_GROUP_DESCRIPTOR_INIT;
    gd.entryCount = 1;
    gd.entries = &ge;
    gd.layout = g_fast_wlayout;
    g_fast_wgroup = wgpuDeviceCreateBindGroup(g_device, &gd);
    gd.layout = g_fast_rlayout;
    g_fast_rgroup = wgpuDeviceCreateBindGroup(g_device, &gd);
    ge.textureView = g_fast_dview;
    gd.layout = g_fast_dlayout;
    g_fast_zgroup = wgpuDeviceCreateBindGroup(g_device, &gd);

    const auto layout = [](WGPUBindGroupLayout second) {
        const WGPUBindGroupLayout both[2] = {g_layout, second};
        WGPUPipelineLayoutDescriptor pld = WGPU_PIPELINE_LAYOUT_DESCRIPTOR_INIT;
        pld.bindGroupLayoutCount = 2;
        pld.bindGroupLayouts = both;
        return wgpuDeviceCreatePipelineLayout(g_device, &pld);
    };
    g_fast_render_layout = layout(g_fast_vlayout);
    const WGPUPipelineLayout load_layout = layout(g_fast_wlayout), store_layout = layout(g_fast_rlayout), zstore_layout = layout(g_fast_dlayout);

    static std::string code;
    code = std::string("enable dual_source_blending;\n") + kGsShader + "\n" + kFastShader;
    WGPUShaderSourceWGSL source = WGPU_SHADER_SOURCE_WGSL_INIT;
    source.code = view(code.c_str());
    WGPUShaderModuleDescriptor md = WGPU_SHADER_MODULE_DESCRIPTOR_INIT;
    md.nextInChain = &source.chain;
    g_fast_module = wgpuDeviceCreateShaderModule(g_device, &md);
    if (!g_fast_module) return false;
    WGPUConstantEntry constants[2] = {WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT};
    constants[0].key = view("SX");
    constants[0].value = static_cast<double>(g_sx);
    constants[1].key = view("SY");
    constants[1].value = static_cast<double>(g_sy);
    WGPUComputePipelineDescriptor cd = WGPU_COMPUTE_PIPELINE_DESCRIPTOR_INIT;
    cd.compute.module = g_fast_module;
    cd.compute.constantCount = 2;
    cd.compute.constants = constants;
    cd.layout = load_layout;
    cd.compute.entryPoint = view("fast_load");
    g_fast_load = wgpuDeviceCreateComputePipeline(g_device, &cd);
    cd.layout = store_layout;
    cd.compute.entryPoint = view("fast_store");
    g_fast_store = wgpuDeviceCreateComputePipeline(g_device, &cd);
    cd.layout = zstore_layout;
    cd.compute.entryPoint = view("fast_zstore");
    g_fast_zstore = wgpuDeviceCreateComputePipeline(g_device, &cd);
    {
        // Z copy-in: a full-rectangle draw that writes depth only
        WGPUColorTargetState target = WGPU_COLOR_TARGET_STATE_INIT;
        target.format = WGPUTextureFormat_RGBA8Unorm;
        target.writeMask = WGPUColorWriteMask_None;
        WGPUFragmentState fs = WGPU_FRAGMENT_STATE_INIT;
        fs.module = g_fast_module;
        fs.entryPoint = view("fast_zload");
        fs.constantCount = 2;
        fs.constants = constants;
        fs.targetCount = 1;
        fs.targets = &target;
        WGPUDepthStencilState ds = WGPU_DEPTH_STENCIL_STATE_INIT;
        ds.format = WGPUTextureFormat_Depth32Float;
        ds.depthWriteEnabled = WGPUOptionalBool_True;
        ds.depthCompare = WGPUCompareFunction_Always;
        WGPURenderPipelineDescriptor rd = WGPU_RENDER_PIPELINE_DESCRIPTOR_INIT;
        rd.layout = g_fast_render_layout;
        rd.vertex.module = g_fast_module;
        rd.vertex.entryPoint = view("fast_vs_full");
        rd.vertex.constantCount = 2;
        rd.vertex.constants = constants;
        rd.primitive.topology = WGPUPrimitiveTopology_TriangleList;
        rd.fragment = &fs;
        rd.depthStencil = &ds;
        g_fast_zload = wgpuDeviceCreateRenderPipeline(g_device, &rd);
    }
    return g_fast_load && g_fast_store && g_fast_zstore && g_fast_zload && fast_pipeline(1 | (1u << 5));
}

bool init(Mode m) {
    if (m == Mode::off) return false;
#ifdef __EMSCRIPTEN__
    g_instance = wgpuCreateInstance(nullptr);
#else
    WGPUInstanceExtras extras = {};
    extras.chain.sType = static_cast<WGPUSType>(WGPUSType_InstanceExtras);
    extras.backends = WGPUInstanceBackend_Primary;
    WGPUInstanceDescriptor id = WGPU_INSTANCE_DESCRIPTOR_INIT;
    id.nextInChain = &extras.chain;
    g_instance = wgpuCreateInstance(&id);
#endif
    if (!g_instance) return false;
    WGPUAdapter adapter = nullptr;
    bool adapter_done = false;
    WGPURequestAdapterOptions options = WGPU_REQUEST_ADAPTER_OPTIONS_INIT;
    options.powerPreference = std::getenv("PS2_GPU_LOW_POWER") ? WGPUPowerPreference_LowPower : WGPUPowerPreference_HighPerformance;
    options.forceFallbackAdapter = std::getenv("PS2_GPU_FALLBACK") != nullptr;
    WGPURequestAdapterCallbackInfo acb = WGPU_REQUEST_ADAPTER_CALLBACK_INFO_INIT;
    acb.mode = WGPUCallbackMode_AllowSpontaneous;
    acb.callback = [](WGPURequestAdapterStatus status, WGPUAdapter a, WGPUStringView, void *out, void *done) {
        if (status == WGPURequestAdapterStatus_Success) *static_cast<WGPUAdapter *>(out) = a;
        *static_cast<bool *>(done) = true;
    };
    acb.userdata1 = &adapter;
    acb.userdata2 = &adapter_done;
    wgpuInstanceRequestAdapter(g_instance, &options, acb);
    while (!adapter_done) pump();
    if (!adapter) {
        std::fprintf(stderr, "[gpu] no adapter\n");
        return false;
    }
    WGPUAdapterInfo info = WGPU_ADAPTER_INFO_INIT;
    if (wgpuAdapterGetInfo(adapter, &info) == WGPUStatus_Success) {
        std::fprintf(stderr, "[gpu] %.*s (%.*s)\n", static_cast<int>(info.device.length), info.device.data, static_cast<int>(info.description.length), info.description.data);
        wgpuAdapterInfoFreeMembers(info);
    }
    WGPULimits supported = WGPU_LIMITS_INIT;
    wgpuAdapterGetLimits(adapter, &supported);
    WGPULimits limits = WGPU_LIMITS_INIT;
    limits.maxStorageBufferBindingSize = supported.maxStorageBufferBindingSize;
    g_max_binding = supported.maxStorageBufferBindingSize;
    limits.maxBufferSize = supported.maxBufferSize;
    limits.maxTextureDimension2D = supported.maxTextureDimension2D;
    WGPUDeviceDescriptor dd = WGPU_DEVICE_DESCRIPTOR_INIT;
    dd.requiredLimits = &limits;
    WGPUFeatureName features[4];
    std::size_t feature_count = 0;
    g_timestamps = wgpuAdapterHasFeature(adapter, WGPUFeatureName_TimestampQuery);
    if (g_timestamps) features[feature_count++] = WGPUFeatureName_TimestampQuery;
    // fast lane: needs dual-source blending (PS2 alpha / 128 as the blend factor) and 8 storage buffers in fragment shaders
    g_fast = !std::getenv("PS2_NO_FAST") && wgpuAdapterHasFeature(adapter, WGPUFeatureName_DualSourceBlending) && supported.maxStorageBuffersPerShaderStage >= 8;
    if (g_fast) features[feature_count++] = WGPUFeatureName_DualSourceBlending;
#ifdef PS2_PGS
    // PCSX2's renderer (lab switch) needs dual-source blending and a 32-bit float depth + stencil format
    if (std::getenv("PS2_PGS")) {
        if (!g_fast && wgpuAdapterHasFeature(adapter, WGPUFeatureName_DualSourceBlending)) features[feature_count++] = WGPUFeatureName_DualSourceBlending;
        if (wgpuAdapterHasFeature(adapter, WGPUFeatureName_Depth32FloatStencil8)) features[feature_count++] = WGPUFeatureName_Depth32FloatStencil8;
    }
#endif
    if (const char *work = std::getenv("PS2_FAST_MIN")) g_fast_min_work = std::strtoull(work, nullptr, 10);
    dd.requiredFeatureCount = feature_count;
    dd.requiredFeatures = features;
    dd.uncapturedErrorCallbackInfo.callback = on_error;
    bool device_done = false;
    WGPURequestDeviceCallbackInfo dcb = WGPU_REQUEST_DEVICE_CALLBACK_INFO_INIT;
    dcb.mode = WGPUCallbackMode_AllowSpontaneous;
    dcb.callback = [](WGPURequestDeviceStatus status, WGPUDevice d, WGPUStringView message, void *out, void *done) {
        if (status == WGPURequestDeviceStatus_Success) *static_cast<WGPUDevice *>(out) = d;
        else std::fprintf(stderr, "[gpu] device: %.*s\n", static_cast<int>(message.length), message.data);
        *static_cast<bool *>(done) = true;
    };
    dcb.userdata1 = &g_device;
    dcb.userdata2 = &device_done;
    wgpuAdapterRequestDevice(adapter, &dd, dcb);
    while (!device_done) pump();
    g_adapter = adapter;
    if (!g_device) return false;
    g_queue = wgpuDeviceGetQueue(g_device);

    if (const char *spec = std::getenv("PS2_GPU_PROFILE")) {
        char path[512] = {};
        unsigned long long a = 0, z = 0;
        if (std::sscanf(spec, "%llu,%llu,%511s", &a, &z, path) == 3) {
            g_profile_out = std::fopen(path, "w");
            g_profile_from = a;
            g_profile_to = z;
        }
    }
    if (const char *scale = std::getenv("PS2_SCALE")) g_scale = std::clamp<std::uint32_t>(static_cast<std::uint32_t>(std::atoi(scale)), 1u, 10u);
    // Up to 10x (8K). Every scaled buffer is kMemorySize * scale^2, so step down until the GPU can bind it.
    // the biggest one is the scratch buffer: (copy + 2 fields) = 2 * kMemorySize * scale^2
    // Widescreen: the game still draws a 640-wide picture, so give it extra samples sideways
    // (32:9 at 2x = 5x across, 2x down) instead of stretching a skinny frame. PS2_SCALE_X overrides.
    g_sy = g_scale;
    g_sx = g_scale;
    if (g_options.aspect > 1.34f && !std::getenv("PS2_NO_WIDE_SAMPLES"))
        g_sx = std::clamp<std::uint32_t>(static_cast<std::uint32_t>(std::lround(g_scale * g_options.aspect * 0.75f)), g_scale, 16u);
    if (const char *sx = std::getenv("PS2_SCALE_X")) g_sx = std::clamp<std::uint32_t>(static_cast<std::uint32_t>(std::atoi(sx)), 1u, 16u);
    // Every scaled buffer is kMemorySize * sx * sy; the biggest is scratch (copy + 2 fields) = 2x that.
    const auto fits = [] { return 2ull * kMemorySize * g_sx * g_sy <= std::min<std::uint64_t>(g_max_binding, 0xFFFFFFFCull); };
    while (!fits() && g_sx > g_sy) --g_sx;
    while (!fits() && g_sy > 1) { --g_sy; g_sx = std::max(g_sy, g_sx - 1); }
    while (!fits() && g_sx > 1) --g_sx;
    g_scale = g_sy;
    std::fprintf(stderr, "[gpu] render scale %ux%u (%ux%u for a 640x448 frame)\n", g_sx, g_sy, 640 * g_sx, 448 * g_sy);
    g_copy_words = (1u << 20) * g_sx * g_sy;
    g_tiles_per_row = (2048 * static_cast<int>(g_sx) + 15) / 16;
    g_tile_rows = (2048 * g_sy + 15) / 16;
    g_tile_count.assign(static_cast<std::size_t>(g_tiles_per_row) * g_tile_rows, 0);
    g_tile_fill.assign(static_cast<std::size_t>(g_tiles_per_row) * g_tile_rows, 0);
    g_field_words = (1u << 19) * g_sx * g_sy;
    g_vram = make_buffer(static_cast<std::uint64_t>(kMemorySize) * g_sx * g_sy, WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst);
    std::vector<std::uint32_t> tables;
    swizzle_tables(tables);
    g_tables = make_buffer(tables.size() * 4, WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst);
    wgpuQueueWriteBuffer(g_queue, g_tables, 0, tables.data(), tables.size() * 4);
    g_clut = make_buffer(static_cast<std::uint64_t>(kClutSlots) * kClutEntries * 4, WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc | WGPUBufferUsage_CopyDst);
    g_scratch = make_buffer((static_cast<std::uint64_t>(g_copy_words) + 2ull * g_field_words) * 4, WGPUBufferUsage_Storage | WGPUBufferUsage_CopySrc);
    g_cache = make_buffer(static_cast<std::uint64_t>(kCacheWords) * 4, WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst);
    g_decoded = make_buffer(static_cast<std::uint64_t>(kDecodedWords) * 4, WGPUBufferUsage_Storage);
    {
        // HD replacement textures (PS2_HD_MB megabytes, default 512, capped by the device's binding limit)
        std::uint64_t bytes = 16;
        if (const char *hd = std::getenv("PS2_HD_MB")) {
            bytes = static_cast<std::uint64_t>(std::max(0, std::atoi(hd))) << 20;
            bytes = std::min<std::uint64_t>(bytes, std::min<std::uint64_t>(g_max_binding, 0xFFFFFFFCull));
            bytes = std::max<std::uint64_t>(bytes & ~3ull, 16);
        }
        g_hd = make_buffer(bytes, WGPUBufferUsage_Storage | WGPUBufferUsage_CopyDst);
        g_hd_words = bytes > 16 ? static_cast<std::uint32_t>(bytes / 4) : 0;
        if (g_hd_words) std::fprintf(stderr, "[gpu] HD texture buffer %llu MB\n", static_cast<unsigned long long>(bytes >> 20));
    }
    if (const char *decode = std::getenv("PS2_DECODE")) g_decode = std::atoi(decode) != 0;
    g_cache_copy.assign(kCacheWords, 0);
    g_readback = make_buffer(static_cast<std::uint64_t>(g_copy_words) * 4, WGPUBufferUsage_MapRead | WGPUBufferUsage_CopyDst);
    if (g_timestamps) {
        WGPUQuerySetDescriptor qd = WGPU_QUERY_SET_DESCRIPTOR_INIT;
        qd.type = WGPUQueryType_Timestamp;
        qd.count = 2;
        g_queries = wgpuDeviceCreateQuerySet(g_device, &qd);
        g_query_resolve = make_buffer(16, WGPUBufferUsage_QueryResolve | WGPUBufferUsage_CopySrc);
        g_query_read = make_buffer(16, WGPUBufferUsage_MapRead | WGPUBufferUsage_CopyDst);
    }

    WGPUBindGroupLayoutEntry le[9] = {};
    const WGPUBufferBindingType types[9] = {WGPUBufferBindingType_Storage, WGPUBufferBindingType_ReadOnlyStorage, WGPUBufferBindingType_Uniform,
                                            WGPUBufferBindingType_ReadOnlyStorage, WGPUBufferBindingType_Storage, WGPUBufferBindingType_Storage,
                                            WGPUBufferBindingType_ReadOnlyStorage, WGPUBufferBindingType_Storage, WGPUBufferBindingType_ReadOnlyStorage};
    for (int i = 0; i < 9; ++i) {
        le[i] = WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT;
        le[i].binding = static_cast<std::uint32_t>(i);
        le[i].visibility = g_fast ? (WGPUShaderStage_Compute | WGPUShaderStage_Fragment) : WGPUShaderStage_Compute;
        le[i].buffer.type = types[i];
        le[i].buffer.hasDynamicOffset = i == 2;
        le[i].buffer.minBindingSize = i == 2 ? kParamStride : 0;
    }
    WGPUBindGroupLayoutDescriptor ld = WGPU_BIND_GROUP_LAYOUT_DESCRIPTOR_INIT;
    ld.entryCount = 9;
    ld.entries = le;
    g_layout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    WGPUPipelineLayoutDescriptor pld = WGPU_PIPELINE_LAYOUT_DESCRIPTOR_INIT;
    pld.bindGroupLayoutCount = 1;
    pld.bindGroupLayouts = &g_layout;
    g_pipeline_layout = wgpuDeviceCreatePipelineLayout(g_device, &pld);

    WGPUShaderSourceWGSL source = WGPU_SHADER_SOURCE_WGSL_INIT;
    source.code = view(kGsShader);
    WGPUShaderModuleDescriptor md = WGPU_SHADER_MODULE_DESCRIPTOR_INIT;
    md.nextInChain = &source.chain;
    WGPUShaderModule module = wgpuDeviceCreateShaderModule(g_device, &md);
    for (int i = 0; i < kPipelines; ++i) {
        WGPUComputePipelineDescriptor cd = WGPU_COMPUTE_PIPELINE_DESCRIPTOR_INIT;
        cd.layout = g_pipeline_layout;
        cd.compute.module = module;
        cd.compute.entryPoint = view(kEntryPoints[i]);
        WGPUConstantEntry constants[4] = {WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT, WGPU_CONSTANT_ENTRY_INIT};
        constants[0].key = view("SX");
        constants[0].value = static_cast<double>(g_sx);
        constants[1].key = view("SY");
        constants[1].value = static_cast<double>(g_sy);
        constants[2].key = view("PIXEL_CACHE");
        constants[2].value = std::getenv("PS2_NO_PIXEL_CACHE") ? 0.0 : 1.0;
        constants[3].key = view("EXP");
        constants[3].value = std::getenv("PS2_EXP") ? std::atof(std::getenv("PS2_EXP")) : 0.0;
        cd.compute.constantCount = 4;
        cd.compute.constants = constants;
        g_pipelines[i] = wgpuDeviceCreateComputePipeline(g_device, &cd);
        if (!g_pipelines[i]) return false;
    }
    wgpuShaderModuleRelease(module);
    if (g_fast) g_fast = init_fast();
    std::fprintf(stderr, "[gpu] fast lane %s\n", g_fast ? "on" : "off");
    ensure_capacity();
    g_mode = m;
    return true;
}

void draw(const State &st, const Vertex *v, int count) {
    if (g_image.active && !g_image.pending.empty()) flush_image();
    std::uint64_t attr = st.prim;
    if (!(st.prmodecont & 1u)) attr = (st.prim & 7u) | (st.prmode & ~7ull);
    const std::uint32_t prim = static_cast<std::uint32_t>(st.prim) & 7u;
    const Context &c = st.ctx[(attr >> 9) & 1u];
    SetupCache &cache = g_setup_cache;
    if (cache.generation != g_setup_generation || cache.attr != attr || cache.clut != g_clut_slot) {
        cache.generation = g_setup_generation;
        cache.attr = attr;
        cache.clut = g_clut_slot;
        ++cache.version;
        const std::uint32_t *w = cache.setup;
        cache.flags = make_setup(st, attr, cache.setup);
        cache.key = static_cast<std::uint64_t>(w[1]) | (static_cast<std::uint64_t>(w[2]) << 14) | (static_cast<std::uint64_t>(w[3]) << 20) |
                    (static_cast<std::uint64_t>(w[5]) << 26) | (static_cast<std::uint64_t>(w[6]) << 40);
        if (cache.flags & 2u) {
            const std::uint32_t tw = w[15] & 0xFFu, th = w[15] >> 8;
            const int tex_w = std::max(1 << tw, static_cast<int>(w[18] >> 16) + 1), tex_h = std::max(1 << th, static_cast<int>(w[19] >> 16) + 1);
            cache.tex = region(w[12], w[13], w[14], 0, 0, tex_w - 1, tex_h - 1);
        }
    }
    const std::uint32_t *setup = cache.setup;
    const std::uint32_t flags = cache.flags;
    const bool fst = flags & 16u, iip = flags & 1u;
    const int ofx = static_cast<int>(c.xyoffset & 0xFFFFu), ofy = static_cast<int>((c.xyoffset >> 32) & 0xFFFFu);
    const int scax0 = static_cast<int>(setup[10] & 0xFFFFu), scax1 = static_cast<int>(setup[10] >> 16);
    const int scay0 = static_cast<int>(setup[11] & 0xFFFFu), scay1 = static_cast<int>(setup[11] >> 16);
    const auto sx = [&](const Vertex &p) { return (static_cast<float>(p.x) - static_cast<float>(ofx)) / 16.0f; };
    const auto sy = [&](const Vertex &p) { return (static_cast<float>(p.y) - static_cast<float>(ofy)) / 16.0f; };
    const float samples_x = static_cast<float>(g_sx), samples_y = static_cast<float>(g_sy);
    const auto first = [&](float lo) { return static_cast<int>(std::floor(std::ceil(lo * samples_x) / samples_x)); };
    const auto first_y = [&](float lo) { return static_cast<int>(std::floor(std::ceil(lo * samples_y) / samples_y)); };

    std::uint32_t rec[kPrimWords] = {};
    int minx, miny, maxx, maxy;
    switch (prim) {
    case 3: case 4: case 5: {
        if (count < 3) return;
        const float x0 = sx(v[0]), y0 = sy(v[0]), x1 = sx(v[1]), y1 = sy(v[1]), x2 = sx(v[2]), y2 = sy(v[2]);
        const float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
        if (area == 0.0f) return;
        minx = std::max(scax0, first(std::min({x0, x1, x2})));
        maxx = std::min(scax1, static_cast<int>(std::ceil(std::max({x0, x1, x2}))) - 1);
        miny = std::max(scay0, first_y(std::min({y0, y1, y2})));
        maxy = std::min(scay1, static_cast<int>(std::ceil(std::max({y0, y1, y2}))) - 1);
        rec[1] = 0;
        const float xy[6] = {x0, y0, x1, y1, x2, y2};
        for (int i = 0; i < 6; ++i) rec[4 + i] = f2u(xy[i]);
        rec[10] = f2u(1.0f / area);
        const float sg = area > 0.0f ? 1.0f : -1.0f;
        const auto inclusive = [&](float ax, float ay, float bx, float by) {
            const float gx = (ay - by) * sg, gy = (bx - ax) * sg;
            return gx > 0.0f || (gx == 0.0f && gy > 0.0f);
        };
        rec[27] = (inclusive(x1, y1, x2, y2) ? 1u : 0u) | (inclusive(x2, y2, x0, y0) ? 2u : 0u) | (inclusive(x0, y0, x1, y1) ? 4u : 0u);
        for (int i = 0; i < 3; ++i) attrs(rec, i, v[i], fst, iip ? nullptr : &v[2]);
        rec[24] = v[0].z;
        rec[25] = f2u(static_cast<float>(static_cast<std::int64_t>(v[1].z) - static_cast<std::int64_t>(v[0].z)));
        rec[26] = f2u(static_cast<float>(static_cast<std::int64_t>(v[2].z) - static_cast<std::int64_t>(v[0].z)));
        break;
    }
    case 6: {
        const float x0 = sx(v[0]), y0 = sy(v[0]), x1 = sx(v[1]), y1 = sy(v[1]);
        minx = std::max(scax0, static_cast<int>(std::ceil(std::min(x0, x1))));
        maxx = std::min(scax1, static_cast<int>(std::ceil(std::max(x0, x1))) - 1);
        miny = std::max(scay0, static_cast<int>(std::ceil(std::min(y0, y1))));
        maxy = std::min(scay1, static_cast<int>(std::ceil(std::max(y0, y1))) - 1);
        rec[1] = 1;
        rec[4] = f2u(x0);
        rec[5] = f2u(y0);
        rec[6] = f2u(x1 - x0);
        rec[7] = f2u(y1 - y0);
        attrs(rec, 0, v[0], fst, nullptr);
        attrs(rec, 1, v[1], fst, nullptr);
        rec[24] = v[1].z;
        break;
    }
    case 1: case 2: {
        const float x0 = sx(v[0]), y0 = sy(v[0]), x1 = sx(v[1]), y1 = sy(v[1]);
        const int steps = static_cast<int>(std::max(std::fabs(x1 - x0), std::fabs(y1 - y0)));
        minx = std::max(scax0, static_cast<int>(std::floor(std::min(x0, x1))) - 1);
        maxx = std::min(scax1, static_cast<int>(std::ceil(std::max(x0, x1))) + 1);
        miny = std::max(scay0, static_cast<int>(std::floor(std::min(y0, y1))) - 1);
        maxy = std::min(scay1, static_cast<int>(std::ceil(std::max(y0, y1))) + 1);
        rec[1] = 2;
        rec[4] = f2u(x0);
        rec[5] = f2u(y0);
        rec[6] = f2u(x1);
        rec[7] = f2u(y1);
        rec[8] = static_cast<std::uint32_t>(steps);
        attrs(rec, 0, v[0], fst, iip ? nullptr : &v[1]);
        attrs(rec, 1, v[1], fst, nullptr);
        rec[24] = v[0].z;
        rec[25] = f2u(static_cast<float>(static_cast<std::int64_t>(v[1].z) - static_cast<std::int64_t>(v[0].z)));
        break;
    }
    case 0: {
        const int x = static_cast<int>(sx(v[0])), y = static_cast<int>(sy(v[0]));
        minx = maxx = x;
        miny = maxy = y;
        if (x < scax0 || x > scax1 || y < scay0 || y > scay1) return;
        rec[1] = 3;
        rec[4] = static_cast<std::uint32_t>(x);
        rec[5] = static_cast<std::uint32_t>(y);
        attrs(rec, 0, v[0], fst, nullptr);
        rec[24] = v[0].z;
        break;
    }
    default:
        return;
    }
    minx = std::max(minx, 0);
    miny = std::max(miny, 0);
    maxx = std::min(maxx, 2047);
    maxy = std::min(maxy, 2047);
    if (minx > maxx || miny > maxy) return;

    Batch &b = g_batch;
    const bool zte = flags & 512u;
    const std::uint64_t key = cache.key;
    if (b.key != ~0ull && b.key != key) emit_all();
    const Range &tex = cache.tex;
    if (flags & 2u) {
        if (!b.prims.empty()) {
            batch_ranges();
            const auto written = [&](const Range &t) { return t.overlaps(b.fb_range.lo, b.fb_range.hi) || (b.zwrite && t.overlaps(b.z_range.lo, b.z_range.hi)); };
            int rect[4];
            if (written(tex)) {
                if (!texel_rect(setup, v, count, prim, fst, rect)) {
                    emit_all();
                } else {
                    const Range used = region(setup[12], setup[13], setup[14], rect[0], rect[1], rect[2], rect[3]);
                    const bool small = rect[2] - rect[0] < 64 && rect[3] - rect[1] < 64;
                    const bool cached = b.texflushes == g_texflushes && small && shares_frame(setup, b);
                    const bool frame = !cached && (shares_frame(setup, b) ? drawn_under(b, rect) : used.overlaps(b.fb_range.lo, b.fb_range.hi));
                    if (frame || (b.zwrite && used.overlaps(b.z_range.lo, b.z_range.hi))) emit_all();
                }
            }
        }
    }
    if (b.prims.empty()) {
        b.texflushes = g_texflushes;
        b.key = key;
        b.fbp = setup[1];
        b.fbw = setup[2];
        b.fpsm = setup[3];
        b.zbp = setup[5];
        b.zpsm = setup[6];
        b.zte = false;
        b.zwrite = false;
        b.rx1 = -2;
    }
    b.zte = b.zte || zte;
    b.zwrite = b.zwrite || (zte && !(flags & 32u));
    const std::size_t setups = b.setups.size() / kSetupWords;
    std::uint32_t setup_index;
    static std::uint32_t last_version = ~0u, last_index = 0, last_batch = ~0u;
    if (g_hot_draw.load(std::memory_order_relaxed) && setups && last_version == cache.version && last_batch == g_batch_serial && last_index < setups) {
        setup_index = last_index;   // same setup as the triangle before, same batch: no 108-byte compare
    } else if (setups && std::memcmp(b.setups.data() + (setups - 1) * kSetupWords, setup, kSetupWords * 4) == 0) {
        setup_index = static_cast<std::uint32_t>(setups - 1);
    } else {
        setup_index = static_cast<std::uint32_t>(setups);
        b.setups.insert(b.setups.end(), setup, setup + kSetupWords);
    }
    last_version = cache.version;
    last_index = setup_index;
    last_batch = g_batch_serial;
    if (flags & 2u) {
        if (g_batch_reads.empty() || g_batch_reads.back().lo != tex.lo || g_batch_reads.back().hi != tex.hi) {
            bool known = false;
            for (const Range &t : g_batch_reads) known = known || (t.lo <= tex.lo && tex.hi <= t.hi);
            if (!known) g_batch_reads.push_back(tex);
        }
    }
    rec[0] = setup_index;
    rec[2] = static_cast<std::uint32_t>(minx) | (static_cast<std::uint32_t>(miny) << 16);
    rec[3] = static_cast<std::uint32_t>(maxx) | (static_cast<std::uint32_t>(maxy) << 16);
    b.prims.insert(b.prims.end(), rec, rec + kPrimWords);
    b.boxes.push_back(rec[2]);
    b.boxes.push_back(rec[3]);
    b.minx = std::min(b.minx, minx);
    b.miny = std::min(b.miny, miny);
    b.maxx = std::max(b.maxx, maxx);
    b.maxy = std::max(b.maxy, maxy);
    if (b.prims.size() >= kPrimWords * 65536) emit_all();
}

void image_begin(const State &s) {
    flush_image();
    Image &im = g_image;
    const std::uint64_t buf = s.bitbltbuf, pos = s.trxpos, reg = s.trxreg;
    im = Image{};
    im.dbp = static_cast<std::uint32_t>(buf >> 32) & 0x3FFFu;
    im.dbw = static_cast<std::uint32_t>(buf >> 48) & 0x3Fu;
    im.dpsm = static_cast<std::uint32_t>(buf >> 56) & 0x3Fu;
    im.dsax = static_cast<std::uint32_t>(pos >> 32) & 0x7FFu;
    im.dsay = static_cast<std::uint32_t>(pos >> 48) & 0x7FFu;
    im.rrw = static_cast<std::uint32_t>(reg) & 0xFFFu;
    im.total = im.rrw * (static_cast<std::uint32_t>(reg >> 32) & 0xFFFu);
    im.bpp = bits_per_pixel(im.dpsm);
    im.id = ++g_image_ids ? g_image_ids : ++g_image_ids;
    im.active = im.total != 0;
}

void image_data(const std::uint8_t *data, std::size_t bytes) {
    CpuTimer cpu_timer(4);
    Image &im = g_image;
    if (!im.active) return;
    if (im.pending.empty() && !im.lead_bits) {
        const std::uint64_t used = queue_upload(data, bytes, 0);
        const std::size_t whole = static_cast<std::size_t>(used / 8);
        if (im.done < im.total && whole < bytes) im.pending.assign(data + whole, data + bytes);
        im.lead_bits = static_cast<std::uint32_t>(used % 8);
        finish_image_if_done();
        return;
    }
    im.pending.insert(im.pending.end(), data, data + bytes);
}

void local_copy(const State &s) {
    flush_all();
    const std::uint64_t buf = s.bitbltbuf, pos = s.trxpos, reg = s.trxreg;
    const std::uint32_t w = static_cast<std::uint32_t>(reg) & 0xFFFu, h = static_cast<std::uint32_t>(reg >> 32) & 0xFFFu;
    if (!w || !h) return;
    mark_rendered(pages(static_cast<std::uint32_t>(buf >> 32) & 0x3FFFu, static_cast<std::uint32_t>(buf >> 48) & 0x3Fu, static_cast<std::uint32_t>(buf >> 56) & 0x3Fu,
                        static_cast<int>(pos >> 32) & 0x7FF, static_cast<int>(pos >> 48) & 0x7FF, (static_cast<int>(pos >> 32) & 0x7FF) + static_cast<int>(w) - 1,
                        (static_cast<int>(pos >> 48) & 0x7FF) + static_cast<int>(h) - 1));
    const std::uint32_t read = push_params({static_cast<std::uint32_t>(buf) & 0x3FFFu, static_cast<std::uint32_t>(buf >> 16) & 0x3Fu, static_cast<std::uint32_t>(buf >> 24) & 0x3Fu,
                                            static_cast<std::uint32_t>(pos) & 0x7FFu, static_cast<std::uint32_t>(pos >> 16) & 0x7FFu, w, h});
    const std::uint32_t write = push_params({static_cast<std::uint32_t>(buf >> 32) & 0x3FFFu, static_cast<std::uint32_t>(buf >> 48) & 0x3Fu, static_cast<std::uint32_t>(buf >> 56) & 0x3Fu,
                                             static_cast<std::uint32_t>(pos >> 32) & 0x7FFu, static_cast<std::uint32_t>(pos >> 48) & 0x7FFu, w, h,
                                             static_cast<std::uint32_t>(pos >> 59) & 3u});
    dispatch_linear(kCopyRead, w * h * g_sx * g_sy, read);
    dispatch_linear(kCopyWrite, w * h * g_sx * g_sy, write);
}

std::atomic<bool> g_clut_dedupe{true};   // lab A/B: fast_lane(5) = load every palette even when nothing changes
void load_clut(std::uint64_t tex0, std::uint64_t texclut) {
    CpuTimer cpu_timer(5);
    flush_image();
    const std::uint32_t psm = static_cast<std::uint32_t>(tex0 >> 20) & 0x3Fu;
    const std::uint32_t cpsm = (static_cast<std::uint32_t>(tex0 >> 51) & 0xFu) == 0 ? PSMCT32 : static_cast<std::uint32_t>(tex0 >> 51) & 0xFu;
    const std::uint32_t tc = static_cast<std::uint32_t>(texclut);
    const std::uint32_t cbp = static_cast<std::uint32_t>(tex0 >> 37) & 0x3FFFu, csm = static_cast<std::uint32_t>(tex0 >> 55) & 1u;
    const std::uint32_t cbw = tc & 0x3Fu, cou = (tc >> 6) & 0x3Fu, cov = (tc >> 12) & 0x3FFu;
    std::uint32_t rec[10] = {g_clut_slot, 0, cbp, cpsm, csm, static_cast<std::uint32_t>(tex0 >> 56) & 0x1Fu, (psm == PSMT8 || psm == PSMT8H) ? 1u : 0u, cbw, cou, cov};
    const Range range = csm ? region(cbp, cbw, cpsm, static_cast<int>(cou * 16), static_cast<int>(cov), static_cast<int>(cou * 16 + 255), static_cast<int>(cov))
                            : region(cbp, 1, cpsm, 0, 0, 15, 15);
    // what the slot will hold after this load; when that is exactly what it holds now (the game reloads the same
    // palette before most draws), the load changes nothing and is skipped
    std::array<std::uint32_t, 32> sl = g_slot_ident[g_clut_slot];
    {
        std::uint32_t id = 0x51u;
        for (int k = 2; k < 10; ++k) id = mix32(id, rec[k]);
        id = mix32(id, static_cast<std::uint32_t>(pages_epoch(range)));
        const std::uint32_t entries = rec[6] ? 256u : 16u, csa = rec[5];
        if (csm) {
            for (std::uint32_t e = 0; e < entries; e += 16) sl[(((csa * 16u) + e) & 511u) / 16u] = mix32(id, e);
        } else if (rec[6]) {
            for (std::uint32_t k = 0; k < 16; ++k) sl[k] = mix32(id, k * 16u);
        } else {
            sl[csa & 15u] = mix32(id, 0u);
        }
    }
    if (g_clut_dedupe.load(std::memory_order_relaxed) && sl == g_slot_ident[g_clut_slot]) {
        g_ps2_cpu_times[14] += 1.0;   // lab counter: palette loads skipped
        return;
    }
    g_ps2_cpu_times[15] += 1.0;   // lab counter: palette loads done
    if (g_clut_loads + 2 >= kClutSlots) {
        emit_all();
        submit();
    }
    const std::uint32_t next = (g_clut_slot + 1) % kClutSlots;
    rec[0] = g_clut_slot;
    rec[1] = next;
    PreOp op;
    op.clut = true;
    std::memcpy(op.rec, rec, sizeof rec);
    op.range = range;
    queue_pre(op);
    g_slot_ident[next] = sl;
    g_clut_slot = next;
    ++g_clut_loads;
}

void texflush() { ++g_texflushes; }

void flush() {
    if (g_mode == Mode::off) return;
    flush_all();
    submit();
}

void wait_idle() {
    flush_all();
    submit();
    bool done = false;
    WGPUQueueWorkDoneCallbackInfo cb = WGPU_QUEUE_WORK_DONE_CALLBACK_INFO_INIT;
    cb.mode = WGPUCallbackMode_AllowProcessEvents;
    cb.callback = [](WGPUQueueWorkDoneStatus, WGPUStringView, void *flag, void *) { *static_cast<bool *>(flag) = true; };
    cb.userdata1 = &done;
    wgpuQueueOnSubmittedWorkDone(g_queue, cb);
    wait_until(done);
}

struct PendingDownload {
    WGPUBuffer buffer = nullptr;
    std::uint64_t capacity = 0;
    std::uint8_t *memory = nullptr;
    std::uint32_t offset = 0, bytes = 0, serial = 0;
    bool busy = false, ready = false;
} g_pending;

void collect_download() {
    if (!g_pending.busy || !g_pending.ready) return;
    const void *mapped = wgpuBufferGetConstMappedRange(g_pending.buffer, 0, g_pending.bytes);
    if (mapped) std::memcpy(g_pending.memory + g_pending.offset, mapped, g_pending.bytes);
    wgpuBufferUnmap(g_pending.buffer);
    g_pending.busy = g_pending.ready = false;
}

// readback counters (perf report / PS2_DL_LOG): GPU -> game memory copies the game waits on
std::atomic<std::uint64_t> g_dl_sync{0}, g_dl_async{0}, g_dl_bytes{0}, g_dl_us{0};
void download_stats(double out[4]) {
    out[0] = static_cast<double>(g_dl_sync.load()); out[1] = static_cast<double>(g_dl_async.load());
    out[2] = static_cast<double>(g_dl_bytes.load()); out[3] = static_cast<double>(g_dl_us.load()) / 1000.0;
}
bool download_async(std::uint8_t *memory, std::uint32_t offset, std::uint32_t bytes, std::uint32_t serial) {
    g_dl_async.fetch_add(1, std::memory_order_relaxed);
    g_dl_bytes.fetch_add(bytes, std::memory_order_relaxed);
    collect_download();
    if (g_pending.busy) return false;
    if (g_pending.capacity < bytes) {
        if (g_pending.buffer) wgpuBufferRelease(g_pending.buffer);
        g_pending.capacity = bytes;
        g_pending.buffer = make_buffer(bytes, WGPUBufferUsage_MapRead | WGPUBufferUsage_CopyDst);
    }
    flush_all();
    if (g_sx * g_sy != 1) dispatch_linear(kResolve, bytes / 4, push_params({offset / 4}));
    submit();
    WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(g_device, nullptr);
    wgpuCommandEncoderCopyBufferToBuffer(enc, g_sx * g_sy == 1 ? g_vram : g_scratch, offset, g_pending.buffer, 0, bytes);
    WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
    wgpuQueueSubmit(g_queue, 1, &cmd);
    wgpuCommandBufferRelease(cmd);
    wgpuCommandEncoderRelease(enc);
    g_pending.memory = memory;
    g_pending.offset = offset;
    g_pending.bytes = bytes;
    g_pending.serial = serial;
    g_pending.busy = true;
    WGPUBufferMapCallbackInfo cb = WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
    cb.mode = WGPUCallbackMode_AllowProcessEvents;
    cb.callback = [](WGPUMapAsyncStatus status, WGPUStringView, void *, void *) {
        if (status == WGPUMapAsyncStatus_Success) g_pending.ready = true;
        else g_pending.busy = false;
    };
    wgpuBufferMapAsync(g_pending.buffer, WGPUMapMode_Read, 0, bytes, cb);
    return true;
}

bool finish_download(std::uint32_t serial) {
    if (!g_pending.busy || g_pending.serial != serial) return false;
    const auto t0 = std::chrono::steady_clock::now();
    while (g_pending.busy && !g_pending.ready) pump();
    g_dl_us.fetch_add(static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - t0).count()), std::memory_order_relaxed);
    const bool done = g_pending.ready;
    collect_download();
    return done;
}

void download(std::uint8_t *memory, std::uint32_t offset, std::uint32_t bytes) {
    g_dl_sync.fetch_add(1, std::memory_order_relaxed);
    g_dl_bytes.fetch_add(bytes, std::memory_order_relaxed);
    struct Timer { std::chrono::steady_clock::time_point t0 = std::chrono::steady_clock::now();
        ~Timer() { g_dl_us.fetch_add(static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - t0).count()), std::memory_order_relaxed); } } timer;
    flush_all();
    if (g_sx * g_sy == 1) {
        submit();
        read_back(g_vram, bytes, memory + offset, offset);
        return;
    }
    dispatch_linear(kResolve, bytes / 4, push_params({offset / 4}));
    submit();
    read_back(g_scratch, bytes, memory + offset, offset);
}

void read_state(std::vector<std::uint32_t> &vram, std::uint32_t &scale, std::vector<std::uint32_t> &clut) {
    flush_all();
    submit();
    scale = g_sx | (g_sy << 16);
    vram.resize(static_cast<std::size_t>(kMemorySize / 4) * g_sx * g_sy);
    read_back(g_vram, vram.size() * 4, vram.data());
    clut.resize(kClutEntries);
    read_back(g_clut, kClutEntries * 4, clut.data(), static_cast<std::uint64_t>(g_clut_slot) * kClutEntries * 4);
}

void write_state(const std::vector<std::uint32_t> &vram, std::uint32_t scale, const std::vector<std::uint32_t> &clut) {
    wait_idle();
    const std::size_t words = kMemorySize / 4;
    const std::uint32_t fx = scale & 0xFFFFu, fy = (scale >> 16) ? (scale >> 16) : fx, from = fx * fy, to = g_sx * g_sy;
    std::fill(std::begin(g_rendered), std::end(g_rendered), from == to && to > 1);
    decode_reset();
    g_upload_seen.clear();
    ++g_ident_serial;
    for (std::uint32_t i = 0; i < 2048; ++i)
        for (std::uint32_t k = 0; k < 32; ++k) g_slot_ident[i][k] = mix32(mix32(g_ident_serial * 2654435761u, i), k);
    if (from == to && vram.size() == words * to) {
        wgpuQueueWriteBuffer(g_queue, g_vram, 0, vram.data(), vram.size() * 4);
    } else {
        std::vector<std::uint32_t> layers(words * to);
        for (std::size_t w = 0; w < words; ++w)
            for (std::uint32_t k = 0; k < to; ++k) layers[w * to + k] = vram[w * from];
        wgpuQueueWriteBuffer(g_queue, g_vram, 0, layers.data(), layers.size() * 4);
    }
    if (clut.size() >= kClutEntries) wgpuQueueWriteBuffer(g_queue, g_clut, static_cast<std::uint64_t>(g_clut_slot) * kClutEntries * 4, clut.data(), kClutEntries * 4);
    wait_idle();
}

void stats() {
    if (g_mode == Mode::off) return;
    std::fprintf(stderr, "[gpu] %llu submits, dispatches:", static_cast<unsigned long long>(g_submits));
    for (int i = 0; i < kPipelines; ++i) std::fprintf(stderr, " %s %llu", kEntryPoints[i], static_cast<unsigned long long>(g_dispatches[i]));
    std::fprintf(stderr, "\n");
}

void configure_surface() {
    WGPUSurfaceConfiguration config = WGPU_SURFACE_CONFIGURATION_INIT;
    config.device = g_device;
    config.format = g_surface_format;
    config.usage = WGPUTextureUsage_RenderAttachment;
    config.width = std::max(g_surface_width, 1u);
    config.height = std::max(g_surface_height, 1u);
    config.presentMode = g_present_mode;
    config.alphaMode = WGPUCompositeAlphaMode_Auto;
    wgpuSurfaceConfigure(g_surface, &config);
}

bool attach_surface(const SurfaceTarget &target) {
    if (g_mode != Mode::primary || !g_device) return false;
    WGPUSurfaceDescriptor sd = WGPU_SURFACE_DESCRIPTOR_INIT;
#ifdef __EMSCRIPTEN__
    WGPUEmscriptenSurfaceSourceCanvasHTMLSelector canvas = WGPU_EMSCRIPTEN_SURFACE_SOURCE_CANVAS_HTML_SELECTOR_INIT;
    canvas.selector = view(target.selector ? target.selector : "#canvas");
    sd.nextInChain = &canvas.chain;
#else
    WGPUSurfaceSourceXlibWindow xlib = WGPU_SURFACE_SOURCE_XLIB_WINDOW_INIT;
    WGPUSurfaceSourceWaylandSurface wayland = WGPU_SURFACE_SOURCE_WAYLAND_SURFACE_INIT;
    if (target.kind == SurfaceTarget::X11) {
        xlib.display = target.display;
        xlib.window = target.window;
        sd.nextInChain = &xlib.chain;
    } else if (target.kind == SurfaceTarget::Wayland) {
        wayland.display = target.display;
        wayland.surface = target.surface;
        sd.nextInChain = &wayland.chain;
    } else {
        return false;
    }
#endif
    g_surface = wgpuInstanceCreateSurface(g_instance, &sd);
    if (!g_surface) return false;
    WGPUSurfaceCapabilities caps = WGPU_SURFACE_CAPABILITIES_INIT;
    if (wgpuSurfaceGetCapabilities(g_surface, g_adapter, &caps) != WGPUStatus_Success || !caps.formatCount) {
        wgpuSurfaceRelease(g_surface);
        g_surface = nullptr;
        return false;
    }
    g_surface_format = caps.formats[0];
    for (std::size_t i = 0; i < caps.formatCount; ++i)
        if (caps.formats[i] == WGPUTextureFormat_BGRA8Unorm || caps.formats[i] == WGPUTextureFormat_RGBA8Unorm) {
            g_surface_format = caps.formats[i];
            break;
        }
    g_present_mode = WGPUPresentMode_Fifo;
    for (const WGPUPresentMode wanted : {WGPUPresentMode_Immediate, WGPUPresentMode_Mailbox})
        for (std::size_t i = 0; i < caps.presentModeCount; ++i)
            if (caps.presentModes[i] == wanted) g_present_mode = wanted;
    wgpuSurfaceCapabilitiesFreeMembers(caps);
    g_surface_width = target.width;
    g_surface_height = target.height;
    configure_surface();

    WGPUShaderSourceWGSL source = WGPU_SHADER_SOURCE_WGSL_INIT;
    source.code = view(kBlitShader);
    WGPUShaderModuleDescriptor md = WGPU_SHADER_MODULE_DESCRIPTOR_INIT;
    md.nextInChain = &source.chain;
    WGPUShaderModule module = wgpuDeviceCreateShaderModule(g_device, &md);
    WGPUBindGroupLayoutEntry le[2] = {WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT, WGPU_BIND_GROUP_LAYOUT_ENTRY_INIT};
    le[0].binding = 0;
    le[0].visibility = WGPUShaderStage_Fragment;
    le[0].buffer.type = WGPUBufferBindingType_ReadOnlyStorage;
    le[1].binding = 1;
    le[1].visibility = WGPUShaderStage_Fragment;
    le[1].buffer.type = WGPUBufferBindingType_Uniform;
    WGPUBindGroupLayoutDescriptor ld = WGPU_BIND_GROUP_LAYOUT_DESCRIPTOR_INIT;
    ld.entryCount = 2;
    ld.entries = le;
    WGPUBindGroupLayout layout = wgpuDeviceCreateBindGroupLayout(g_device, &ld);
    WGPUPipelineLayoutDescriptor pld = WGPU_PIPELINE_LAYOUT_DESCRIPTOR_INIT;
    pld.bindGroupLayoutCount = 1;
    pld.bindGroupLayouts = &layout;
    WGPUPipelineLayout pipeline_layout = wgpuDeviceCreatePipelineLayout(g_device, &pld);
    WGPUColorTargetState color = WGPU_COLOR_TARGET_STATE_INIT;
    color.format = g_surface_format;
    WGPUFragmentState fragment = WGPU_FRAGMENT_STATE_INIT;
    fragment.module = module;
    fragment.entryPoint = view("fs");
    fragment.targetCount = 1;
    fragment.targets = &color;
    WGPURenderPipelineDescriptor rd = WGPU_RENDER_PIPELINE_DESCRIPTOR_INIT;
    rd.layout = pipeline_layout;
    rd.vertex.module = module;
    rd.vertex.entryPoint = view("vs");
    rd.fragment = &fragment;
    g_blit = wgpuDeviceCreateRenderPipeline(g_device, &rd);
    wgpuShaderModuleRelease(module);
    wgpuPipelineLayoutRelease(pipeline_layout);
    g_blit_params = make_buffer(32, WGPUBufferUsage_Uniform | WGPUBufferUsage_CopyDst);
    WGPUBindGroupEntry be[2] = {WGPU_BIND_GROUP_ENTRY_INIT, WGPU_BIND_GROUP_ENTRY_INIT};
    be[0].binding = 0;
    be[0].buffer = g_scratch;
    be[0].size = WGPU_WHOLE_SIZE;
    be[1].binding = 1;
    be[1].buffer = g_blit_params;
    be[1].size = 32;
    WGPUBindGroupDescriptor bd = WGPU_BIND_GROUP_DESCRIPTOR_INIT;
    bd.layout = layout;
    bd.entryCount = 2;
    bd.entries = be;
    g_blit_group = wgpuDeviceCreateBindGroup(g_device, &bd);
    wgpuBindGroupLayoutRelease(layout);
    return g_blit != nullptr;
}

void resize_surface(std::uint32_t width, std::uint32_t height) {
    if (!g_surface || (width == g_surface_width && height == g_surface_height)) return;
    g_surface_width = width;
    g_surface_height = height;
    configure_surface();
#ifdef PS2_PGS
    if (g_pgs) pgs::resize(width, height);
#endif
}

bool has_surface() { return g_surface != nullptr; }

// Even frame spacing (web): present() can stop after the frame is built into its field buffer; the host then
// puts it on the canvas with show_pending() when its turn on the 60 Hz beat comes, while the next frame keeps
// rendering. At most one frame waits: a new one shows the waiting one first.
std::atomic<bool> g_defer_show{false};
bool g_pending_show = false;
std::uint32_t g_pending_blit[8] = {};
float g_pending_aspect = 0.0f;

void set_defer_show(bool on) { g_defer_show.store(on); }
bool pending_show() {
#ifdef PS2_PGS
    if (g_pgs) return g_pgs_pending;
#endif
    return g_pending_show;
}
std::atomic<std::uint32_t> g_shows{0};
std::uint32_t show_count() { return g_shows.load(); }

#ifdef PS2_PGS
bool pgs_start() {
    static bool tried = false;
    if (tried) return g_pgs;
    tried = true;
    const char *want = std::getenv("PS2_PGS");
    if (!want || !g_device || !g_surface) return false;
    const float scale = std::clamp(static_cast<float>(std::atof(want)), 1.0f, 10.0f);
    g_pgs = pgs::init(g_instance, g_adapter, g_device, scale, g_surface_width, g_surface_height, g_options.aspect);
    std::fprintf(stderr, "[pgs] PCSX2 GS renderer %s at %.0fx\n", g_pgs ? "on" : "failed", scale);
    return g_pgs;
}
bool pgs_on() { return g_pgs; }
bool pgs_show_now() {
    static double acquire_ms = 0;
    static int shows = 0;
    const auto t0 = std::chrono::steady_clock::now();
    WGPUSurfaceTexture st = WGPU_SURFACE_TEXTURE_INIT;
    wgpuSurfaceGetCurrentTexture(g_surface, &st);
    acquire_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    if (++shows == 60) {
        if (std::getenv("PS2_PGS_PROF")) std::fprintf(stderr, "[pgs] canvas texture wait %.2f ms/frame\n", acquire_ms / 60);
        shows = 0;
        acquire_ms = 0;
    }
    if (st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessOptimal && st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessSuboptimal) {
        if (st.texture) wgpuTextureRelease(st.texture);
        configure_surface();
        return true;
    }
    WGPUTextureView target = wgpuTextureCreateView(st.texture, nullptr);
    pgs::show(target, g_surface_format, g_surface_width, g_surface_height);
#ifndef __EMSCRIPTEN__
    wgpuSurfacePresent(g_surface);
#endif
    wgpuTextureViewRelease(target);
    wgpuTextureRelease(st.texture);
    return true;
}
void pgs_present() {
    // same pacing as the engine's own frames: with even spacing on, the picture waits for show_pending()
    if (g_pgs_pending) { g_pgs_pending = false; g_shows.fetch_add(1); pgs_show_now(); }
    if (g_defer_show.load(std::memory_order_relaxed)) { g_pgs_pending = true; return; }
    pgs_show_now();
}
#else
bool pgs_start() { return false; }
bool pgs_on() { return false; }
void pgs_present() {}
#endif

bool show_pending() {
#ifdef PS2_PGS
    if (g_pgs) {
        if (!g_pgs_pending) return false;
        g_pgs_pending = false;
        g_shows.fetch_add(1);
        return pgs_show_now();
    }
#endif
    if (!g_pending_show || !g_surface) return false;
    g_pending_show = false;
    g_shows.fetch_add(1);
    g_present_aspect = g_pending_aspect;
    wgpuQueueWriteBuffer(g_queue, g_blit_params, 0, g_pending_blit, sizeof g_pending_blit);
    WGPUSurfaceTexture st = WGPU_SURFACE_TEXTURE_INIT;
    wgpuSurfaceGetCurrentTexture(g_surface, &st);
    if (st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessOptimal && st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessSuboptimal) {
        if (st.texture) wgpuTextureRelease(st.texture);
        submit();
        configure_surface();
        return true;
    }
    WGPUTextureView target = wgpuTextureCreateView(st.texture, nullptr);
    submit(target);
#ifndef __EMSCRIPTEN__
    wgpuSurfacePresent(g_surface);
#endif
    wgpuTextureViewRelease(target);
    wgpuTextureRelease(st.texture);
    return true;
}

bool present(const DisplaySource &src) {
    if (!g_surface) return false;
    if (g_pending_show) show_pending();
    flush_all();
    const std::uint32_t current = field_base(g_field), previous = field_base(g_field + 1);
    static const bool weave_off = std::getenv("PS2_NO_DEINTERLACE") != nullptr;
    const bool blend = src.halved && g_have_previous && g_last_width == src.width && g_last_height == src.height && !weave_off;
    const std::uint32_t param = push_params({src.fbp, src.fbw, src.psm, src.dbx, src.dby, src.width, src.height, src.halved ? 1u : 0u, current});
    res_flush();
    g_commands.push_back({kDisplay, (src.width * g_sx + 7) / 8, (src.height * g_sy + 7) / 8, param});
    const float sw = static_cast<float>(g_surface_width), sh = static_cast<float>(g_surface_height);
    g_present_aspect = present_as_43() ? 4.0f / 3.0f : g_options.aspect;
    const float aspect = g_present_aspect;
    const float vw = std::min(sw, sh * aspect), vh = vw / aspect;
    const std::uint32_t blit[8] = {src.width * g_sx, src.height * g_sy, current, previous, blend ? 1u : 0u, static_cast<std::uint32_t>(vw), static_cast<std::uint32_t>(vh), ps2::video_options()};
    ++g_field;
    g_have_previous = true;
    g_last_width = src.width;
    g_last_height = src.height;
    if (g_defer_show.load(std::memory_order_relaxed)) {
        submit();   // build the frame into its field buffer now; it goes on the canvas in show_pending()
        std::memcpy(g_pending_blit, blit, sizeof blit);
        g_pending_aspect = g_present_aspect;
        g_pending_show = true;
        return true;
    }
    wgpuQueueWriteBuffer(g_queue, g_blit_params, 0, blit, sizeof blit);
    WGPUSurfaceTexture st = WGPU_SURFACE_TEXTURE_INIT;
    wgpuSurfaceGetCurrentTexture(g_surface, &st);
    if (st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessOptimal && st.status != WGPUSurfaceGetCurrentTextureStatus_SuccessSuboptimal) {
        if (st.texture) wgpuTextureRelease(st.texture);
        submit();
        configure_surface();
        return true;
    }
    WGPUTextureView target = wgpuTextureCreateView(st.texture, nullptr);
    submit(target);
#ifndef __EMSCRIPTEN__
    wgpuSurfacePresent(g_surface);
#endif
    wgpuTextureViewRelease(target);
    wgpuTextureRelease(st.texture);
    return true;
}

bool rendered_pages(std::uint32_t lo, std::uint32_t hi) {
    Range r;
    r.add(lo, hi);
    return rendered(r);
}

std::uint32_t hd_capacity_words() { return g_hd_words; }

bool hd_upload(std::uint32_t offset_words, const std::uint8_t *rgba, std::size_t bytes) {
    if (!g_hd || static_cast<std::uint64_t>(offset_words) * 4 + bytes > static_cast<std::uint64_t>(g_hd_words) * 4) return false;
    wgpuQueueWriteBuffer(g_queue, g_hd, static_cast<std::uint64_t>(offset_words) * 4, rgba, (bytes + 3) & ~std::size_t{3});
    return true;
}

void set_fast_lane(int on) { g_fast_on.store(on != 0); g_decode_many_on.store(on != 2); g_res_on.store(on != 2 && on != 3); g_hot_draw.store(on != 4); g_clut_dedupe.store(on != 5); }

void start_profile(std::uint64_t from, std::uint64_t to) {
    if (g_profile_out) std::fclose(g_profile_out);
    g_profile_out = std::fopen("/gpuprof.txt", "w");
    g_profile_from = from;
    g_profile_to = to;
}

double busy_ms() {
    if (!g_measured) return 0.0;
    return static_cast<double>(g_measured_ns) / static_cast<double>(g_measured) * static_cast<double>(g_total_passes) / 1e6;
}

struct Copy {
    WGPUBuffer buffer = nullptr;
    std::uint64_t size = 0, order = 0;
    std::uint32_t width = 0, height = 0;
    bool busy = false, ready = false;
};
Copy g_copies[3];
std::uint64_t g_copy_order = 0;

bool display_async(const DisplaySource &src, std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height) {
#ifdef __EMSCRIPTEN__
    wgpuInstanceProcessEvents(g_instance);
#else
    wgpuDevicePoll(g_device, false, nullptr);
#endif
    Copy *newest = nullptr;
    for (Copy &c : g_copies)
        if (c.ready && (!newest || c.order > newest->order)) newest = &c;
    if (newest) {
        const std::uint64_t bytes = static_cast<std::uint64_t>(newest->width) * newest->height * 4;
        const void *mapped = wgpuBufferGetConstMappedRange(newest->buffer, 0, bytes);
        if (mapped) {
            rgba.resize(static_cast<std::size_t>(newest->width) * newest->height);
            std::memcpy(rgba.data(), mapped, bytes);
            width = newest->width;
            height = newest->height;
        }
        for (Copy &c : g_copies)
            if (c.ready && c.order <= newest->order) {
                wgpuBufferUnmap(c.buffer);
                c.ready = c.busy = false;
            }
        if (!mapped) newest = nullptr;
    }
    Copy *slot = nullptr;
    for (Copy &c : g_copies)
        if (!c.busy) slot = &c;
    if (slot) {
        const std::uint64_t bytes = static_cast<std::uint64_t>(src.width) * src.height * g_sx * g_sy * 4;
        if (slot->size < bytes) {
            if (slot->buffer) wgpuBufferRelease(slot->buffer);
            slot->size = bytes;
            slot->buffer = make_buffer(bytes, WGPUBufferUsage_MapRead | WGPUBufferUsage_CopyDst);
        }
        flush_all();
        const std::uint32_t param = push_params({src.fbp, src.fbw, src.psm, src.dbx, src.dby, src.width, src.height, src.halved ? 1u : 0u});
        res_flush();
    g_commands.push_back({kDisplay, (src.width * g_sx + 7) / 8, (src.height * g_sy + 7) / 8, param});
        submit();
        WGPUCommandEncoder enc = wgpuDeviceCreateCommandEncoder(g_device, nullptr);
        wgpuCommandEncoderCopyBufferToBuffer(enc, g_scratch, 0, slot->buffer, 0, bytes);
        WGPUCommandBuffer cmd = wgpuCommandEncoderFinish(enc, nullptr);
        wgpuQueueSubmit(g_queue, 1, &cmd);
        wgpuCommandBufferRelease(cmd);
        wgpuCommandEncoderRelease(enc);
        slot->busy = true;
        slot->order = ++g_copy_order;
        slot->width = src.width * g_sx;
        slot->height = src.height * g_sy;
        WGPUBufferMapCallbackInfo cb = WGPU_BUFFER_MAP_CALLBACK_INFO_INIT;
        cb.mode = WGPUCallbackMode_AllowProcessEvents;
        cb.callback = [](WGPUMapAsyncStatus status, WGPUStringView, void *copy, void *) {
            Copy &c = *static_cast<Copy *>(copy);
            if (status == WGPUMapAsyncStatus_Success) c.ready = true;
            else c.busy = false;
        };
        cb.userdata1 = slot;
        wgpuBufferMapAsync(slot->buffer, WGPUMapMode_Read, 0, bytes, cb);
    }
    return newest != nullptr;
}

bool display(const DisplaySource &src, std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height) {
    flush_all();
    const std::uint32_t param = push_params({src.fbp, src.fbw, src.psm, src.dbx, src.dby, src.width, src.height, src.halved ? 1u : 0u});
    res_flush();
    g_commands.push_back({kDisplay, (src.width * g_sx + 7) / 8, (src.height * g_sy + 7) / 8, param});
    submit();
    width = src.width * g_sx;
    height = src.height * g_sy;
    rgba.resize(static_cast<std::size_t>(width) * height);
    read_back(g_scratch, rgba.size() * 4, rgba.data());
    return true;
}

}
