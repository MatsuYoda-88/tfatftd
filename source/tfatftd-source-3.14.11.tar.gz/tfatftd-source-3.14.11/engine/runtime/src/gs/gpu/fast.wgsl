// ===== Fast lane =====
// A batch of plain layers (no depth test, no destination-alpha test) is drawn by the GPU's own rasterizer and
// blender instead of the tile loop: its frame-buffer rectangle is copied out of PS2 memory into an RGBA texture
// (fast_load), every primitive is drawn as its bounding box with this fragment shader (which runs the exact
// same coverage / texture / fog / alpha-test code as the compute rasterizer and discards what it would skip),
// the blend unit does (A - B) * C + D, and the rectangle is written back into PS2 memory (fast_store).
// This module is the compute shader text with this file appended; it needs the dual-source-blending feature
// (the blend factor is the PS2 source alpha / 128, while the stored alpha is the source alpha itself).
//
// params: 1 prims, 2 setups, 7 origin x (pixels), 8 origin y, 9 width (samples), 10 height (samples),
//         11 frame base (setup word 1), 12 frame width, 13 frame psm, 14 target width, 15 target height,
//         16 Z base (setup word 5), 17 Z psm
//
// Depth: PS2 Z is an integer (32, 24 or 16 bits). It goes into a depth32float target as the bit pattern of a
// positive normal float (+ 0x00800000 keeps it clear of denormals), so the GPU's float compare is the integer
// compare: exact for Z24 / Z16, the top 29 bits for Z32 (values written back unchanged keep their low bits).

// load_setup without the frame / Z layouts (the fast lane's depth and blend units do those) and the texture
// layout only for undecoded textures
fn load_setup_fast(at: u32) -> Setup {
    var s: Setup;
    s.flags = data[at];
    s.fbp = data[at + 1u];
    s.fbw = data[at + 2u];
    s.fpsm = data[at + 3u];
    s.fbmsk = data[at + 4u];
    s.zbp = data[at + 5u];
    s.zpsm = data[at + 6u];
    s.modes = data[at + 7u];
    s.aref = data[at + 8u];
    s.fix = data[at + 9u];
    s.scax0 = i32(data[at + 10u] & 0xFFFFu);
    s.scax1 = i32(data[at + 10u] >> 16u);
    s.scay0 = i32(data[at + 11u] & 0xFFFFu);
    s.scay1 = i32(data[at + 11u] >> 16u);
    s.tbp = data[at + 12u];
    s.tbw = data[at + 13u];
    s.tpsm = data[at + 14u];
    s.tw = data[at + 15u] & 0xFFu;
    s.th = data[at + 15u] >> 8u;
    s.cpsm = data[at + 16u];
    s.csa = data[at + 17u];
    s.minu = data[at + 18u] & 0xFFFFu;
    s.maxu = data[at + 18u] >> 16u;
    s.minv = data[at + 19u] & 0xFFFFu;
    s.maxv = data[at + 19u] >> 16u;
    s.ta0 = data[at + 20u] & 0xFFu;
    s.ta1 = (data[at + 20u] >> 8u) & 0xFFu;
    s.fogcol = data[at + 21u];
    s.clut = data[at + 22u];
    s.zmax = data[at + 23u];
    s.dec = data[at + 24u];
    s.hd = data[at + 25u];
    s.hds = data[at + 26u];
    if ((s.flags & F_TME) != 0u && s.dec == 0xFFFFFFFFu && s.hd == 0xFFFFFFFFu) {
        s.tf = fmt_of(s.tpsm, s.tbp, s.tbw);
    }
    return s;
}

@group(1) @binding(0) var<storage, read> vdata: array<u32>;
@group(1) @binding(1) var<uniform> vparams: Params;

fn vprm(i: u32) -> u32 {
    return vparams.v[i / 4u][i % 4u];
}

struct FastVertex {
    @builtin(position) pos: vec4<f32>,
    @location(0) @interpolate(flat) prim: u32,
}

fn cross2(a: vec2<f32>, b: vec2<f32>) -> f32 {
    return a.x * b.y - a.y * b.x;
}

@vertex
fn fast_vs(@builtin(vertex_index) vi: u32) -> FastVertex {
    let n = vi / 6u;
    let c = vi % 6u;
    let p = vprm(1u) + n * PRIM_WORDS;
    let lo = vdata[p + 2u];
    let hi = vdata[p + 3u];
    let ox = vprm(7u);
    let oy = vprm(8u);
    // bounding box corners in target samples (inclusive pixel box -> exclusive sample edge)
    let x0 = f32(((lo & 0xFFFFu) - ox) * SX);
    let y0 = f32(((lo >> 16u) - oy) * SY);
    let x1 = f32(((hi & 0xFFFFu) + 1u - ox) * SX);
    let y1 = f32(((hi >> 16u) + 1u - oy) * SY);
    var x = x0;
    var y = y0;
    // two triangles: 0 1 2 / 2 1 3 with corners 0 = (x0,y0) 1 = (x1,y0) 2 = (x0,y1) 3 = (x1,y1)
    let corner = array<u32, 6>(0u, 1u, 2u, 2u, 1u, 3u)[c];
    if ((corner & 1u) != 0u) {
        x = x1;
    }
    if ((corner & 2u) != 0u) {
        y = y1;
    }
    // triangles: their own shape, pushed out by one target pixel on every edge (so every sample the compute
    // rasterizer would cover gets a fragment; the fragment shader then applies the exact PS2 edge test)
    if (vdata[p + 1u] == 0u) {
        var t: array<vec2<f32>, 3>;
        for (var i = 0u; i < 3u; i = i + 1u) {
            t[i] = vec2<f32>((bitcast<f32>(vdata[p + 4u + i * 2u]) - f32(ox)) * f32(SX), (bitcast<f32>(vdata[p + 5u + i * 2u]) - f32(oy)) * f32(SY));
        }
        let e = cross2(t[1] - t[0], t[2] - t[0]);
        let i = min(c, 2u);
        let a = t[(i + 2u) % 3u];
        let b = t[i];
        let n = t[(i + 1u) % 3u];
        var pos = b;
        if (e != 0.0) {
            let d1 = normalize(b - a);
            let d2 = normalize(n - b);
            var n1 = vec2<f32>(d1.y, -d1.x);
            var n2 = vec2<f32>(d2.y, -d2.x);
            if (e < 0.0) {
                n1 = -n1;
                n2 = -n2;
            }
            var off = (n1 + n2) / max(1.0 + dot(n1, n2), 0.0625);
            let len = length(off);
            if (len > 8.0) {
                off = off * (8.0 / len);
            }
            pos = b + off;
        }
        x = pos.x;
        y = pos.y;
    }
    let tw = f32(vprm(14u));
    let th = f32(vprm(15u));
    var out: FastVertex;
    out.pos = vec4<f32>(x / tw * 2.0 - 1.0, 1.0 - y / th * 2.0, 0.0, 1.0);
    out.prim = n;
    return out;
}

fn zenc(z: u32, psm: u32) -> f32 {
    if (psm == PSMZ32) {
        return bitcast<f32>((z >> 3u) + 0x00800000u);
    }
    return bitcast<f32>(z + 0x00800000u);
}

struct FastOut {
    @location(0) @blend_src(0) color: vec4<f32>,
    @location(0) @blend_src(1) factor: vec4<f32>,
    @builtin(frag_depth) depth: f32,
}

@fragment
fn fast_fs(@builtin(position) pos: vec4<f32>, @location(0) @interpolate(flat) prim: u32) -> FastOut {
    let sx = prm(7u) * SX + u32(pos.x);
    let sy = prm(8u) * SY + u32(pos.y);
    let x = i32(sx / SX);
    let y = i32(sy / SY);
    let k = (sy % SY) * SX + sx % SX;
    let px = f32(x) + f32(sx % SX) / f32(SX);
    let py = f32(y) + f32(sy % SY) / f32(SY);
    let p = prm(1u) + prim * PRIM_WORDS;
    let s = load_setup_fast(prm(2u) + data[p] * SETUP_WORDS);
    if (x < s.scax0 || x > s.scax1 || y < s.scay0 || y > s.scay1) {
        discard;
    }
    let scanmsk = mode(s, 28u, 2u);
    if ((scanmsk == 2u && (y & 1) == 0) || (scanmsk == 3u && (y & 1) != 0)) {
        discard;
    }
    let h = prim_attr(p, s, x, y, px, py);
    if (!h.hit) {
        discard;
    }
    let f = frag_color(s, k, h.at);
    if (!f.ok || !f.fb) {
        discard;
    }
    var out_a = u32(f.a & 0xFF);
    if (has(s, F_FBA)) {
        out_a = out_a | 0x80u;
    }
    var out: FastOut;
    out.color = vec4<f32>(f32(clamp(f.r, 0, 255)), f32(clamp(f.g, 0, 255)), f32(clamp(f.b, 0, 255)), f32(out_a)) / 255.0;
    // blend factor C = source alpha (the FIX variants use the blend constant instead)
    out.factor = vec4<f32>(0.0, 0.0, 0.0, clamp(f32(f.a) / 128.0, 0.0, 1.0));
    out.depth = zenc(min(h.at.z, s.zmax), prm(17u));
    return out;
}

// whole target rectangle (the Z buffer copy-in at the start of a fast batch)
@vertex
fn fast_vs_full(@builtin(vertex_index) vi: u32) -> @builtin(position) vec4<f32> {
    let corner = array<u32, 6>(0u, 1u, 2u, 2u, 1u, 3u)[vi % 6u];
    var x = f32(vprm(7u) * SX);
    var y = f32(vprm(8u) * SY);
    if ((corner & 1u) != 0u) {
        x = x + f32(vprm(9u));
    }
    if ((corner & 2u) != 0u) {
        y = y + f32(vprm(10u));
    }
    return vec4<f32>(x / f32(vprm(14u)) * 2.0 - 1.0, 1.0 - y / f32(vprm(15u)) * 2.0, 0.0, 1.0);
}

@fragment
fn fast_zload(@builtin(position) pos: vec4<f32>) -> @builtin(frag_depth) f32 {
    let sx = u32(pos.x);
    let sy = u32(pos.y);
    let k = (sy % SY) * SX + sx % SX;
    let l = addr(fmt_of(prm(17u), prm(16u), prm(12u)), sx / SX, sy / SY);
    return zenc(load_at(l, k), prm(17u));
}

@group(1) @binding(0) var fast_zin: texture_depth_2d;

@compute @workgroup_size(8, 8)
fn fast_zstore(@builtin(global_invocation_id) gid: vec3<u32>) {
    if (gid.x >= prm(9u) || gid.y >= prm(10u)) {
        return;
    }
    let sx = prm(7u) * SX + gid.x;
    let sy = prm(8u) * SY + gid.y;
    let k = (sy % SY) * SX + sx % SX;
    let l = addr(fmt_of(prm(17u), prm(16u), prm(12u)), sx / SX, sy / SY);
    var v = bitcast<u32>(textureLoad(fast_zin, vec2<u32>(sx, sy), 0)) - 0x00800000u;
    let old = load_at(l, k);
    if (prm(17u) == PSMZ32) {
        if ((old >> 3u) == v) {
            return;
        }
        v = v << 3u;
    } else if (old == v) {
        return;
    }
    store(l, k, v);
}

@group(1) @binding(0) var fast_out: texture_storage_2d<rgba8unorm, write>;

@compute @workgroup_size(8, 8)
fn fast_load(@builtin(global_invocation_id) gid: vec3<u32>) {
    if (gid.x >= prm(9u) || gid.y >= prm(10u)) {
        return;
    }
    let sx = prm(7u) * SX + gid.x;
    let sy = prm(8u) * SY + gid.y;
    let k = (sy % SY) * SX + sx % SX;
    let f = fmt_of(prm(13u), prm(11u), prm(12u));
    let l = addr(f, sx / SX, sy / SY);
    let v = atomicLoad(&vram[l.word * SX * SY + k]);
    textureStore(fast_out, vec2<u32>(sx, sy), unpack4x8unorm(v));
}

@group(1) @binding(0) var fast_in: texture_2d<f32>;

@compute @workgroup_size(8, 8)
fn fast_store(@builtin(global_invocation_id) gid: vec3<u32>) {
    if (gid.x >= prm(9u) || gid.y >= prm(10u)) {
        return;
    }
    let sx = prm(7u) * SX + gid.x;
    let sy = prm(8u) * SY + gid.y;
    let k = (sy % SY) * SX + sx % SX;
    let f = fmt_of(prm(13u), prm(11u), prm(12u));
    let l = addr(f, sx / SX, sy / SY);
    let w = l.word * SX * SY + k;
    var v = pack4x8unorm(textureLoad(fast_in, vec2<u32>(sx, sy), 0));
    if (prm(13u) == PSMCT24) {
        v = (v & 0xFFFFFFu) | (atomicLoad(&vram[w]) & 0xFF000000u);
    }
    atomicStore(&vram[w], v);
}
