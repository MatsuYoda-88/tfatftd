#pragma once

#include "ps2/cpu.hpp"
#include "ps2/system.hpp"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace ps2::state {
class Stream;
}

namespace ps2::gs {

inline constexpr std::uint32_t kMemorySize = 4u << 20;

enum Psm : std::uint32_t {
    PSMCT32 = 0x00, PSMCT24 = 0x01, PSMCT16 = 0x02, PSMCT16S = 0x0A,
    PSMT8 = 0x13, PSMT4 = 0x14, PSMT8H = 0x1B, PSMT4HL = 0x24, PSMT4HH = 0x2C,
    PSMZ32 = 0x30, PSMZ24 = 0x31, PSMZ16 = 0x32, PSMZ16S = 0x3A,
};

struct Vertex {
    std::uint32_t x, y, z;
    std::uint8_t r, g, b, a;
    float q, s, t;
    std::uint32_t u, v;
    std::uint8_t f;
};

struct Context {
    std::uint64_t tex0, clamp, tex1, tex2, xyoffset, miptbp1, miptbp2, scissor, alpha, test, fba, frame, zbuf;
};

struct State {
    std::uint64_t prim, prmode, prmodecont, rgbaq, st, uv, fog, texclut, scanmsk, texa, fogcol, dimx, dthe, colclamp, pabe;
    std::uint64_t bitbltbuf, trxpos, trxreg, trxdir;
    Context ctx[2];
    float q;
    Vertex queue[3];
    int count;
    std::uint32_t clut[512];
};

extern State g_state;
extern std::uint32_t g_setup_generation;
std::uint8_t *memory();

void init();
void state(ps2::state::Stream &s);
void reset();
void write(std::uint32_t reg, std::uint64_t value);
void signal(std::uint32_t reg, std::uint64_t value);
void note_transfer(std::uint32_t reg, std::uint64_t value);
void write_packed(std::uint32_t reg, const Reg128 &q);
// PACKED loops of exactly ST, RGBAQ, XYZ2 (98% of a tune shop's GIF data): handles `loops` of them in one go.
// Returns false (doing nothing) when the plain path must be used (tracing / lab switch).
bool write_packed_st_rgba_xyz2(const std::uint8_t *data, std::uint32_t loops);
void write_image(const std::uint8_t *data, std::uint32_t qwords);
void read_image(std::uint8_t *data, std::uint32_t qwords);
void render_read_image(std::uint8_t *data, std::uint32_t qwords);
void render_reset();

std::uint64_t read_privileged(std::uint32_t address);
void write_privileged(std::uint32_t address, std::uint64_t value);
void vblank(bool start);
bool interlaced_odd_field();

std::uint32_t address32(std::uint32_t bp, std::uint32_t bw, std::uint32_t x, std::uint32_t y);
std::uint32_t read_pixel(std::uint32_t psm, std::uint32_t bp, std::uint32_t bw, std::uint32_t x, std::uint32_t y);
void write_pixel(std::uint32_t psm, std::uint32_t bp, std::uint32_t bw, std::uint32_t x, std::uint32_t y, std::uint32_t value);

// HD texture replacement (PCSX2 replacement packs), see gs.cpp / hd.hpp
bool hd_enabled();
bool hd_upload_finish(std::uint64_t key, const std::uint8_t *data, std::size_t bytes);
void hd_touch_transfer(std::uint64_t buf, std::uint64_t pos, std::uint64_t reg, bool dest);
void hd_configure(std::uint32_t capacity_words, std::function<void(const std::string &, std::uint32_t, std::uint32_t, std::uint32_t)> request,
                  std::function<bool(std::uint32_t, const std::uint8_t *, std::size_t)> upload);
std::size_t hd_add_names(const char *text, std::size_t length);
void hd_loaded(std::uint32_t id, const std::uint8_t *rgba, std::uint32_t width, std::uint32_t height, std::uint32_t shift);
bool hd_lookup(const State &s, const Context &c, std::uint32_t &offset, std::uint32_t &shift);
void hd_stats();

struct DisplayRegs {
    std::uint64_t pmode, smode2, dispfb[2], display[2];
};
DisplayRegs display_regs();

bool display(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);
bool display(const DisplayRegs &regs, std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);
// Frame for hosts that draw it themselves, with interlaced fields blended like present(); may lag a frame.
bool copy_frame(std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);
bool copy_frame(const DisplayRegs &regs, std::vector<std::uint32_t> &rgba, std::uint32_t &width, std::uint32_t &height);
bool attach_window(int kind, void *display, std::uint64_t window, void *surface, const char *selector, std::uint32_t width, std::uint32_t height);
void resize_window(std::uint32_t width, std::uint32_t height);
bool present();
bool present(const DisplayRegs &regs);
void set_defer_show(bool on);
bool pending_show();
bool show_pending();
std::uint32_t show_count();
void start_thread();
void flush_and_wait();
void post_present();
Rendered render_pending(const std::function<void(const DisplayRegs &)> &on_present, double budget_ms);
double gpu_busy_ms();
void gpu_profile(std::uint64_t from, std::uint64_t to);
void set_fast_lane(int on);
std::uint64_t primitives_drawn();
void trace_draws(bool on);
bool present_as_43();
void stats();

}
