# Credits and thanks

tfatftd.xyz exists because a lot of people did a lot of hard work and shared it. Thank you, all of you. Because of
you I get to play this game again, with my friends, in a browser.

- **Samir Nuri (snuri00)** — ps2-web-recomp, the engine everything here is built on: the PS2 static recompiler, the
  runtime, the vector units, the sound, the browser port. https://github.com/snuri00/ps2-web-recomp
- **The PCSX2 team and every PCSX2 contributor** — the GS hardware renderer, texture cache, shaders and the game
  database fixes this site's high-resolution mode uses, and 20+ years of PS2 research. https://pcsx2.net
- **Eutechnyx** (developer), **Bandai Namco** (publisher) and **Universal** — for making The Fast and the Furious.
  This site is a fan project, not affiliated with or endorsed by them. Play with a disc you own.
- **Arapapa** — PS2 widescreen / field-of-view patch work that the widescreen and 32:9 options follow.
- **Emscripten**, **Dawn / emdawnwebgpu** (Google and contributors) and **wgpu-native** (gfx-rs) — C++ and WebGPU in
  the browser and on the desktop.
- **{fmt}** (Victor Zverovich and contributors), **xxHash** (Yann Collet), **fast_float** (Daniel Lemire and
  contributors), **Dear ImGui** (Omar Cornut, headers only), **stb_image** (Sean Barrett),
  **coi-serviceworker** (Guido Zuidhof) — the libraries inside.
- Everyone who documented the PS2's hardware over the years, and everyone who plays and tests on tfatftd.xyz.
